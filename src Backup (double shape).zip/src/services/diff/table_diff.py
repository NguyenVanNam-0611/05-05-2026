# src/services/diff/table_diff.py
"""
So sánh 2 table node ở mức row → cell → paragraph/image/nested table.

Fix so với cũ:
  - detect_structure_change: "cols" → "col_count" (khớp key từ extract_table)
  - diff_table: dùng SequenceMatcher trên row signature để align trước khi diff
    — tránh pair sai khi insert/delete row ở giữa bảng (zip theo index báo sai)
  - _diff_cell: match children theo type trước khi zip — tránh pair
    paragraph với image khi node xen kẽ nhau
  - nested table equal: emit unchanged để frontend biết cell có nested table
  - _row_sig: signature stable (không dùng row_index) — khớp với signature.py

Fix thêm (row merge):
  - _cell_full_text: lấy text từ children paragraphs nếu content.text rỗng
    — tránh sig rỗng khi cell chỉ có paragraph children, không có direct text
  - _rows_merged_into: detect N rows cũ → 1 row mới (text gộp lại trong 1 cell)
  - diff_table / replace opcode: gọi _try_emit_merge trước khi pair 1-1
    để emit table_row_merged thay vì pair sai + emit delete thừa
"""

from __future__ import annotations

import difflib
import hashlib
from typing import Any, Dict, List, Optional, Set, Tuple

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change
from src.services.extractor.utils import norm_text as _norm, norm_for_diff
from src.services.block.signature import _sig_row as _row_sig
# ── Serialization ─────────────────────────────────────────────────────────────

def _serialize_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None
    out = {
        "uid":      getattr(node, "uid",   None),
        "type":     node.type,
        "content":  node.content,
        "children": [_serialize_node(c) for c in (node.children or [])],
    }
    if out["type"] == "image":
        out["data_uri"] = (node.content or {}).get("data_uri")
    return out

def _serialize_cell(cell: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if cell is None:
        return None
    content = cell.content or {}
    return {
        "uid":          getattr(cell, "uid", None),
        "type":         "cell",
        "text":         _norm(content.get("text", "")),          # so sánh / diff
        "text_display": content.get("text_display", "")          # hiển thị UI ← thêm dòng này
            or _norm(content.get("text", "")),                   # fallback nếu chưa có
        "row_index":    content.get("row_index"),
        "col_index":    content.get("col_index"),
        "row_span":     content.get("row_span", 1),
        "col_span":     content.get("col_span", 1),
        "is_merged":    content.get("is_merged", False),
        "image_count": content.get("image_count", 0),  
        "children":    [_serialize_node(c) for c in (cell.children or [])],
    }

def _serialize_row(row: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    cells = [c for c in (row.children or []) if c.type == "cell"]
    return {
        "uid":       getattr(row, "uid", None),
        "type":      "row",
        "row_index": (row.content or {}).get("row_index"),
        "text":      (row.content or {}).get("text", ""),
        "cells":     [_serialize_cell(c) for c in cells],
    }


def _serialize_full_table(tbl: DocNode) -> Dict[str, Any]:
    rows = _get_rows(tbl)
    return {
        "uid":      getattr(tbl, "uid", None),
        "type":     "table",
        "content":  tbl.content or {},
        "rows":     [_serialize_row(r) for r in rows],
        "all_cells": [
            [_serialize_cell(c) for c in _get_cells(r)]
            for r in rows
        ],
    }


# ── Tree helpers ──────────────────────────────────────────────────────────────

def _cell_text(cell: Optional[DocNode]) -> str:
    if not cell:
        return ""
    return norm_for_diff(cell.content.get("text", ""))  # ← _norm → norm_for_diff

def _cell_full_text(cell: Optional[DocNode]) -> str:
    if not cell:
        return ""
    direct = norm_for_diff(cell.content.get("text", ""))  # ← đổi _norm → norm_for_diff
    if direct:
        return direct
    parts = []
    for child in (cell.children or []):
        if child.type == "paragraph":
            t = norm_for_diff(child.content.get("text", ""))  # ← đổi ở đây luôn
            if t:
                parts.append(t)
    return " ".join(parts)


def _row_text(row: Optional[DocNode]) -> str:
    if not row:
        return ""
    return _norm(row.content.get("text", ""))


def _get_rows(tbl: DocNode) -> List[DocNode]:
    return [c for c in (tbl.children or []) if c.type == "row"]


def _get_cells(row: DocNode) -> List[DocNode]:
    return [c for c in (row.children or []) if c.type == "cell"]


def _real_col_index(cell: Optional[DocNode], fallback: int) -> int:
    """
    Lấy col_index thật từ content — tránh lệch khi có merged/spanning cells.
    """
    if cell is None:
        return fallback
    return int((cell.content or {}).get("col_index") or fallback)



# ── Structure change detection ────────────────────────────────────────────────

def detect_structure_change(a_tbl, b_tbl):
    a_cols = int((a_tbl.content or {}).get("col_count", 0) or 0)
    b_cols = int((b_tbl.content or {}).get("col_count", 0) or 0)

    if a_cols > 0 and b_cols > 0 and a_cols != b_cols:
        # Dùng text_set thay vì text — không phụ thuộc thứ tự layout
        a_set = _norm(a_tbl.content.get("text_set", "") or "")
        b_set = _norm(b_tbl.content.get("text_set", "") or "")
        if a_set and b_set and a_set == b_set:
            return False
        return True

    # Fallback
    a_rows = _get_rows(a_tbl)
    b_rows = _get_rows(b_tbl)
    if a_rows and b_rows:
        a_max = max((len(_get_cells(r)) for r in a_rows), default=0)
        b_max = max((len(_get_cells(r)) for r in b_rows), default=0)
        if a_max != b_max:
            return True

    return False

def get_header_row(tbl: DocNode) -> Optional[Dict[str, Any]]:
    rows = _get_rows(tbl)
    return _serialize_row(rows[0]) if rows else None


# ── Paragraph diff inside cell ────────────────────────────────────────────────

def _diff_paragraph(a: DocNode, b: DocNode) -> Optional[Dict[str, Any]]:
    old_text = _norm(a.content.get("text", ""))
    new_text = _norm(b.content.get("text", ""))
    old_display = a.content.get("text_display") or old_text  # ← thêm
    new_display = b.content.get("text_display") or new_text  # ← thêm

    text_changed = old_text != new_text
    a_imgs = [c for c in (a.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.children or []) if c.type == "image"]

    if not text_changed and not a_imgs and not b_imgs:
        return None

    changes: List[Dict[str, Any]] = []

    if text_changed:
        word_diff   = diff_words(old_text, new_text, old_display=old_display, new_display=new_display)
        diff_result = word_diff if word_diff else {}
        changes.append({
            "type":             "paragraph_modified",
            "old_full_text":    diff_result.get("old_full_text", old_text),
            "new_full_text":    diff_result.get("new_full_text", new_text),
            "spans":            diff_result.get("spans", []),
            "original_content": a.content,
            "modified_content": b.content,
        })

    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if images_equal(ai, bi):
            changes.append({
                "type":        "image_unchanged",
                "change_kind": "equal",
                "image":       _serialize_node(ai),
            })
        else:
            changes.append(build_image_change(ai, bi))

    if not changes:
        return None

    return {
        "type":     "paragraph_container_modified",
        "original": _serialize_node(a),
        "modified": _serialize_node(b),
        "changes":  changes,
    }


# ── Cell diff ─────────────────────────────────────────────────────────────────

def _group_children_by_type(
    node: DocNode,
) -> Tuple[List[DocNode], List[DocNode], List[DocNode]]:
    paragraphs: List[DocNode] = []
    images:     List[DocNode] = []
    tables:     List[DocNode] = []
    for c in (node.children or []):
        if c.type == "paragraph":
            paragraphs.append(c)
        elif c.type == "image":
            images.append(c)
        elif c.type == "table":
            tables.append(c)
    return paragraphs, images, tables


def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    changes: List[Dict[str, Any]] = []

    a_paras, a_imgs, a_tables = _group_children_by_type(a)
    b_paras, b_imgs, b_tables = _group_children_by_type(b)

    for i in range(max(len(a_paras), len(b_paras))):
        ap = a_paras[i] if i < len(a_paras) else None
        bp = b_paras[i] if i < len(b_paras) else None

        if ap is None and bp is not None:
            changes.append({
                "type":        "paragraph_inserted",
                "change_kind": "insert",
                "original":    None,
                "modified":    _serialize_node(bp),
            })
        elif bp is None and ap is not None:
            changes.append({
                "type":        "paragraph_deleted",
                "change_kind": "delete",
                "original":    _serialize_node(ap),
                "modified":    None,
            })
        elif ap is not None and bp is not None:
            para_change = _diff_paragraph(ap, bp)
            if para_change:
                changes.append(para_change)

    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None

        if ai is None and bi is not None:
            changes.append(build_image_change(None, bi))
        elif bi is None and ai is not None:
            changes.append(build_image_change(ai, None))
        elif ai is not None and bi is not None:
            if not images_equal(ai, bi):
                changes.append(build_image_change(ai, bi))

    for i in range(max(len(a_tables), len(b_tables))):
        at = a_tables[i] if i < len(a_tables) else None
        bt = b_tables[i] if i < len(b_tables) else None

        if at is None and bt is not None:
            changes.append({
                "type":        "nested_table_inserted",
                "change_kind": "insert",
                "original":    None,
                "modified":    _serialize_node(bt),
                "changes":     [],
            })
        elif bt is None and at is not None:
            changes.append({
                "type":        "nested_table_deleted",
                "change_kind": "delete",
                "original":    _serialize_node(at),
                "modified":    None,
                "changes":     [],
            })
        elif at is not None and bt is not None:
            nested_changes = diff_table(at, bt)
            if nested_changes:
                changes.append({
                    "type":        "nested_table_modified",
                    "change_kind": "replace",
                    "original":    _serialize_node(at),
                    "modified":    _serialize_node(bt),
                    "changes":     nested_changes,
                })
            else:
                changes.append({
                    "type":        "nested_table_unchanged",
                    "change_kind": "equal",
                    "original":    _serialize_node(at),
                    "modified":    _serialize_node(bt),
                    "changes":     [],
                })

    return changes


# ── Row merge detection ───────────────────────────────────────────────────────

def _row_cell_texts(row: DocNode) -> List[str]:
    """
    Trả về list text (non-empty) của các cell trong row.
    Dùng _cell_full_text để cover cả cell có text trong paragraph children.
    """
    return [t for t in (_cell_full_text(c) for c in _get_cells(row)) if t]


def _rows_merged_into(
    a_rows: List[DocNode],
    b_row:  DocNode,
    col_count: int,
) -> Optional[List[int]]:
    """
    Kiểm tra xem b_row có phải là kết quả merge của nhiều rows trong a_rows không.

    Logic:
    1. Lấy text của từng cell trong b_row (new merged cell).
    2. Với mỗi cell của b_row, tách text thành các token bằng dấu phẩy/chấm phẩy.
    3. So sánh với text của cells trong a_rows: nếu text của a_row[i] là
       subset của tokens trong b_row → a_row[i] đã được merge vào b_row.
    4. Trả về list index của a_rows tham gia merge, hoặc None nếu không phải merge.

    Điều kiện để kết luận là merge:
    - Ít nhất 2 rows từ a được tìm thấy trong b_row.
    - Tất cả a_rows được truyền vào đều được accounted for (tham gia merge
      hoặc là row không đổi được bỏ qua bởi SequenceMatcher).

    Args:
        a_rows:    List các DocNode row từ bảng gốc trong 1 replace opcode block.
        b_row:     DocNode row đơn từ bảng mới (candidate merged row).
        col_count: Số cột của bảng (để context).

    Returns:
        List index (trong a_rows) của các rows đã bị merge vào b_row,
        hoặc None nếu không detect được merge.
    """
    # Text của tất cả cells trong b_row (new)
    b_cell_texts = [_cell_full_text(c) for c in _get_cells(b_row)]
    b_full_text  = " ".join(t for t in b_cell_texts if t).lower()

    if not b_full_text:
        return None

    # Build token set từ b — split bằng dấu phẩy, chấm phẩy, xuống dòng
    import re
    b_tokens: Set[str] = set()
    for raw in re.split(r"[,;\n]+", b_full_text):
        tok = _norm(raw)
        if tok:
            b_tokens.add(tok)

    merged_indices: List[int] = []

    for idx, a_row in enumerate(a_rows):
        a_texts = _row_cell_texts(a_row)
        if not a_texts:
            continue

        # Kiểm tra: tất cả text non-empty của a_row đều xuất hiện trong b
        # (either trong b_tokens hoặc là substring của b_full_text)
        all_found = all(
            t.lower() in b_tokens or t.lower() in b_full_text
            for t in a_texts
            if t  # bỏ qua text rỗng (merged cell continuation)
        )

        if all_found:
            merged_indices.append(idx)

    # Cần ít nhất 2 rows để gọi là "merge"
    if len(merged_indices) >= 2:
        return merged_indices

    return None


def _try_emit_merge(
    changes:   List[Dict[str, Any]],
    a_slice:   List[DocNode],  # rows từ a trong replace block
    b_row:     DocNode,        # row duy nhất từ b (candidate)
    row_idx:   int,
    a_tbl:     DocNode,
    b_tbl:     DocNode,
) -> Optional[Set[int]]:
    """
    Thử detect và emit table_row_merged cho b_row.

    Returns:
        Set index (trong a_slice) của các rows đã được consumed bởi merge,
        hoặc None nếu không phải merge case.

    Nếu merge được detect:
    - Emit 1 change "table_row_merged" thay vì replace + nhiều delete.
    - "merged_from_rows": list serialized rows gốc đã bị merge.
    - "cell_changes": diff giữa text gộp từ a → cell mới ở b.
    """
    col_count    = _table_col_count(b_tbl)
    merged_idxs  = _rows_merged_into(a_slice, b_row, col_count)

    if merged_idxs is None:
        return None

    merged_a_rows = [a_slice[i] for i in merged_idxs]

    # Build cell changes: so sánh text gộp từ merged rows với b_row
    # Dùng diff_words trên text tổng hợp để frontend highlight
    a_combined_text = ", ".join(
        t
        for r in merged_a_rows
        for t in _row_cell_texts(r)
        if t
    )

    b_cells    = _get_cells(b_row)
    b_combined = " ".join(_cell_full_text(c) for c in b_cells if _cell_full_text(c))

    cell_changes: List[Dict[str, Any]] = []

    # So sánh từng cell của b với text tổng hợp từ a
    for ci, bc in enumerate(b_cells):
        bc_text  = _cell_full_text(bc)
        if not bc_text:
            continue

        # Tìm cells trong a_rows cùng col_index
        real_col = _real_col_index(bc, ci)
        a_col_texts = []
        for ar in merged_a_rows:
            for ac in _get_cells(ar):
                if _real_col_index(ac, -1) == real_col:
                    t = _cell_full_text(ac)
                    if t:
                        a_col_texts.append(t)

        if not a_col_texts:
            # Cell mới hoàn toàn
            cell_changes.append({
                "type":        "table_cell_added",
                "change_kind": "insert",
                "col_index":   real_col,
                "left_cell":   None,
                "right_cell":  _serialize_cell(bc),
                "left_text":   "",
                "right_text":  bc_text,
                "changes":     [],
            })
        else:
            a_text_joined = ", ".join(a_col_texts)
            if a_text_joined != bc_text:
                cell_changes.append({
                    "type":        "table_cell_merged",
                    "change_kind": "replace",
                    "col_index":   real_col,
                    # left_cell: first cell từ merged rows tại col này
                    "left_cell":   _serialize_cell(next(
                        (ac for ar in merged_a_rows
                         for ac in _get_cells(ar)
                         if _real_col_index(ac, -1) == real_col),
                        None
                    )),
                    "right_cell":  _serialize_cell(bc),
                    "left_text":   a_text_joined,
                    "right_text":  bc_text,
                    # word_diff để frontend highlight merge
                    "word_diff":   diff_words(a_text_joined, bc_text),
                    "changes":     [],
                })

    changes.append({
        "type":        "table_row_merged",
        "change_kind": "replace",
        "row_index":   row_idx,
        "col_count":   col_count,

        # Tất cả rows gốc đã bị merge
        "merged_from_rows": [_serialize_row(r) for r in merged_a_rows],
        "merged_from_count": len(merged_a_rows),

        "left_row":    _serialize_row(merged_a_rows[0]) if merged_a_rows else None,
        "right_row":   _serialize_row(b_row),

        "left_cells":  [
            _serialize_cell(c)
            for r in merged_a_rows
            for c in _get_cells(r)
        ],
        "right_cells": [_serialize_cell(c) for c in b_cells],

        "left_display_cells":  _build_row_display_cells(a_tbl, merged_a_rows[0]),
        "right_display_cells": _build_row_display_cells(b_tbl, b_row),

        "left_text":   a_combined_text,
        "right_text":  b_combined,
        "cell_changes": cell_changes,
    })

    return set(merged_idxs)


# ── Main diff_table ───────────────────────────────────────────────────────────

def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh 2 table node, trả về list change ở mức row → cell.

    Dùng SequenceMatcher trên row signature để align rows trước khi diff.

    Xử lý thêm N→1 row merge trong replace opcode:
    - Nếu replace block có nhiều rows ở a nhưng ít ở b (hoặc 1 ở b),
      thử detect xem b_row có phải là kết quả merge của nhiều a_rows không.
    - Nếu đúng: emit table_row_merged, skip các a_rows đã được consumed.
    - Nếu không: fallback về pair 1-1 + delete/insert phần dư như cũ.
    """
    changes: List[Dict[str, Any]] = []

    a_rows = _get_rows(a_tbl)
    b_rows = _get_rows(b_tbl)

    if not a_rows and not b_rows:
        return changes

    a_sigs = [_row_sig(r) for r in a_rows]
    b_sigs = [_row_sig(r) for r in b_rows]
    sm      = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():

        if tag == "equal":
            continue

        if tag == "insert":
            for jr in range(j1, j2):
                br      = b_rows[jr]
                b_cells = _get_cells(br)
                changes.append({
                    "type":        "table_row_added",
                    "change_kind": "insert",
                    "row_index":   jr,
                    "col_count":   _table_col_count(b_tbl),
                    "left_row":    None,
                    "right_row":   _serialize_row(br),
                    "left_cells":  [],
                    "right_cells": [_serialize_cell(c) for c in b_cells],
                    "right_display_cells": _build_row_display_cells(b_tbl, br),
                    "left_text":   "",
                    "right_text":  _row_text(br),
                    "cell_changes": [],
                })
            continue

        if tag == "delete":
            for ir in range(i1, i2):
                ar      = a_rows[ir]
                a_cells = _get_cells(ar)
                changes.append({
                    "type":        "table_row_deleted",
                    "change_kind": "delete",
                    "row_index":   ir,
                    "col_count":   _table_col_count(a_tbl),
                    "left_row":    _serialize_row(ar),
                    "right_row":   None,
                    "left_cells":  [_serialize_cell(c) for c in a_cells],
                    "right_cells": [],
                    "left_display_cells": _build_row_display_cells(a_tbl, ar),
                    "left_text":   _row_text(ar),
                    "right_text":  "",
                    "cell_changes": [],
                })
            continue

        if tag == "replace":
            a_slice = a_rows[i1:i2]  # rows gốc trong block này
            b_slice = b_rows[j1:j2]  # rows mới trong block này

            n_a = len(a_slice)
            n_b = len(b_slice)

            # ── Detect N→1 merge: nhiều rows a → ít rows b ───────────────────
            # Chỉ thử khi a > b (merge giảm số rows)
            if n_a > n_b:
                consumed_a: Set[int] = set()  # index trong a_slice đã được merge

              # SAU KHI SỬA
                for k, br in enumerate(b_slice):
                    remaining_a = [
                        a_slice[i] for i in range(n_a)
                        if i not in consumed_a
                    ]

                    # ── Thử merge khi còn >= 2 rows chưa consume ──────────────────
                    consumed = None
                    if len(remaining_a) >= 2:
                        consumed = _try_emit_merge(
                            changes   = changes,
                            a_slice   = remaining_a,
                            b_row     = br,
                            row_idx   = j1 + k,
                            a_tbl     = a_tbl,
                            b_tbl     = b_tbl,
                        )

                    if consumed is not None:
                        # Merge thành công: map index trong remaining_a → index trong a_slice
                        remaining_indices = [
                            i for i in range(n_a) if i not in consumed_a
                        ]
                        for ci in consumed:
                            consumed_a.add(remaining_indices[ci])
                        # ✅ KHÔNG pair thêm — continue ngay
                    else:
                        # Không phải merge: pair 1-1 với a_row đầu tiên còn trống
                        first_avail = next(
                            (i for i in range(n_a) if i not in consumed_a),
                            None
                        )
                        if first_avail is not None:
                            _diff_one_row(
                                changes, a_slice[first_avail], br,
                                i1 + first_avail, a_tbl, b_tbl
                            )
                            consumed_a.add(first_avail)
                # Rows trong a_slice chưa được consume → delete
                for i in range(n_a):
                    if i not in consumed_a:
                        ar      = a_slice[i]
                        a_cells = _get_cells(ar)
                        changes.append({
                            "type":        "table_row_deleted",
                            "change_kind": "delete",
                            "row_index":   i1 + i,
                            "col_count":   _table_col_count(a_tbl),
                            "left_row":    _serialize_row(ar),
                            "right_row":   None,
                            "left_cells":  [_serialize_cell(c) for c in a_cells],
                            "right_cells": [],
                            "left_display_cells": _build_row_display_cells(a_tbl, ar),
                            "left_text":   _row_text(ar),
                            "right_text":  "",
                            "cell_changes": [],
                        })

                # b_rows chưa được pair → insert
                # (khi n_b > n_a không xảy ra ở nhánh này,
                #  nhưng nếu consume sót thì vẫn handle)
                paired_b: Set[int] = set()
                for change in changes:
                    if change.get("type") == "table_row_merged":
                        ri = change.get("row_index")
                        if ri is not None and j1 <= ri < j2:
                            paired_b.add(ri - j1)

                for k in range(n_b):
                    if k not in paired_b:
                        # Kiểm tra đã được emit bởi _diff_one_row chưa
                        # (không emit duplicate)
                        # _diff_one_row emit table_row_modified với row_index = i1+first_avail
                        # → không trùng với j index → cần check riêng
                        # Đơn giản: nếu n_a > n_b và k >= số b đã pair → insert
                        pass  # đã handle qua consumed_a logic ở trên

            else:
                # n_a <= n_b: pair 1-1 như cũ
                pairs = min(n_a, n_b)

                for k in range(pairs):
                    ar = a_slice[k]
                    br = b_slice[k]
                    _diff_one_row(changes, ar, br, i1 + k, a_tbl, b_tbl)

                # Phần dư a → delete
                for ir in range(i1 + pairs, i2):
                    ar      = a_rows[ir]
                    a_cells = _get_cells(ar)
                    changes.append({
                        "type":        "table_row_deleted",
                        "change_kind": "delete",
                        "row_index":   ir,
                        "col_count":   len(a_cells),
                        "left_row":    _serialize_row(ar),
                        "right_row":   None,
                        "left_cells":  [_serialize_cell(c) for c in a_cells],
                        "right_cells": [],
                        "left_text":   _row_text(ar),
                        "right_text":  "",
                        "cell_changes": [],
                    })

                # Phần dư b → insert
                for jr in range(j1 + pairs, j2):
                    br      = b_rows[jr]
                    b_cells = _get_cells(br)
                    changes.append({
                        "type":        "table_row_added",
                        "change_kind": "insert",
                        "row_index":   jr,
                        "col_count":   len(b_cells),
                        "left_row":    None,
                        "right_row":   _serialize_row(br),
                        "left_cells":  [],
                        "right_cells": [_serialize_cell(c) for c in b_cells],
                        "left_text":   "",
                        "right_text":  _row_text(br),
                        "cell_changes": [],
                    })

    return changes


def _diff_one_row(
    changes: List[Dict[str, Any]],
    ar: DocNode,
    br: DocNode,
    row_idx: int,
    a_tbl: DocNode,
    b_tbl: DocNode,
) -> None:
    a_cells = _get_cells(ar)
    b_cells = _get_cells(br)

    col_count = _table_col_count(b_tbl) or _table_col_count(a_tbl)

    def build_col_map(cells):
        m = {}
        for cell in cells:
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            for k in range(cs):
                m[ci + k] = cell
        return m

    a_map = build_col_map(a_cells)
    b_map = build_col_map(b_cells)

    all_cols = sorted(set(a_map) | set(b_map))

    row_changed = False
    row_cell_changes: List[Dict[str, Any]] = []

    for col in all_cols:
        ac = a_map.get(col)
        bc = b_map.get(col)

        ac_ci = int((ac.content or {}).get("col_index", 0) or 0) if ac is not None else col
        bc_ci = int((bc.content or {}).get("col_index", 0) or 0) if bc is not None else col

        ac_is_cont = (ac is not None and ac_ci != col)
        bc_is_cont = (bc is not None and bc_ci != col)

        # Cả 2 đều là continuation của colspan đã xử lý → skip
        if ac_is_cont and bc_is_cont:
            continue

        # bc là continuation (đã xử lý ở col=bc_ci), ac chưa xử lý → ac bị xóa
        if bc_is_cont and not ac_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_deleted",
                "change_kind": "delete",
                "col_index":   col,
                "left_cell":   _serialize_cell(ac),
                "right_cell":  None,
                "left_text":   _cell_full_text(ac),
                "right_text":  "",
                "changes":     [],
            })
            continue

        # ac là continuation (đã xử lý ở col=ac_ci), bc chưa xử lý → bc mới thêm
        if ac_is_cont and not bc_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_added",
                "change_kind": "insert",
                "col_index":   col,
                "left_cell":   None,
                "right_cell":  _serialize_cell(bc),
                "left_text":   "",
                "right_text":  _cell_full_text(bc),
                "changes":     [],
            })
            continue

        # Từ đây: cả 2 đều là cell gốc (không phải continuation)

        if ac is None and bc is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_added",
                "change_kind": "insert",
                "col_index":   col,
                "left_cell":   None,
                "right_cell":  _serialize_cell(bc),
                "left_text":   "",
                "right_text":  _cell_full_text(bc),
                "changes":     [],
            })
            continue

        if bc is None and ac is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_deleted",
                "change_kind": "delete",
                "col_index":   col,
                "left_cell":   _serialize_cell(ac),
                "right_cell":  None,
                "left_text":   _cell_full_text(ac),
                "right_text":  "",
                "changes":     [],
            })
            continue

        if ac is None or bc is None:
            continue

        a_cs = int((ac.content or {}).get("col_span", 1) or 1)
        b_cs = int((bc.content or {}).get("col_span", 1) or 1)

        if a_cs != b_cs:
            # colspan thay đổi → gộp các a_cells trong range [col, col+b_cs)      
            a_covered = sorted(
                {a_map[c] for c in range(col, col + b_cs) if c in a_map},
                key=lambda x: int((x.content or {}).get("col_index", 0) or 0)
            )
            a_combined_text = " ".join(
                _cell_full_text(c) for c in a_covered if _cell_full_text(c)
            )
            b_text = _cell_full_text(bc)

            row_changed = True
            row_cell_changes.append({
                "type":           "table_cell_span_changed",
                "change_kind":    "replace",
                "col_index":      col,
                "left_cell":      _serialize_cell(ac),
                "right_cell":     _serialize_cell(bc),
                "left_text":      a_combined_text,
                "right_text":     b_text,
                "left_col_span":  a_cs,
                "right_col_span": b_cs,
                "left_cells":     [_serialize_cell(c) for c in a_covered],
                "changes": [{
                    "type":          "paragraph_modified",
                    "old_full_text": a_combined_text,
                    "new_full_text": b_text,
                    "spans":         (diff_words(a_combined_text, b_text) or {}).get("spans", []),
                }],
            })
            continue

        # Cùng colspan → diff bình thường
        cell_changes = _diff_cell(ac, bc)
        if cell_changes:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   col,
                "left_cell":   _serialize_cell(ac),
                "right_cell":  _serialize_cell(bc),
                "left_text":   _cell_text(ac),
                "right_text":  _cell_text(bc),
                "changes":     cell_changes,
            })

    if row_changed:
        changes.append({
            "type":        "table_row_modified",
            "change_kind": "replace",
            "row_index":   row_idx,
            "col_count":   col_count,
            "left_row":    _serialize_row(ar),
            "right_row":   _serialize_row(br),
            "left_cells":  [_serialize_cell(c) for c in a_cells],
            "right_cells": [_serialize_cell(c) for c in b_cells],
            "left_display_cells":  _build_row_display_cells(a_tbl, ar),
            "right_display_cells": _build_row_display_cells(b_tbl, br),
            "left_text":   _row_text(ar),
            "right_text":  _row_text(br),
            "cell_changes": row_cell_changes,
        })
# ── High-level table change analysis — dùng bởi json_builder ─────────────────

TABLE_RENDER_FULL         = "full_table"
TABLE_RENDER_ROW_ADDED    = "row_added"
TABLE_RENDER_ROW_DELETED  = "row_deleted"
TABLE_RENDER_DELETED      = "table_deleted"
TABLE_RENDER_ROW_MODIFIED = "row_modified"
TABLE_RENDER_ROW_MERGED   = "row_merged"   # NEW


def _is_span_only_change(change: Dict[str, Any]) -> bool:
    """
    Trả True nếu row_modified chỉ khác col_span nhưng text giống nhau.
    False positive do title row làm lệch gridSpan XML.
    """
    if change.get("type") != "table_row_modified":
        return False
    cell_changes = change.get("cell_changes", [])
    if not cell_changes:
        return False
    for cc in cell_changes:
        if cc.get("type") != "table_cell_span_changed":
            return False
        if _norm(cc.get("left_text", "")) != _norm(cc.get("right_text", "")):
            return False
    return True
def _collect_row_all_text(change: Dict[str, Any], side: str) -> str:
    """
    Gom toàn bộ text của 1 side (left/right) trong 1 row change.
    
    Dùng để so sánh content thực sự — không phân biệt layout/span.
    side = "left" hoặc "right".
    
    Lấy từ {side}_cells nếu có, fallback về {side}_text.
    """
    cells_key = f"{side}_cells"
    text_key  = f"{side}_text"

    cells = change.get(cells_key) or []
    if cells:
        parts = []
        for c in cells:
            if not c:
                continue
            t = _norm(c.get("text", "") or "")
            if t:
                parts.append(t)
        return " ".join(parts)

    return _norm(change.get(text_key, "") or "")


def _is_text_only_layout_change(change: Dict[str, Any]) -> bool:
    """
    Trả True nếu change chỉ là layout/span/merge thay đổi
    nhưng tổng text content của left == right.

    Áp dụng cho:
    - table_row_modified  : so sánh left_text vs right_text
    - table_row_merged    : gom text tất cả merged_from_rows vs right_row
    - table_row_deleted   : kiểm tra xem text có xuất hiện ở right table không
                            (không thể biết ở đây — chỉ skip modified/merged)
    - table_row_added     : tương tự deleted

    NOTE: deleted/added KHÔNG filter ở đây vì không có cả 2 side để so sánh.
    Chỉ filter modified và merged.
    """
    change_type = change.get("type", "")

    if change_type == "table_row_modified":
        left_text  = _collect_row_all_text(change, "left")
        right_text = _collect_row_all_text(change, "right")
        return left_text == right_text

    if change_type == "table_row_merged":
        merged_rows = change.get("merged_from_rows") or []
        left_parts  = set()
        for row in merged_rows:
            if not row:
                continue
            for cell in (row.get("cells") or []):
                if not cell:
                    continue
                t = _norm(cell.get("text", "") or "")
                if t:
                    left_parts.add(t)

        right_parts = set()
        for cell in (change.get("right_cells") or []):
            if not cell:
                continue
            t = _norm(cell.get("text", "") or "")
            if t:
                right_parts.add(t)

        return left_parts == right_parts  # so sánh set, không phụ thuộc thứ tự

    return False

def analyze_table_change(
    a_tbl:         Optional[DocNode],
    b_tbl:         Optional[DocNode],
    table_changes: List[Dict[str, Any]],
) -> Dict[str, Any]:

    # ── Xóa bảng ──────────────────────────────────────────────────────────────
    if a_tbl is not None and b_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_DELETED,
            "structure_changed":   False,
            "full_table_original": _serialize_full_table(a_tbl),
            "full_table_modified": None,
            "header_row":          get_header_row(a_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    # ── Thêm bảng ─────────────────────────────────────────────────────────────
    if b_tbl is not None and a_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   False,
            "full_table_original": None,
            "full_table_modified": _serialize_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    assert a_tbl is not None and b_tbl is not None

    structure_changed = detect_structure_change(a_tbl, b_tbl)

    # ── Filter meaningful_changes ──────────────────────────────────────────────
    meaningful_changes = [c for c in table_changes if not _is_span_only_change(c)]
    meaningful_changes = [c for c in meaningful_changes if not _is_text_only_layout_change(c)]

    seen_row_keys: set = set()
    deduped: list = []
    for c in meaningful_changes:
        ri  = c.get("row_index")
        ct  = c.get("type", "")
        key = (ct, ri) if ri is not None else id(c)
        if key not in seen_row_keys:
            seen_row_keys.add(key)
            deduped.append(c)
    meaningful_changes = deduped

    # ── Layout khác nhưng content giống → hiện full 2 bảng ───────────────────
    if structure_changed and not meaningful_changes:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   True,
            "full_table_original": _serialize_full_table(a_tbl),
            "full_table_modified": _serialize_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    # ── Không có thay đổi gì → không hiện ────────────────────────────────────
    if not meaningful_changes:
        return None

    # ── Có changes → luôn hiện theo từng dòng ─────────────────────────────────
    added_rows   = [c for c in meaningful_changes if c.get("type") == "table_row_added"]
    deleted_rows = [c for c in meaningful_changes if c.get("type") == "table_row_deleted"]
    merged_rows  = [c for c in meaningful_changes if c.get("type") == "table_row_merged"]

    return {
        "render_mode":         TABLE_RENDER_ROW_MODIFIED,
        "structure_changed":   structure_changed,
        "full_table_original": _serialize_full_table(a_tbl),
        "full_table_modified": _serialize_full_table(b_tbl),
        "header_row":          get_header_row(b_tbl),
        "added_rows":          added_rows,
        "deleted_rows":        deleted_rows,
        "merged_rows":         merged_rows,
        "table_changes":       meaningful_changes,
    }
def _table_col_count(tbl: DocNode) -> int:
    """Lấy số cột logic của table."""
    cc = int((tbl.content or {}).get("col_count", 0) or 0)
    if cc > 0:
        return cc

    mx = 0
    for r in _get_rows(tbl):
        for c in _get_cells(r):
            ci = int((c.content or {}).get("col_index", 0) or 0)
            cs = int((c.content or {}).get("col_span", 1) or 1)
            mx = max(mx, ci + cs)
    if mx > 0:
        return mx

    rows = _get_rows(tbl)
    return len(_get_cells(rows[0])) if rows else 0


def _build_row_display_cells(tbl: DocNode, target_row: DocNode):
    rows      = _get_rows(tbl)
    col_count = _table_col_count(tbl)
    if col_count == 0:
        return [_serialize_cell(c) for c in _get_cells(target_row)]

    target_ri = int((target_row.content or {}).get("row_index", -1) or -1)
    target_id = id(target_row)

    active: List[Optional[Dict[str, Any]]] = [None] * col_count

    def _virtual_from_master(master_ser, current_row_index):
        v = dict(master_ser)
        v["virtual_from_merge"] = True
        v["row_span"] = 1
        v["row_index"] = current_row_index
        return v

    for r in rows:
        ri        = int((r.content or {}).get("row_index", -1) or -1)
        # ← Chỉ dùng id() — không dùng ri để tránh match nhầm nhiều rows cùng ri
        is_target = (id(r) == target_id)

        grid: List[Optional[Dict[str, Any]]] = [None] * col_count

        for col in range(col_count):
            info = active[col]
            if not info:
                continue
            if info["start_col"] != col:
                continue
            master = info["master_ser"]
            cs     = int(info.get("col_span", 1) or 1)
            grid[col] = _virtual_from_master(master, ri)
            for k in range(1, cs):
                if col + k < col_count:
                    grid[col + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": master.get("uid"),
                    }

        for cell in _get_cells(r):
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            if ci < 0 or ci >= col_count:
                continue
            ser = _serialize_cell(cell) or {}
            ser["virtual_from_merge"] = False
            grid[ci] = ser

            cs = int((cell.content or {}).get("col_span", 1) or 1)
            rs = int((cell.content or {}).get("row_span", 1) or 1)

            for k in range(1, cs):
                if ci + k < col_count:
                    grid[ci + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": ser.get("uid"),
                    }

            if rs > 1:
                info_obj = {
                    "master_ser": ser,
                    "remain":     rs - 1,
                    "start_col":  ci,
                    "col_span":   cs,
                }
                for k in range(cs):
                    if ci + k < col_count:
                        active[ci + k] = info_obj

        if is_target:
            return grid

        to_clear = []
        for col in range(col_count):
            info = active[col]
            if not info:
                continue
            if info["start_col"] == col:
                info["remain"] -= 1
                if info["remain"] < 0:
                    cs = int(info.get("col_span", 1) or 1)
                    for k in range(cs):
                        if col + k < col_count:
                            to_clear.append(col + k)
        for col in to_clear:
            active[col] = None

    return [_serialize_cell(c) for c in _get_cells(target_row)]

