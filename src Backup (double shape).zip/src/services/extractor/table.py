"""
extractor/table.py
~~~~~~~~~~~~~~~~~~
Extract table và cell từ docx thành DocNode.

Chịu trách nhiệm:
    - Duyệt table → row → cell (kể cả merged cell)
    - Extract nội dung cell: paragraph, image inline, nested table
    - Tính merge info (col_span, row_span)
    - Lọc bỏ paragraph rỗng trong cell (Word tự thêm)

KHÔNG xử lý: paragraph ở document level, TOC, shape ở document level.
Import từ: utils.py, paragraph.py

Iterator _iter_cell_items nằm ở đây vì chỉ table.py dùng.

Cây trả về từ extract_table():
    table
    └── row
        └── cell
            ├── paragraph
            │   └── image       (inline)
            └── table           (nested — đệ quy)
"""

from __future__ import annotations

from typing import Dict, Iterator, List, Optional, Tuple, Union

from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph

from src.services.models.docnode import DocNode
from src.services.extractor.paragraph import extract_paragraph_nodes
from src.services.extractor.utils import OrderRef, next_order, norm_text, raw_text

# ── Types ─────────────────────────────────────────────────────────────────────

BlockItem = Union[Paragraph, Table]


# ══════════════════════════════════════════════════════════════════════════════
# Cell iterator
# ══════════════════════════════════════════════════════════════════════════════

def _iter_cell_items(cell: _Cell) -> Iterator[BlockItem]:
    """
    Duyệt các phần tử con trực tiếp của 1 cell.
    Yield Paragraph hoặc Table theo đúng thứ tự XML.

    Khác với iter_block_items của document:
    - Chỉ nhận _Cell
    - Lọc bỏ paragraph rỗng (không text, không ảnh inline)
      vì Word tự thêm paragraph rỗng cuối mỗi cell —
      giữ lại gây false positive khi diff signature.

    Paragraph được giữ nếu có text HOẶC có ảnh inline (w:drawing).
    """
    for child in cell._tc.iterchildren():
        if isinstance(child, CT_P):
            par = Paragraph(child, cell)

            has_text  = bool(norm_text(par.text))
            has_image = any(
                run._r is not None and run._r.find(qn("w:drawing")) is not None
                for run in par.runs
            )

            if has_text or has_image:
                yield par

        elif isinstance(child, CT_Tbl):
            yield Table(child, cell)


# ══════════════════════════════════════════════════════════════════════════════
# XML / merged cell helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_xml_rows(tbl: Table) -> List[List]:
    """
    Trả về list[list[tc_element]] — physical cells từ XML.
    python-docx deduplicate merged cells nên KHÔNG dùng tbl.rows[r].cells.
    """
    TR = qn("w:tr")
    TC = qn("w:tc")
    return [
        list(tr.iterchildren(TC))
        for tr in tbl._tbl.iterchildren(TR)
    ]


def _tc_col_span(tc) -> int:
    """Số cột mà tc này chiếm (gridSpan)."""
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1
    gs = tcPr.find(qn("w:gridSpan"))
    return int(gs.get(qn("w:val"), 1)) if gs is not None else 1


# BUG FIX #1: Tính n_cols từ XML thực tế thay vì tbl.columns
# tbl.columns ném exception với merged/jagged table → trả 0 sai.
# _count_cols_from_xml đọc gridSpan của từng hàng → kết quả đúng với
# mọi loại table kể cả irregular colspan.

def _count_cols_from_xml(xml_rows: List[List]) -> int:
    """
    Tính số cột thực tế của table từ XML rows đã parse.
    
    Ưu tiên rows có > 1 physical cell để tránh title row (1 cell spanning)
    làm lệch col_count. Fallback về tất cả rows nếu không có multi-cell row.
    """
    if not xml_rows:
        return 0

    # Rows có > 1 cell = rows dữ liệu thực
    multi_cell_rows = [row for row in xml_rows if len(row) > 1]
    candidate_rows  = multi_cell_rows if multi_cell_rows else xml_rows

    return max(
        sum(_tc_col_span(tc) for tc in row)
        for row in candidate_rows
    )


def _get_cell_merge_info(cell: _Cell) -> Tuple[int, bool, bool]:
    """
    Trả về (col_span, is_restart, is_continue).

    is_restart  = True → cell này bắt đầu 1 vMerge group
    is_continue = True → cell này là phần tiếp của vMerge (bỏ qua)
    """
    tc   = cell._tc
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1, False, False

    gs       = tcPr.find(qn("w:gridSpan"))
    col_span = int(gs.get(qn("w:val"), 1)) if gs is not None else 1

    vMerge = tcPr.find(qn("w:vMerge"))
    if vMerge is None:
        return col_span, False, False

    val = vMerge.get(qn("w:val"), "")
    if val == "restart":
        return col_span, True, False
    return col_span, False, True


def _count_row_span(xml_rows: List[List], row_idx: int, grid_col: int) -> int:
    """
    Đếm số row mà cell tại (row_idx, grid_col) chiếm
    bằng cách đi xuống và đếm các vMerge continuation.
    """
    span = 1
    for r in range(row_idx + 1, len(xml_rows)):
        pos      = 0
        found_tc = None

        for tc in xml_rows[r]:
            if pos == grid_col:
                found_tc = tc
                break
            pos += _tc_col_span(tc)
            if pos > grid_col:
                break

        if found_tc is None:
            break

        tcPr   = found_tc.find(qn("w:tcPr"))
        vMerge = tcPr.find(qn("w:vMerge")) if tcPr is not None else None

        if vMerge is None:
            break
        if vMerge.get(qn("w:val"), "") == "restart":
            break

        span += 1

    return span


# ══════════════════════════════════════════════════════════════════════════════
# Cell content helpers
# ══════════════════════════════════════════════════════════════════════════════

def _cell_direct_text(cell: _Cell) -> str:
    """
    Lấy text đã normalize của cell — dùng để diff/so sánh.
    Nhiều paragraph (do Enter) được join bằng space.
    Ký tự xuống dòng, tab, dấu phẩy đã được norm_text loại bỏ.
    """
    parts = []
    for item in _iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = norm_text(item.text)
            if t:
                parts.append(t)
    return " ".join(parts)


#

def _cell_raw_text(cell: _Cell) -> str:
    parts = []
    for item in _iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = raw_text(item.text)   # ← dùng raw_text mới
            if t:
                parts.append(t)
    return "\n".join(parts)


def _cell_image_count(cell: _Cell) -> int:
    """
    Đếm tổng số ảnh inline trong tất cả paragraph của cell.
    Giúp diff/frontend biết cell có ảnh mà không cần walk toàn bộ cây.
    """
    count = 0
    for item in _iter_cell_items(cell):
        if not isinstance(item, Paragraph):
            continue
        for run in item.runs:
            r_elem = run._r
            if r_elem is not None and r_elem.find(qn("w:drawing")) is not None:
                count += 1
    return count


# ══════════════════════════════════════════════════════════════════════════════
# Cell extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_cell(
    cell: _Cell,
    uid_prefix: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    row_index: int,
    col_index: int,
    col_span: int = 1,
    row_span: int = 1,
    is_merged: bool = False,
) -> DocNode:
    import logging
    from docx.oxml.ns import qn as _qn
    from src.services.extractor.image import _NS, _pure
    _log = logging.getLogger(__name__)

    cell_node = DocNode(
        type="cell",
        uid=uid_prefix,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid_prefix.replace(".", "/"),
        content={
            "text":         _cell_direct_text(cell),
            "text_display": _cell_raw_text(cell),
            "row_index":    row_index,
            "col_index":    col_index,
            "row_span":     row_span,
            "col_span":     col_span,
            "is_merged":    is_merged,
            "image_count":  _cell_image_count(cell),
        },
    )

    # ── DEBUG START ───────────────────────────────────────────────────────────
    _log.warning(f"\n{'='*60}")
    _log.warning(f"CELL [{uid_prefix}] row={row_index} col={col_index}")
    _log.warning(f"  image_count (từ _cell_image_count): {_cell_image_count(cell)}")

    for _dbg_idx, _dbg_item in enumerate(_iter_cell_items(cell)):
        if isinstance(_dbg_item, Paragraph):
            _dbg_text = norm_text(_dbg_item.text)
            _dbg_drawings = [
                run._r for run in _dbg_item.runs
                if run._r is not None and run._r.find(_qn("w:drawing")) is not None
            ]
            _log.warning(
                f"  item[{_dbg_idx}] = Paragraph "
                f"text={_dbg_text!r:.40} "
                f"drawings={len(_dbg_drawings)}"
            )
            for _di, _dr in enumerate(_dbg_drawings):
                _drawing_elem = _dr.find(_qn("w:drawing"))
                if _drawing_elem is None:
                    continue
                _dr_pure     = _pure(_drawing_elem)
                _has_inline  = bool(_dr_pure.xpath("wp:inline", namespaces=_NS))
                _has_anchor  = bool(_dr_pure.xpath("wp:anchor", namespaces=_NS))
                _blips       = _dr_pure.xpath(".//a:blip/@r:embed", namespaces=_NS)
                _log.warning(
                    f"    drawing[{_di}]: inline={_has_inline} anchor={_has_anchor} "
                    f"blip_rids={_blips}"
                )
        else:
            _log.warning(f"  item[{_dbg_idx}] = {type(_dbg_item).__name__}")
    # ── DEBUG END ─────────────────────────────────────────────────────────────

    para_texts     = []
    first_para     = None
    all_para_items = []
    table_items    = []

    for item in _iter_cell_items(cell):
        if isinstance(item, Paragraph):
            all_para_items.append(item)
            t = norm_text(item.text)
            if t:
                para_texts.append(t)
                if first_para is None:
                    first_para = item
        elif isinstance(item, Table):
            table_items.append(item)

    n = 0

    if first_para is not None:
        n += 1
        merged_text = " ".join(para_texts)

        raw_parts = []
        for item in _iter_cell_items(cell):
            if isinstance(item, Paragraph):
                t = raw_text(item.text)
                if t:
                    raw_parts.append(t)
        merged_text_display = "\n".join(raw_parts)

        nodes = list(extract_paragraph_nodes(
            first_para,
            uid=f"{uid_prefix}.p{n}",
            parent_uid=uid_prefix,
            order_ref=order_ref,
            in_toc=False,
        ))
        if nodes:
            nodes[0].content["text"]         = merged_text
            nodes[0].content["text_display"] = merged_text_display
            cell_node.add_child(nodes[0])

    from src.services.extractor.image import extract_inline_images

    for para in all_para_items:
        has_text = bool(norm_text(para.text))
        if has_text:
            continue
        imgs = extract_inline_images(
            para,
            uid_prefix=f"{uid_prefix}.img{n}",
            parent_uid=uid_prefix,
            order_ref=order_ref,
        )
        for img in imgs:
            n += 1
            cell_node.add_child(img)

    for item in table_items:
        n += 1
        cell_node.add_child(
            extract_table(
                item,
                uid=f"{uid_prefix}.t{n}",
                parent_uid=uid_prefix,
                order_ref=order_ref,
            )
        )

    # ── DEBUG children sau extract ────────────────────────────────────────────
    _log.warning(f"CELL [{uid_prefix}] children sau extract:")
    for _ch in (cell_node.children or []):
        _log.warning(f"  child type={_ch.type} uid={_ch.uid}")
        if _ch.type == "paragraph":
            for _gch in (_ch.children or []):
                _log.warning(
                    f"    grandchild type={_gch.type} uid={_gch.uid} "
                    f"has_data_uri={bool((_gch.content or {}).get('data_uri'))}"
                )
        if _ch.type == "image":
            _log.warning(f"    has_data_uri={bool((_ch.content or {}).get('data_uri'))}")
    # ── DEBUG END ─────────────────────────────────────────────────────────────

    return cell_node

# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_table(
    tbl: Table,
    uid: Optional[str] = None,
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> DocNode:
    """
    Extract một table thành DocNode (kể cả nested table đệ quy).

    Args:
        tbl:        Table object từ python-docx.
        uid:        UID của table node (vd: "n3", "n3.r1.c2.t1").
        parent_uid: UID của node cha.
        order_ref:  Mutable counter dùng chung toàn document.

    Returns:
        DocNode(type="table") với cây con row → cell → ...
    """
    
    
    if order_ref is None:
        order_ref = {"value": 0}

    # BUG FIX #1: parse xml_rows sớm để tính n_cols đúng
    # Trước đây: len(tbl.columns) ném exception với merged/jagged table → n_cols=0
    # Bây giờ: _count_cols_from_xml đọc gridSpan từ XML rows → luôn đúng
    xml_rows = _get_xml_rows(tbl)
    n_rows   = len(xml_rows)
    n_cols   = _count_cols_from_xml(xml_rows)

    table_text = "\n".join(
        " | ".join(_cell_direct_text(cell) for cell in row.cells)
        for row in tbl.rows
    )

    all_cell_texts = sorted(set(
        _cell_direct_text(cell)
        for row in tbl.rows
        for cell in row.cells
        if _cell_direct_text(cell)
    ))

    table_node = DocNode(
        type="table",
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=(uid or "").replace(".", "/"),
        content={
            "row_count": n_rows,
            "col_count": n_cols,
            "text":      table_text,
            "text_set":  " ".join(all_cell_texts),  # ← thêm vào đây
        },
    )
    # xml_rows đã được tính ở trên — không parse lại
    skip_map: Dict[Tuple[int, int], bool] = {}

    for r_idx, row in enumerate(tbl.rows):
        row_uid  = f"{uid}.r{r_idx}" if uid else f"row.{r_idx}"
        xml_tcs  = xml_rows[r_idx] if r_idx < len(xml_rows) else []
        row_text = " | ".join(_cell_direct_text(c) for c in row.cells)

        row_node = DocNode(
            type="row",
            uid=row_uid,
            parent_uid=uid,
            order=next_order(order_ref),
            path=row_uid.replace(".", "/"),
            content={
                "row_index":  r_idx,
                "cell_count": len(xml_tcs),
                "text":       row_text,
            },
        )
        table_node.add_child(row_node)

        logical_col = 0

        for tc in xml_tcs:
            if skip_map.get((r_idx, logical_col)):
                logical_col += _tc_col_span(tc)
                continue

            cell = _Cell(tc, tbl)
            col_span, is_restart, is_continue = _get_cell_merge_info(cell)

            if is_continue:
                logical_col += col_span
                continue

            row_span  = 1
            is_merged = col_span > 1

            if is_restart:
                row_span  = _count_row_span(xml_rows, r_idx, logical_col)
                is_merged = True
                for dr in range(1, row_span):
                    for dc in range(col_span):
                        skip_map[(r_idx + dr, logical_col + dc)] = True

            cell_uid = (
                f"{uid}.r{r_idx}.c{logical_col}"
                if uid else
                f"cell.r{r_idx}.c{logical_col}"
            )

            row_node.add_child(
                _extract_cell(
                    cell=cell,
                    uid_prefix=cell_uid,
                    parent_uid=row_uid,
                    order_ref=order_ref,
                    row_index=r_idx,
                    col_index=logical_col,
                    col_span=col_span,
                    row_span=row_span,
                    is_merged=is_merged,
                )
            )

            logical_col += col_span

    return table_node