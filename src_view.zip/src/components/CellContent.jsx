// ─────────────────────────────────────────────────────────────
// CellContent.jsx
// Renders a serialized cell node OR a cell diff (cellChange).
// Used by TableChange for both full-table and row-modified modes.
// ─────────────────────────────────────────────────────────────
import { getCellText, getCellImages, getAllCellImages } from '../utils/diffHelpers';
import { WordDiff, ImgBox } from './WordDiff';

// ── Nested table (plain, no diff) ────────────────────────────
export function NestedTable({ tableNode, wrapClass = '' }) {
  if (!tableNode) return <span className="empty-hint">(nested table trống)</span>;
  const rows = (tableNode.children || []).filter(r => r?.type === 'row');
  if (!rows.length) return <span className="empty-hint">(nested table rỗng)</span>;
  return (
    <div className={`nested-tbl-wrap ${wrapClass}`}>
      <table className="nested-doc-table">
        <tbody>
          {rows.map((row, ri) => {
            const cells = (row.children || []).filter(c => c?.type === 'cell');
            const isHeader = ri === 0;
            const Tag = isHeader ? 'th' : 'td';
            return (
              <tr key={ri}>
                {cells.map((cell, ci) => {
                  const content = cell.content || {};
                  const cSpan = content.col_span > 1 ? content.col_span : undefined;
                  const rSpan = content.row_span > 1 ? content.row_span : undefined;
                  const txt = content.text_display ?? content.text ?? '';
                  const nested = (cell.children || []).filter(ch => ch?.type === 'table');
                  return (
                    <Tag key={ci} colSpan={cSpan} rowSpan={rSpan}>
                      {txt}
                      {nested.map((t, ti) => (
                        <NestedTable key={ti} tableNode={t} wrapClass="nested-level-2" />
                      ))}
                    </Tag>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Nested table with diff highlights ────────────────────────
export function NestedTableWithDiff({ tableNode, side, nestedChanges = [] }) {
  if (!tableNode) return <span className="empty-hint">(trống)</span>;
  const rows = (tableNode.children || []).filter(r => r?.type === 'row');
  if (!rows.length) return <span className="empty-hint">(rỗng)</span>;

  const cellChangeMap = {};
  const modifiedRows = new Set();
  const addedRows = new Set();
  const deletedRows = new Set();

  nestedChanges.forEach(nc => {
    if (nc.type === 'table_row_modified') {
      modifiedRows.add(nc.row_index);
      cellChangeMap[nc.row_index] = {};
      (nc.cell_changes || []).forEach(cc => {
        cellChangeMap[nc.row_index][cc.col_index] = cc;
      });
    }
    if (nc.type === 'table_row_added') addedRows.add(nc.row_index);
    if (nc.type === 'table_row_deleted') deletedRows.add(nc.row_index);
  });

  return (
    <div className="nested-tbl-wrap">
      <table className="nested-doc-table">
        <tbody>
          {rows.map((row, arrayIdx) => {
            const content = row.content || {};
            const ri = content.row_index != null ? Number(content.row_index) : arrayIdx;
            const cells = (row.children || []).filter(c => c?.type === 'cell');
            const rCls =
              (addedRows.has(ri) && side === 'right') ? 'row-added' :
              (deletedRows.has(ri) && side === 'left') ? 'row-deleted' :
              modifiedRows.has(ri) ? 'row-modified' : '';
            return (
              <tr key={ri} className={rCls}>
                {cells.map((cell, ci) => {
                  const cContent = cell.content || {};
                  const colIdx = cContent.col_index != null ? Number(cContent.col_index) : ci;
                  const cSpan = cContent.col_span > 1 ? cContent.col_span : undefined;
                  const rSpan = cContent.row_span > 1 ? cContent.row_span : undefined;
                  const txt = cContent.text_display ?? cContent.text ?? '';
                  const cc = cellChangeMap[ri]?.[colIdx];
                  return (
                    <td key={ci} className={cc ? 'cell-changed' : ''} colSpan={cSpan} rowSpan={rSpan}>
                      {cc ? <CellContent cellChange={cc} side={side} fallback={txt} /> : txt}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Cell node (no diff) ───────────────────────────────────────
export function CellNode({ cellNode, fallbackText = '' }) {
  if (!cellNode) return <>{fallbackText}</>;
  const children = cellNode.children || [];
  if (!children.length) {
    const txt = fallbackText || getCellText(cellNode) || '';
    const imgs = (cellNode.images || []).filter(Boolean);
    return (
      <>
        {txt}
        {imgs.map((url, i) => <ImgBox key={i} url={url} style={{ marginTop: 4 }} />)}
      </>
    );
  }

  return (
    <>
      {children.map((ch, i) => {
        if (!ch) return null;
        if (ch.type === 'paragraph') {
          const txt = ch.content?.text_display ?? ch.content?.text ?? '';
          const imgs = (ch.children || []).filter(c => c?.type === 'image');
          return (
            <div key={i}>
              {txt}
              {imgs.map((img, ii) => {
                const url = img.image_url || img.image?.image_url || img.content?.image_url;
                return <ImgBox key={ii} url={url} style={{ marginTop: 4 }} />;
              })}
            </div>
          );
        }
        if (ch.type === 'image') {
          const url = ch.image_url || ch.image?.image_url || ch.content?.image_url;
          return <ImgBox key={i} url={url} style={{ marginTop: 4 }} />;
        }
        if (ch.type === 'table') {
          return <NestedTable key={i} tableNode={ch} />;
        }
        return null;
      })}
    </>
  );
}

// ── Cell content WITH diff ────────────────────────────────────
export function CellContent({ cellChange, side, fallback = '', cellNode = null }) {
  if (!cellChange) return <>{fallback}</>;

  const changes = cellChange.changes || [];

  // span_changed: just pick first paragraph_modified
  if (cellChange.type === 'table_cell_span_changed') {
    for (const ch of changes) {
      if (ch.type === 'paragraph_modified') {
        return <WordDiff wd={ch} side={side} />;
      }
    }
    const txt = side === 'left' ? (cellChange.left_text || '') : (cellChange.right_text || '');
    return <>{txt}</>;
  }

  const parts = [];

  for (const ch of changes) {
    const chType = ch.type || '';

    if (chType === 'paragraph_container_modified') {
      for (const ic of (ch.changes || [])) {
        if (ic.type === 'paragraph_modified') {
          parts.push(<div key={parts.length}><WordDiff wd={ic} side={side} /></div>);
          const paraNode = side === 'left' ? ic.original : ic.modified;
          if (paraNode) {
            (paraNode.children || []).forEach((child, ci) => {
              if (child?.type === 'image') {
                const url = child.image_url || child.image?.image_url || child.content?.image_url;
                if (url) parts.push(<ImgBox key={`${parts.length}-${ci}`} url={url} style={{ marginTop: 4 }} />);
              }
            });
          }
        } else if (ic.type === 'paragraph_inserted' && side === 'right') {
          const txt = ic.modified?.content?.text || '';
          if (txt) parts.push(<div key={parts.length}><span className="ins-span">{txt}</span></div>);
          getCellImages(ic.modified).forEach((url, i) =>
            parts.push(<ImgBox key={`ins-${i}`} url={url} style={{ marginTop: 4 }} />));
        } else if (ic.type === 'paragraph_deleted' && side === 'left') {
          const txt = ic.original?.content?.text || '';
          if (txt) parts.push(<div key={parts.length}><span className="del-span">{txt}</span></div>);
          getCellImages(ic.original).forEach((url, i) =>
            parts.push(<ImgBox key={`del-${i}`} url={url} style={{ marginTop: 4, opacity: 0.5 }} />));
        } else if (ic.type === 'image_unchanged') {
          const url = ic.image?.image_url || ic.image?.image?.image_url;
          if (url) parts.push(<ImgBox key={parts.length} url={url} style={{ marginTop: 4 }} />);
        }
      }
      continue;
    }

    if (chType === 'paragraph_unchanged') {
      const paraNode = side === 'left' ? ch.original : ch.modified;
      if (paraNode) {
        const txt = paraNode.content?.text_display ?? paraNode.content?.text ?? '';
        if (txt) parts.push(<div key={parts.length}>{txt}</div>);
        (paraNode.children || []).forEach((child, ci) => {
          if (child?.type === 'image') {
            const url = child.image_url || child.image?.image_url || child.content?.image_url;
            if (url) parts.push(<ImgBox key={`pu-${ci}`} url={url} style={{ marginTop: 4 }} />);
          }
        });
      }
      continue;
    }

    if (chType === 'image_unchanged') {
      const url = ch.image?.image_url || ch.image?.image?.image_url;
      if (url) parts.push(<ImgBox key={parts.length} url={url} style={{ marginTop: 4 }} />);
      continue;
    }

    if (chType === 'paragraph_modified') {
      parts.push(<div key={parts.length}><WordDiff wd={ch} side={side} /></div>);
      const paraNode = side === 'left' ? ch.original : ch.modified;
      if (paraNode) {
        (paraNode.children || []).forEach((child, ci) => {
          if (child?.type === 'image') {
            const url = child.image_url || child.image?.image_url || child.content?.image_url;
            if (url) parts.push(<ImgBox key={`pm-${ci}`} url={url} style={{ marginTop: 4 }} />);
          }
        });
      }
      continue;
    }

    if (chType === 'paragraph_inserted' && side === 'right') {
      const txt = ch.modified?.content?.text_display ?? ch.modified?.content?.text ?? '';
      if (txt) parts.push(<div key={parts.length}><span className="ins-span">{txt}</span></div>);
      getCellImages(ch.modified).forEach((url, i) =>
        parts.push(<ImgBox key={`pi-${i}`} url={url} style={{ marginTop: 4 }} />));
      continue;
    }

    if (chType === 'paragraph_deleted' && side === 'left') {
      const txt = ch.original?.content?.text_display ?? ch.original?.content?.text ?? '';
      if (txt) parts.push(<div key={parts.length}><span className="del-span">{txt}</span></div>);
      getCellImages(ch.original).forEach((url, i) =>
        parts.push(<ImgBox key={`pd-${i}`} url={url} style={{ marginTop: 4, opacity: 0.5 }} />));
      continue;
    }

    if (chType === 'nested_table_inserted' && side === 'right') {
      parts.push(
        <div key={parts.length}>
          <span className="nested-tbl-badge ins-badge">+ Nested table</span>
          <NestedTable tableNode={ch.modified} wrapClass="nested-ins" />
        </div>
      );
      continue;
    }

    if (chType === 'nested_table_deleted' && side === 'left') {
      parts.push(
        <div key={parts.length}>
          <span className="nested-tbl-badge del-badge">- Nested table</span>
          <NestedTable tableNode={ch.original} wrapClass="nested-del" />
        </div>
      );
      continue;
    }

    if (chType === 'nested_table_modified') {
      const node = side === 'left' ? ch.original : ch.modified;
      parts.push(
        <div key={parts.length}>
          <span className="nested-tbl-badge mod-badge">≈ Nested table (sửa)</span>
          <NestedTableWithDiff tableNode={node} side={side} nestedChanges={ch.changes || []} />
        </div>
      );
      continue;
    }

    if (chType === 'nested_table_unchanged') {
      const node = ch.original || ch.modified;
      parts.push(
        <div key={parts.length}>
          <span className="nested-tbl-badge eq-badge">= Nested table</span>
          <NestedTable tableNode={node} wrapClass="nested-eq" />
        </div>
      );
      continue;
    }
  }

  if (!parts.length) {
    return <CellNode cellNode={cellNode} fallbackText={fallback} />;
  }
  return <>{parts}</>;
}
