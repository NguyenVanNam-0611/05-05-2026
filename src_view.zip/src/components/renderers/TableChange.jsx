// ─────────────────────────────────────────────────────────────
// renderers/TableChange.jsx
// ─────────────────────────────────────────────────────────────
import { getCellText, getAllCellImages, nodeToTableData } from '../../utils/diffHelpers';
import { ImgBox } from '../WordDiff';
import { CellContent, CellNode } from '../CellContent';

// ── Full table view ───────────────────────────────────────────
function FullTable({ tableData, label, tableChanges = [], structureChanged = false }) {
    if (!tableData) return <div className="empty-hint" style={{ padding: 8 }}>(không có)</div>;

    const side = label === 'before' ? 'left' : 'right';
    const rows = tableData.rows || tableData.all_cells || [];

    const addedSet = new Set();
    const deletedSet = new Set();
    const modifiedSet = new Set();
    const cellChangeMap = {};
    const deletedColsPerRow = {};
    const addedColsPerRow = {};

    // Luôn build row sets để highlight dù structure thay đổi
    tableChanges.forEach(c => {
        const ri = c.row_index;
        if (c.type === 'table_row_deleted' && label === 'before') deletedSet.add(ri);
        if (c.type === 'table_row_added' && label === 'after') addedSet.add(ri);
        if (c.type === 'table_row_modified') modifiedSet.add(ri);
    });

    // Chỉ build cell-level diff khi structure không thay đổi
    if (!structureChanged) {
        tableChanges.forEach(rc => {
            if (rc.type !== 'table_row_modified') return;
            const ri = rc.row_index;
            (rc.cell_changes || []).forEach(cc => {
                if (cc.type === 'table_cell_modified' || cc.type === 'table_cell_span_changed') {
                    if (!cellChangeMap[ri]) cellChangeMap[ri] = {};
                    cellChangeMap[ri][cc.col_index] = cc;
                }
                if (cc.type === 'table_cell_deleted') {
                    if (!deletedColsPerRow[ri]) deletedColsPerRow[ri] = new Set();
                    deletedColsPerRow[ri].add(cc.col_index);
                }
                if (cc.type === 'table_cell_added') {
                    if (!addedColsPerRow[ri]) addedColsPerRow[ri] = new Set();
                    addedColsPerRow[ri].add(cc.col_index);
                }
            });
        });
    }

    return (
        <div className="tbl-wrap">
            <table className="doc-table">
                <tbody>
                    {rows.map((rowData, arrayIdx) => {
                        const cells = rowData.cells || rowData || [];
                        const ri = rowData.row_index != null ? Number(rowData.row_index) : arrayIdx;

                        const rCls =
                            addedSet.has(ri) ? 'row-added' :
                                deletedSet.has(ri) ? 'row-deleted' :
                                    modifiedSet.has(ri) ? 'row-modified' : '';

                        let gridPos = 0;
                        const tds = cells
                            .filter(cell => {
                                if (!cell) return false;
                                const colIdx = cell.col_index != null ? Number(cell.col_index) : 0;
                                return colIdx >= gridPos;
                            })
                            .map((cell, ci) => {
                                const colIdx = cell.col_index != null ? Number(cell.col_index) : ci;
                                const cSpan = cell.col_span > 1 ? cell.col_span : undefined;
                                const rSpan = cell.row_span > 1 ? cell.row_span : undefined;
                                const key = `${ri}_${colIdx}`;
                                const cc = cellChangeMap[ri]?.[colIdx];

                                let cellCls = '';
                                if (cc) {
                                    cellCls = 'cell-changed';
                                } else if (label === 'before' && deletedColsPerRow[ri]?.has(colIdx)) {
                                    cellCls = 'cell-deleted';
                                } else if (label === 'after' && addedColsPerRow[ri]?.has(colIdx)) {
                                    cellCls = 'cell-added';
                                }

                                gridPos = colIdx + (cell.col_span > 1 ? Number(cell.col_span) : 1);

                                return (
                                    <td key={key} className={cellCls} colSpan={cSpan} rowSpan={rSpan}>
                                        {cc
                                            ? <CellContent cellChange={cc} side={side} fallback={getCellText(cell)} cellNode={cell} />
                                            : <CellNode cellNode={cell} fallbackText={getCellText(cell)} />
                                        }
                                    </td>
                                );
                            });

                        return <tr key={ri} className={rCls}>{tds}</tr>;
                    })}
                </tbody>
            </table>
        </div>
    );
}

// ── Row-level view (modified / added / deleted / merged) ──────
function RowModifiedView({ tableChanges }) {
    if (!tableChanges.length) return null;

    return (
        <div className="sub-rows-wrap">
            {tableChanges.map((rc, idx) => {
                const type = rc.type || '';
                let leftContent = null;
                let rightContent = null;

                if (type === 'table_row_modified') {
                    const leftCells = rc.left_display_cells ?? rc.left_cells ?? [];
                    const rightCells = rc.right_display_cells ?? rc.right_cells ?? [];

                    const cellChangeMap = {};
                    const deletedCols = new Set();
                    const addedCols = new Set();
                    (rc.cell_changes || []).forEach(cc => {
                        if (cc.type === 'table_cell_modified' || cc.type === 'table_cell_span_changed')
                            cellChangeMap[cc.col_index] = cc;
                        else if (cc.type === 'table_cell_deleted') deletedCols.add(cc.col_index);
                        else if (cc.type === 'table_cell_added') addedCols.add(cc.col_index);
                    });

                    const renderRowCells = (cells, side) => cells
                        .filter(c => c && c.type !== 'cell_span_continuation')
                        .map((c, i) => {
                            const ci = c.col_index != null ? Number(c.col_index) : i;
                            const cc = cellChangeMap[ci];
                            const cSpan = c.col_span > 1 ? c.col_span : undefined;
                            const vCls = c.virtual_from_merge ? ' cell-virtual' : '';
                            let chCls = '';
                            if (cc) chCls = ' cell-changed';
                            else if (side === 'left' && deletedCols.has(ci)) chCls = ' cell-deleted';
                            else if (side === 'right' && addedCols.has(ci)) chCls = ' cell-added';
                            const fallback = c.text_display ?? c.text ?? '';
                            const fullCell = cc ? (side === 'left' ? cc.left_cell : cc.right_cell) : null;
                            const extraImgs = getAllCellImages(fullCell || c);

                            return (
                                <td key={ci} className={`${chCls}${vCls}`} colSpan={cSpan}>
                                    {cc
                                        ? <CellContent cellChange={cc} side={side} fallback={fallback} cellNode={fullCell || c} />
                                        : <CellNode cellNode={c} fallbackText={fallback} />
                                    }
                                    {extraImgs.map((url, ii) => <ImgBox key={`ei-${ii}`} url={url} style={{ marginTop: 4 }} />)}
                                </td>
                            );
                        });

                    leftContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#b45309' }}>≈ Dòng sửa (gốc)</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody><tr>{renderRowCells(leftCells, 'left')}</tr></tbody>
                                </table>
                            </div>
                        </>
                    );
                    rightContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>≈ Dòng sửa (mới)</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody><tr>{renderRowCells(rightCells, 'right')}</tr></tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_added') {
                    const cells = rc.right_display_cells ?? rc.right_cells ?? [];
                    rightContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>+ Dòng mới</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        <tr className="row-added">
                                            {cells
                                                .filter(c => c && c.type !== 'cell_span_continuation')
                                                .map((c, i) => (
                                                    <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                                        <CellNode cellNode={c} fallbackText="" />
                                                    </td>
                                                ))}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_deleted') {
                    const cells = rc.left_display_cells ?? rc.left_cells ?? [];
                    leftContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#dc2626' }}>- Dòng xóa</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        <tr className="row-deleted">
                                            {cells
                                                .filter(c => c && c.type !== 'cell_span_continuation')
                                                .map((c, i) => (
                                                    <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                                        <CellNode cellNode={c} fallbackText="" />
                                                    </td>
                                                ))}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_merged') {
                    const mergedFrom = rc.merged_from_rows || [];
                    const rightCells = rc.right_display_cells ?? rc.right_cells ?? [];

                    leftContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#b45309' }}>
                                ⊕ Gộp ({rc.merged_from_count || mergedFrom.length} → 1)
                            </div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        {mergedFrom.map((r, ri) => (
                                            <tr key={ri} className="row-deleted">
                                                {(r.cells || []).map((c, ci) => (
                                                    <td key={ci} colSpan={c?.col_span > 1 ? c.col_span : undefined}>
                                                        <CellNode cellNode={c} fallbackText="" />
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );

                    rightContent = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>⊕ Sau khi gộp</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        <tr className="row-modified">
                                            {rightCells
                                                .filter(c => c && c.type !== 'cell_span_continuation')
                                                .map((c, i) => {
                                                    const ci = c.col_index ?? i;
                                                    const cc = (rc.cell_changes || []).find(x => x.col_index === ci);
                                                    const vCls = c.virtual_from_merge ? ' cell-virtual' : '';
                                                    return (
                                                        <td key={i} className={vCls} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                                            {cc
                                                                ? <CellContent cellChange={cc} side="right" fallback={getCellText(c)} cellNode={c} />
                                                                : <CellNode cellNode={c} fallbackText="" />
                                                            }
                                                        </td>
                                                    );
                                                })}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                return (
                    <div key={idx} className="sub-row">
                        <div className="sub-cell sub-left">{leftContent}</div>
                        <div className="sub-cell">{rightContent}</div>
                    </div>
                );
            })}
        </div>
    );
}

// ── Main export ───────────────────────────────────────────────
export function TableChange({ change }) {
    const analysis = change.table_analysis || {};
    const tableChanges = change.table_changes || analysis.table_changes || [];
    const renderMode = analysis.render_mode || 'full_table';
    const kind = change.change_kind || 'replace';
    const structChanged = !!analysis.structure_changed;

    // Ưu tiên table_analysis nếu có, fallback về node tree
    const leftTableData = analysis.full_table_original ?? nodeToTableData(change.left?.node);
    const rightTableData = analysis.full_table_modified ?? nodeToTableData(change.right?.node);

    // ── Deleted table
    if (kind === 'delete' || renderMode === 'table_deleted') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable tableData={leftTableData} label="before" />
                    </div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="empty-hint" style={{ padding: 10 }}>(đã xóa)</div>
                </div>
            </>
        );
    }

    // ── Inserted table
    if (kind === 'insert') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="empty-hint" style={{ padding: 10 }}>(chưa tồn tại)</div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable tableData={rightTableData} label="after" />
                    </div>
                </div>
            </>
        );
    }

    // ── Full table side-by-side
    if (renderMode === 'full_table') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable
                            tableData={leftTableData}
                            label="before"
                            tableChanges={tableChanges}
                            structureChanged={structChanged}
                        />
                    </div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable
                            tableData={rightTableData}
                            label="after"
                            tableChanges={tableChanges}
                            structureChanged={structChanged}
                        />
                    </div>
                </div>
            </>
        );
    }

    // ── Row-added only
    if (renderMode === 'row_added') {
        const headerRow = analysis.header_row;
        const addedRows = analysis.added_rows || [];
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="empty-hint" style={{ padding: 8 }}>Không có dòng mới ở bên gốc.</div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <div className="tbl-label" style={{ color: '#16a34a' }}>▼ Dòng được thêm</div>
                        <div className="tbl-wrap">
                            <table className="doc-table">
                                <tbody>
                                    {headerRow && (
                                        <tr>
                                            {(headerRow.cells || []).map((c, i) => (
                                                <th key={i}>{getCellText(c)}</th>
                                            ))}
                                        </tr>
                                    )}
                                    {addedRows.map((r, ri) => {
                                        const cells = r.right_display_cells ?? r.right_cells ?? r.right_row?.cells ?? [];
                                        return (
                                            <tr key={ri} className="row-added">
                                                {cells
                                                    .filter(c => c && c.type !== 'cell_span_continuation')
                                                    .map((c, ci) => (
                                                        <td
                                                            key={ci}
                                                            className={c.virtual_from_merge ? 'cell-virtual' : ''}
                                                            colSpan={c.col_span > 1 ? c.col_span : undefined}
                                                        >
                                                            <CellNode cellNode={c} fallbackText="" />
                                                        </td>
                                                    ))}
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </>
        );
    }

    // ── row_modified / row_deleted / row_merged / mixed
    return (
        <div style={{ display: 'block', width: '100%' }}>
            <RowModifiedView tableChanges={tableChanges} />
        </div>
    );
}
