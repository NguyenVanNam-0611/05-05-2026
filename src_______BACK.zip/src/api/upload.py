"""
api/upload.py
~~~~~~~~~~~~~
POST /upload — nhận 2 file .doc/.docx, tạo job, enqueue, schedule cleanup.

Fixes so với cũ:
1. RACE CONDITION — nếu lưu file thứ 2 thất bại, folder thứ 1 đã tạo
   nhưng không có cleanup job → leak disk vĩnh viễn.
   FIX: bọc toàn bộ _save_file trong try/except, xóa folder đã tạo nếu lỗi.

2. FILE SIZE — không có giới hạn, user có thể upload file 500MB.
   FIX: thêm MAX_UPLOAD_BYTES, check trước khi ghi disk.

3. SYNC IO trên async context — file_path.write_bytes() là sync, block event loop.
   FIX: dùng asyncio.to_thread() để ghi file trong thread pool.

4. UPLOAD_BASE dùng os.getcwd() — không stable khi deploy với Docker/systemd.
   FIX: đọc từ env var UPLOAD_DIR, fallback về "./uploads".

5. USERNAME không được validate — path traversal risk.
   FIX: whitelist regex, reject nếu không hợp lệ.

6. DB không được tự động clear — record tích tụ mãi.
   FIX: thêm scheduled job chạy mỗi 24h, purge record cũ hơn 24h đã xóa file.
        Job được persist vào SQLite jobstore → tự chạy bù sau khi server restart.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore

from src.core.jobs import create_job, mark_job_files_deleted, purge_old_jobs
from src.core.queue import enqueue_job
from src.services.word_converter import convert_doc_to_docx_if_needed

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Upload"])

# ── Constants ─────────────────────────────────────────────────────────────────

ALLOWED_EXTENSIONS = {".doc", ".docx"}

# Đọc từ env var — stable qua Docker, systemd, v.v.
UPLOAD_BASE = Path(os.environ.get("UPLOAD_DIR", "uploads")).resolve()

# 50 MB per file
MAX_UPLOAD_BYTES = 50 * 1024 * 1024

# Username: chỉ cho phép ký tự an toàn, tránh path traversal
_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")

# ── Scheduler ─────────────────────────────────────────────────────────────────

_jobstore_path = Path("data/scheduler.db")
_jobstore_path.parent.mkdir(parents=True, exist_ok=True)

scheduler = AsyncIOScheduler(
    jobstores={
        "default": SQLAlchemyJobStore(url=f"sqlite:///{_jobstore_path}")
    },
    timezone="UTC",
)


def _purge_old_jobs_task() -> None:
    """
    Xóa record DB của các job cũ hơn 24h đã done/error và files_deleted=1.
    Chạy định kỳ mỗi 24h, được persist vào SQLite jobstore.
    Nếu server tắt đúng lúc cần chạy → misfire_grace_time=3600 đảm bảo
    chạy bù trong vòng 1h sau khi restart.
    """
    deleted = purge_old_jobs(older_than_hours=24)
    if deleted:
        logger.info(f"[PURGE] Deleted {deleted} old job record(s) from DB")
    else:
        logger.debug("[PURGE] No old job records to delete")


def start_scheduler() -> None:
    if not scheduler.running:
        scheduler.start()

        # Purge DB job — chạy mỗi 24h, persist qua restart
        scheduler.add_job(
            _purge_old_jobs_task,
            trigger="interval",
            hours=24,
            id="purge_old_jobs",
            replace_existing=True,
            misfire_grace_time=3600,  # chạy bù trong vòng 1h nếu bị miss
        )

        logger.info("[SCHEDULER] Started with SQLite jobstore")


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("[SCHEDULER] Stopped")


# ── Cleanup job (chạy trong APScheduler thread pool) ─────────────────────────

def delete_upload_files(job_id: str, folders: list[str]) -> None:
    for folder in folders:
        try:
            p = Path(folder)
            if p.exists():
                shutil.rmtree(p)
                logger.info(f"[CLEANUP] Deleted: {folder}")
            else:
                logger.warning(f"[CLEANUP] Already gone: {folder}")
        except Exception as e:
            logger.error(f"[CLEANUP] Failed to delete {folder}: {e}")

    try:
        mark_job_files_deleted(job_id)
    except Exception as e:
        logger.error(f"[CLEANUP] Failed to update DB for job {job_id}: {e}")


def schedule_cleanup(job_id: str, folders: list[Path]) -> None:
    run_at = datetime.now(timezone.utc) + timedelta(hours=24)
    scheduler.add_job(
        delete_upload_files,
        trigger="date",
        run_date=run_at,
        args=[job_id, [str(f) for f in folders]],
        id=f"cleanup_{job_id}",
        replace_existing=True,
        misfire_grace_time=None,
    )
    logger.info(f"[CLEANUP] Scheduled for job {job_id} at {run_at.isoformat()}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _validate_username(username: str) -> None:
    """
    Whitelist username — chỉ cho phép ký tự an toàn.
    Chặn path traversal kiểu '../', absolute path, ký tự đặc biệt.
    """
    if not _USERNAME_RE.match(username):
        raise HTTPException(
            status_code=400,
            detail="Invalid username. Only letters, digits, hyphens, and underscores are allowed (max 64 chars).",
        )


def _validate_file(file: UploadFile) -> str:
    """Kiểm tra extension và sanitize filename. Trả về safe filename."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="Filename is required")

    safe_name = Path(file.filename).name  # loại bỏ path traversal
    ext = Path(safe_name).suffix.lower()

    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type '{ext}'. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
        )

    return safe_name


async def _read_and_check_size(file: UploadFile) -> bytes:
    """
    Đọc toàn bộ file vào memory, kiểm tra size.
    Raise 413 nếu vượt quá MAX_UPLOAD_BYTES.
    """
    content = await file.read()
    if len(content) > MAX_UPLOAD_BYTES:
        mb = MAX_UPLOAD_BYTES // (1024 * 1024)
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum allowed size is {mb} MB.",
        )
    return content


async def _save_file(
    content: bytes,
    safe_filename: str,
    username: str,
    mode: str,
    date: str,
) -> tuple[Path, str, str, Path]:
    """
    Ghi file xuống disk trong thread pool (không block event loop).
    Returns: (file_path, folder_name, stem, folder_path)
    """
    stem = Path(safe_filename).stem
    ts   = datetime.now(timezone.utc).strftime("%H%M%S")
    folder_name = f"{stem}_{ts}"

    folder    = UPLOAD_BASE / date / username / mode / folder_name
    file_path = folder / safe_filename

    def _write() -> None:
        folder.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(content)

    await asyncio.to_thread(_write)

    return file_path, folder_name, stem, folder


def _cleanup_folders(*folders: Path | None) -> None:
    """Xóa các folder đã tạo khi upload thất bại giữa chừng."""
    for folder in folders:
        if folder is None:
            continue
        try:
            if folder.exists():
                shutil.rmtree(folder)
                logger.info(f"[UPLOAD] Rolled back folder: {folder}")
        except Exception as e:
            logger.error(f"[UPLOAD] Rollback failed for {folder}: {e}")


# ── Route ─────────────────────────────────────────────────────────────────────

@router.post("/upload")
async def upload_pair(
    username: str = Form(...),
    originalFile: UploadFile = File(...),
    modifiedFile: UploadFile = File(...),
):
    # 1. Validate username — phải làm trước khi dùng trong path
    _validate_username(username)

    # 2. Validate filename + extension (trước khi đọc nội dung)
    original_safe_name = _validate_file(originalFile)
    modified_safe_name = _validate_file(modifiedFile)

    # 3. Đọc nội dung + check size (async, không block)
    original_content = await _read_and_check_size(originalFile)
    modified_content = await _read_and_check_size(modifiedFile)

    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # 4. Lưu file — rollback nếu bất kỳ bước nào thất bại
    o_folder: Path | None = None
    m_folder: Path | None = None

    try:
        o_path, o_folder_name, o_stem, o_folder = await _save_file(
            original_content, original_safe_name, username, "original", date
        )
        m_path, m_folder_name, m_stem, m_folder = await _save_file(
            modified_content, modified_safe_name, username, "modified", date
        )
    except HTTPException:
        _cleanup_folders(o_folder, m_folder)
        raise
    except Exception:
        _cleanup_folders(o_folder, m_folder)
        raise HTTPException(status_code=500, detail="Failed to save uploaded files")

    # 5. Convert .doc → .docx nếu cần (sync → chạy trong thread pool)
    try:
        o_path = await asyncio.to_thread(convert_doc_to_docx_if_needed, o_path)
        m_path = await asyncio.to_thread(convert_doc_to_docx_if_needed, m_path)
    except Exception as e:
        _cleanup_folders(o_folder, m_folder)
        raise HTTPException(status_code=500, detail=f"Failed to convert file: {e}")

    # 6. Tạo job trong DB (sync SQLite → thread pool)
    job_id  = uuid.uuid4().hex
    now_utc = datetime.now(timezone.utc)

    try:
        await asyncio.to_thread(
            create_job,
            job_id=job_id,
            username=username,
            original_path=str(o_path),
            modified_path=str(m_path),
            date=date,
            original_file_name=o_stem,
            modified_file_name=m_stem,
            original_folder_name=o_folder_name,
            modified_folder_name=m_folder_name,
            created_at=now_utc.replace(microsecond=0).isoformat(),
        )
    except Exception as e:
        _cleanup_folders(o_folder, m_folder)
        raise HTTPException(status_code=500, detail=f"Failed to create job: {e}")

    # 7. Enqueue + schedule cleanup
    await enqueue_job(job_id)
    schedule_cleanup(job_id, folders=[o_folder, m_folder])

    expire_at = (now_utc + timedelta(hours=24)).replace(microsecond=0).isoformat()

    return {
        "job_id":          job_id,
        "status":          "queued",
        "status_url":      f"/api/status/job/{job_id}",
        "files_expire_at": expire_at,
    }