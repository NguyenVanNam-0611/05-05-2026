# src/services/diff/image_diff.py
"""
So sánh và serialize image nodes.

Fix so với cũ:
  - images_equal: dùng 2 tầng so sánh từ utils.hash
      Tầng 1 — sha256 byte-exact (từ content, không cần raw bytes)
      Tầng 2 — perceptual hash qua images_changed() nếu có raw_bytes
    Fallback conservative (False) khi không đủ dữ liệu.
  - _image_payload: thêm guard type check để tránh serialize nhầm node khác.
  - build_image_change: thêm guard kiểm tra type trước khi gọi payload.
  - _image_payload: thêm field floating (True = anchor, False = inline)
    để frontend biết loại ảnh — forward-compat với image.py mới.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from src.services.models.docnode import DocNode
from src.services.utils.hash import images_changed


def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a.type != "image" or b.type != "image":
        return False

    # ── Tầng 1: sha256 byte-exact từ content ─────────────────────────────────
    # Nhanh, không cần decode ảnh, stable tuyệt đối.
    a_hash = a.content.get("sha256") or a.content.get("hash")
    b_hash = b.content.get("sha256") or b.content.get("hash")

    if a_hash and b_hash:
        if a_hash == b_hash:
            return True
        # sha256 khác → thử tầng 2 nếu có raw bytes

    # ── Tầng 2: perceptual hash qua hash.py ──────────────────────────────────
    # Bỏ qua resize nhỏ và minor JPEG compression — tránh false positive.
    # Chỉ chạy khi extractor lưu raw_bytes vào content.
    a_bytes = a.content.get("raw_bytes")
    b_bytes = b.content.get("raw_bytes")

    if a_bytes and b_bytes:
        return not images_changed(a_bytes, b_bytes)

    # Không đủ dữ liệu để so sánh chính xác → conservative.
    # Trả False để frontend luôn hiển thị diff — người dùng tự verify.
    #
    # Lý do không fallback về kích thước + tên:
    #   Nhiều ảnh placeholder trong template docx cùng kích thước, không có name
    #   → fallback sẽ trả True (false positive) → ảnh thực sự thay đổi không được báo.
    return False


def _image_payload(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    """
    Serialize image node thành payload đầy đủ cho frontend render.

    Guard: chỉ serialize node có type="image". Nếu caller truyền nhầm
    node khác, trả None thay vì serialize ra payload sai type.
    """
    if node is None:
        return None
    if node.type != "image":
        return None

    content = node.content or {}

    width_emu  = content.get("width_emu")  or 0
    height_emu = content.get("height_emu") or 0

    # Quy đổi EMU → pixel (1 inch = 914400 EMU, 96 dpi)
    px_per_emu = 96 / 914400
    width_px   = round(width_emu  * px_per_emu) if width_emu  else content.get("width")
    height_px  = round(height_emu * px_per_emu) if height_emu else content.get("height")

    return {
        "uid":          getattr(node, "uid",   None),
        "type":         "image",
        "display_type": "image",
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  ""),
        "image": {
            # Identifiers
            "name":       content.get("name"),
            "ext":        content.get("ext"),
            "hash":       content.get("hash"),
            "sha256":     content.get("sha256"),
            # Kích thước
            "width_emu":  width_emu,
            "height_emu": height_emu,
            "width_px":   width_px,
            "height_px":  height_px,
            # Data URI để frontend render trực tiếp — không cần thêm request
            "data_uri":   content.get("data_uri"),
            # Metadata phụ
            "mime":       content.get("mime"),
            "rid":        content.get("rid"),
            # floating=True  → wp:anchor (Win32com convert từ .doc)
            # floating=False → wp:inline (native docx / LibreOffice convert)
            # floating=None  → node cũ chưa có field này, treat như inline
            "floating":   content.get("floating", False),
        },
        "text":    content.get("text",    ""),
        "caption": content.get("caption", ""),
        # data_uri bubble lên top-level để dễ access hơn
        "data_uri": content.get("data_uri"),
    }


def build_image_change(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """
    Tạo change object cho image.

    Naming thống nhất:
      left  = original (bên trái trong side-by-side view)
      right = modified (bên phải trong side-by-side view)

    Frontend dùng:
      left_img.data_uri  để render ảnh gốc
      right_img.data_uri để render ảnh mới
      change_kind        để biết insert/delete/replace
    """
    left_payload  = _image_payload(a)
    right_payload = _image_payload(b)

    # ── IMAGE DELETED ─────────────────────────────────────────────────────────
    if a is not None and b is None:
        return {
            "type":         "image_deleted",
            "display_type": "image",
            "change_kind":  "delete",
            "left":         left_payload,
            "right":        None,
            "left_img":     left_payload,
            "right_img":    None,
        }

    # ── IMAGE ADDED ───────────────────────────────────────────────────────────
    if b is not None and a is None:
        return {
            "type":         "image_added",
            "display_type": "image",
            "change_kind":  "insert",
            "left":         None,
            "right":        right_payload,
            "left_img":     None,
            "right_img":    right_payload,
        }

    # ── IMAGE MODIFIED (cả 2 đều có, khác nhau) ───────────────────────────────
    return {
        "type":         "image_modified",
        "display_type": "image",
        "change_kind":  "replace",
        "left":         left_payload,
        "right":        right_payload,
        "left_img":     left_payload,
        "right_img":    right_payload,
    }