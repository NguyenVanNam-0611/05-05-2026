"""
extractor/image.py
~~~~~~~~~~~~~~~~~~
Extract ảnh từ một Paragraph.

Xử lý:
    ✅ Ảnh inline  (<wp:inline>) — nằm trong dòng chữ
    ✅ Ảnh anchor  (<wp:anchor>) có a:blip — floating image (Win32com convert từ .doc)
    ✅ Ảnh inline trong cell (table.py gọi hàm này cho mỗi paragraph trong cell)

Không xử lý:
    ❌ Ảnh anchor không có a:blip — đây là shape/textbox, không phải ảnh
    ❌ Ảnh trong header / footer

Lý do mở rộng sang anchor:
    Win32com khi convert .doc → .docx thường render ảnh floating thành wp:anchor,
    trong khi LibreOffice/Word native thường tạo wp:inline.
    Điều kiện lọc ảnh thật vs shape: a:blip có r:embed hay không —
    nếu không có blip thì dù inline hay anchor đều là shape, bỏ qua.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from docx.text.paragraph import Paragraph
from lxml import etree

from src.services.models.docnode import DocNode
from src.services.extractor.utils import OrderRef, next_order
from src.services.utils.hash import bytes_to_data_uri, safe_sha256

# ── Namespaces ────────────────────────────────────────────────────────────────

_NS: Dict[str, str] = {
    "a":  "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r":  "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "w":  "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "v":  "urn:schemas-microsoft-com:vml",
    "o":  "urn:schemas-microsoft-com:office:office",
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _pure(elm):
    """
    Chuyển BaseOxmlElement về lxml element thuần.
    python-docx 1.2.0 override .xpath() và không nhận tham số 'namespaces'
    nên phải serialize → parse lại để bypass.
    """
    return etree.fromstring(etree.tostring(elm))


def _get_image_size(drawing_elm) -> tuple[int, int]:
    """
    Lấy kích thước ảnh (width, height) tính bằng EMU từ wp:extent.
    Thử wp:inline trước, fallback sang wp:anchor.
    """
    extents = drawing_elm.xpath(".//wp:inline/wp:extent", namespaces=_NS)
    if not extents:
        extents = drawing_elm.xpath(".//wp:anchor/wp:extent", namespaces=_NS)
    if not extents:
        return 0, 0
    ext = extents[0]
    return _emu_to_int(ext.get("cx")), _emu_to_int(ext.get("cy"))


def _get_alt_text(drawing_elm) -> str:
    """
    Lấy alt text từ wp:docPr descr hoặc title.
    Thử wp:inline trước, fallback sang wp:anchor.
    """
    doc_prs = drawing_elm.xpath(".//wp:inline/wp:docPr", namespaces=_NS)
    if not doc_prs:
        doc_prs = drawing_elm.xpath(".//wp:anchor/wp:docPr", namespaces=_NS)
    if not doc_prs:
        return ""
    doc_pr = doc_prs[0]
    return doc_pr.get("descr") or doc_pr.get("title") or ""


def _is_anchor(drawing_elm) -> bool:
    """Trả True nếu drawing là wp:anchor (floating)."""
    return bool(drawing_elm.xpath("wp:anchor", namespaces=_NS))


def _parse_vml_size(style: str) -> tuple[int, int]:
    """
    Parse "width:344.25pt;height:87pt" → (width_emu, height_emu).
    1 pt = 12700 EMU.
    """
    PT_TO_EMU = 12700
    width_emu = height_emu = 0
    for part in style.split(";"):
        part = part.strip()
        if part.startswith("width:"):
            val = part[6:].replace("pt", "").strip()
            try:
                width_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
        elif part.startswith("height:"):
            val = part[7:].replace("pt", "").strip()
            try:
                height_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
    return width_emu, height_emu


def _convert_emf_to_png(blob: bytes) -> Optional[bytes]:
    try:
        import tempfile, os, io, time, ctypes
        from ctypes import wintypes
        from PIL import Image

        gdi32  = ctypes.windll.gdi32
        user32 = ctypes.windll.user32

        with tempfile.NamedTemporaryFile(suffix=".emf", delete=False) as f:
            f.write(blob)
            emf_path = f.name

        hemf = None
        try:
            hemf = gdi32.GetEnhMetaFileW(emf_path)
            if not hemf:
                raise RuntimeError("GetEnhMetaFileW failed")

            class ENHMETAHEADER(ctypes.Structure):
                _fields_ = [
                    ("iType",          ctypes.c_uint),
                    ("nSize",          ctypes.c_uint),
                    ("rclBounds",      ctypes.c_long * 4),
                    ("rclFrame",       ctypes.c_long * 4),
                    ("dSignature",     ctypes.c_uint),
                    ("nVersion",       ctypes.c_uint),
                    ("nBytes",         ctypes.c_uint),
                    ("nRecords",       ctypes.c_uint),
                    ("nHandles",       ctypes.c_ushort),
                    ("sReserved",      ctypes.c_ushort),
                    ("nDescription",   ctypes.c_uint),
                    ("offDescription", ctypes.c_uint),
                    ("nPalEntries",    ctypes.c_uint),
                    ("szlDevice",      ctypes.c_long * 2),
                    ("szlMillimeters", ctypes.c_long * 2),
                ]

            header = ENHMETAHEADER()
            gdi32.GetEnhMetaFileHeader(hemf, ctypes.sizeof(header), ctypes.byref(header))

            w = max(header.rclBounds[2] - header.rclBounds[0], 1)
            h = max(header.rclBounds[3] - header.rclBounds[1], 1)
            if w <= 1 or h <= 1:
                w = max(int((header.rclFrame[2] - header.rclFrame[0]) * 96 / 2540), 100)
                h = max(int((header.rclFrame[3] - header.rclFrame[1]) * 96 / 2540), 100)

            hdc  = user32.GetDC(0)
            hmdc = gdi32.CreateCompatibleDC(hdc)
            hbmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
            gdi32.SelectObject(hmdc, hbmp)

            WHITE_BRUSH = 0
            hbrush = gdi32.GetStockObject(WHITE_BRUSH)
            rect   = (ctypes.c_long * 4)(0, 0, w, h)
            user32.FillRect(hmdc, rect, hbrush)

            rect2 = (ctypes.c_long * 4)(0, 0, w, h)
            gdi32.PlayEnhMetaFile(hmdc, hemf, rect2)

            class BITMAP(ctypes.Structure):
                _fields_ = [
                    ("bmType",       ctypes.c_long),
                    ("bmWidth",      ctypes.c_long),
                    ("bmHeight",     ctypes.c_long),
                    ("bmWidthBytes", ctypes.c_long),
                    ("bmPlanes",     ctypes.c_ushort),
                    ("bmBitsPixel",  ctypes.c_ushort),
                    ("bmBits",       ctypes.c_void_p),
                ]

            bmp = BITMAP()
            gdi32.GetObjectW(hbmp, ctypes.sizeof(bmp), ctypes.byref(bmp))
            bmpstr_size = bmp.bmWidthBytes * bmp.bmHeight
            bmpstr = (ctypes.c_char * bmpstr_size)()
            gdi32.GetBitmapBits(hbmp, bmpstr_size, bmpstr)

            img = Image.frombuffer(
                "RGB", (bmp.bmWidth, bmp.bmHeight),
                bytes(bmpstr), "raw", "BGRX", 0, 1
            )

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            result = buf.getvalue()
            return result

        finally:
            # ── Giải phóng GDI handle TRƯỚC khi xóa file ──
            if hemf:
                gdi32.DeleteEnhMetaFile(hemf)
            try:
                gdi32.DeleteObject(hbmp)
            except Exception:
                pass
            try:
                gdi32.DeleteDC(hmdc)
            except Exception:
                pass
            try:
                user32.ReleaseDC(0, hdc)
            except Exception:
                pass

            # Retry unlink vì AV/Windows có thể còn giữ lock vài ms
            for attempt in range(5):
                try:
                    os.unlink(emf_path)
                    break
                except PermissionError:
                    if attempt < 4:
                        time.sleep(0.1)

    except Exception as e:
        print(f"[EMF_CONVERT] fail: {e}")
        return None

# ══════════════════════════════════════════════════════════════════════════════
# VML extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_vml_images(
    r_pure,
    par: Paragraph,
    uid_prefix: str,
    run_idx: int,
    parent_uid: Optional[str],
    order_ref: Optional[OrderRef],
) -> List[DocNode]:
    """
    Xử lý ảnh VML từ w:pict > v:shape > v:imagedata.
    Dùng cho file convert từ .doc bằng Win32com.

    Cấu trúc XML:
        <w:pict>
          <v:shape style="width:...; height:...">
            <v:imagedata r:id="rId4" o:title=""/>
          </v:shape>
        </w:pict>
    """
    nodes: List[DocNode] = []

    picts = r_pure.xpath(".//w:pict", namespaces=_NS)
    if not picts:
        return nodes

    for pict_idx, pict in enumerate(picts, start=1):
        imagedatas = pict.xpath(".//v:imagedata", namespaces=_NS)
        for img_idx, imgdata in enumerate(imagedatas, start=1):
            rid = imgdata.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            if not rid:
                continue

            part = par.part.related_parts.get(rid)
            if part is None:
                continue

            blob = part.blob
            if not blob:
                continue

            shape = pict.xpath(".//v:shape", namespaces=_NS)
            width_emu, height_emu = 0, 0
            if shape:
                style = shape[0].get("style", "")
                width_emu, height_emu = _parse_vml_size(style)

            alt_text = imgdata.get("{urn:schemas-microsoft-com:office:office}title", "")
            mime     = getattr(part, "content_type", None) or "image/png"
            if mime in ("image/x-emf", "image/emf", "image/wmf", "image/x-wmf"):
                converted = _convert_emf_to_png(blob)
                if converted:
                    blob = converted
                    mime = "image/png"

            sha256   = safe_sha256(blob)
            data_uri = bytes_to_data_uri(blob, mime=mime)
            # Convert EMF/WMF → PNG vì browser không render được
            if mime in ("image/x-emf", "image/emf", "image/wmf", "image/x-wmf"):
                converted = _convert_emf_to_png(blob)
                if converted:
                    blob = converted
                    mime = "image/png"
           
            img_uid  = f"{uid_prefix}.r{run_idx}.p{pict_idx}.{img_idx}"

            nodes.append(
                DocNode(
                    type="image",
                    uid=img_uid,
                    parent_uid=parent_uid,
                    order=next_order(order_ref),
                    path=img_uid.replace(".", "/"),
                    content={
                        "rid":        rid,
                        "hash":       sha256,
                        "sha256":     sha256,
                        "mime":       mime,
                        "width_emu":  width_emu,
                        "height_emu": height_emu,
                        "alt_text":   alt_text,
                        "data_uri":   data_uri,
                        "floating":   True,
                        "run_index":  run_idx,
                        "draw_index": pict_idx,
                        "blip_index": img_idx,
                        "vml":        True,
                    },
                )
            )

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_inline_images(
    par: Paragraph,
    uid_prefix: str = "img",
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> List[DocNode]:
    """
    Trích xuất tất cả ảnh từ một paragraph.

    Lấy cả wp:inline lẫn wp:anchor miễn là có a:blip với r:embed.
    Fallback sang VML (w:pict > v:imagedata) cho file convert từ .doc bằng Win32com.

    Args:
        par:        Paragraph cần extract.
        uid_prefix: Prefix cho uid của các node ảnh.
        parent_uid: uid của node cha (paragraph hoặc cell).
        order_ref:  Mutable counter dùng chung toàn document.

    Returns:
        List DocNode(type="image"), rỗng nếu không có ảnh.
    """
    nodes: List[DocNode] = []

    for run_idx, run in enumerate(par.runs, start=1):
        r_elm = run._r
        if r_elm is None:
            continue

        r_pure   = _pure(r_elm)
        drawings = r_pure.xpath(".//w:drawing", namespaces=_NS)

        if drawings:
            # ── DrawingML path (DOCX bình thường / LibreOffice) ──────────────
            for draw_idx, drawing in enumerate(drawings, start=1):
                blip_rids = drawing.xpath(".//a:blip/@r:embed", namespaces=_NS)
                if not blip_rids:
                    continue

                width_emu, height_emu = _get_image_size(drawing)
                alt_text              = _get_alt_text(drawing)
                floating              = _is_anchor(drawing)

                for blip_idx, rid in enumerate(blip_rids, start=1):
                    part = par.part.related_parts.get(rid)
                    if part is None:
                        continue

                    blob = part.blob
                    if not blob:
                        continue

                    mime     = getattr(part, "content_type", None) or "image/png"
                    sha256   = safe_sha256(blob)
                    data_uri = bytes_to_data_uri(blob, mime=mime)
                    img_uid  = f"{uid_prefix}.r{run_idx}.d{draw_idx}.{blip_idx}"

                    nodes.append(
                        DocNode(
                            type="image",
                            uid=img_uid,
                            parent_uid=parent_uid,
                            order=next_order(order_ref),
                            path=img_uid.replace(".", "/"),
                            content={
                                "rid":        rid,
                                "hash":       sha256,
                                "sha256":     sha256,
                                "mime":       mime,
                                "width_emu":  width_emu,
                                "height_emu": height_emu,
                                "alt_text":   alt_text,
                                "data_uri":   data_uri,
                                "floating":   floating,
                                "run_index":  run_idx,
                                "draw_index": draw_idx,
                                "blip_index": blip_idx,
                            },
                        )
                    )

        else:
            # ── VML fallback (Win32com convert từ .doc) ───────────────────────
            nodes.extend(
                _extract_vml_images(r_pure, par, uid_prefix, run_idx, parent_uid, order_ref)
            )

    return nodes