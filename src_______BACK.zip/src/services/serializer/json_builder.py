"""
serializer/json_builder.py  — FIX SORT ORDER v4

Root cause của out-of-order:
- delete/insert opcode độc lập bị _add() ngay (gán id ngay),
  trong khi replace mới dùng pending.
- Khi align_blocks emit delete(i1=156) SAU replace(i1=163) do
  _match_mixed_slice, json_builder xử lý replace trước (id nhỏ, seq lớn)
  rồi delete sau (id lớn, seq nhỏ) → sort (seq_index, id) bị sai.

Fix v4: global_pending — gom TẤT CẢ (seq, change) vào một list,
sort một lần duy nhất, rồi mới gán id theo thứ tự đúng.
Không còn _add() sớm cho bất kỳ opcode nào.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from src.services.models.block import Block
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.table_diff import diff_table, analyze_table_change
from src.services.diff.shape_diff import diff_shape
from src.services.diff.image_diff import images_equal, build_image_change
from src.services.extractor.utils import norm_text as _norm, norm_for_diff

_SEQ_MULT = 100_000


def _display_text(content: dict) -> str:
    return (content.get("text_display") or content.get("text") or "").strip()


def _serialize_node(node) -> Optional[Dict[str, Any]]:
    if not node:
        return None

    out = {
        "uid":      getattr(node, "uid",  None),
        "type":     getattr(node, "type", None),
        "content":  getattr(node, "content", {}) or {},
        "children": [_serialize_node(c) for c in (getattr(node, "children", []) or [])],
    }

    # ✅ bubble data_uri cho image (để UI đọc node.data_uri cũng được)
    if out["type"] == "image":
        out["data_uri"] = out["content"].get("data_uri")

    return out

def _serialize_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
        "node":         _serialize_node(block.node),
    }


def _collect_shape_text_lines(node) -> List[str]:
    lines: List[str] = []
    for child in (getattr(node, "children", []) or []):
        t = getattr(child, "type", None)
        if t == "paragraph":
            content = getattr(child, "content", {}) or {}
            txt = _display_text(content)
            if txt:
                lines.append(txt)
        elif t == "shape":
            lines.extend(_collect_shape_text_lines(child))
        elif t == "table":
            for row in (getattr(child, "children", []) or []):
                if getattr(row, "type", None) != "row":
                    continue
                cell_texts = []
                for cell in (getattr(row, "children", []) or []):
                    if getattr(cell, "type", None) != "cell":
                        continue
                    content = getattr(cell, "content", {}) or {}
                    ct = _display_text(content)
                    if ct:
                        cell_texts.append(ct)
                if cell_texts:
                    lines.append(" | ".join(cell_texts))
        elif t == "image": 
            lines.append("[Image]")
    return lines


def _serialize_shape_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None
    base = _serialize_block_side(block)
    if base is None:
        return None

    lines = _collect_shape_text_lines(block.node)

    def _collect_images(node):
        imgs = []
        for ch in (getattr(node, "children", []) or []):
            if getattr(ch, "type", None) == "image":
                content = getattr(ch, "content", {}) or {}
                px = 96 / 914400
                imgs.append({
                    "data_uri": content.get("data_uri"),
                    "width_px":  ...,
                    "height_px": ...,
                })
            else:
                imgs.extend(_collect_images(ch))
        return imgs

    base["shape_images"] = _collect_images(block.node)

    if not lines:
        img_count   = (block.node.content or {}).get("image_count", 0) or 0
        table_count = (block.node.content or {}).get("table_count", 0) or 0
        preview = []
        if img_count:
            preview.append(f"Image × {img_count}")
        if table_count:
            preview.append(f"Table × {table_count}")
        lines = [f"[{' , '.join(preview)}]"] if preview else ["[Empty shape]"]

    base["shape_text_lines"] = lines  # ← luôn set
    return base                        # ← luôn return

def _ctx_item(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
    }


def _build_context(blocks: List[Block], index: int) -> Dict[str, Any]:
    return {
        "previous": _ctx_item(blocks[index - 1] if index > 0               else None),
        "next":     _ctx_item(blocks[index + 1] if index + 1 < len(blocks) else None),
    }


def _change_kind(left: Any, right: Any) -> str:
    if left is not None and right is None:
        return "delete"
    if left is None and right is not None:
        return "insert"
    return "replace"


def _shape_has_text(block: Block) -> bool:
    def _check(node) -> bool:
        for child in (getattr(node, "children", []) or []):
            if getattr(child, "type", None) == "paragraph":
                if _norm((getattr(child, "content", {}) or {}).get("text", "")):
                    return True
            elif getattr(child, "type", None) == "shape":
                if _check(child):
                    return True
        return False
    return _check(block.node)


def _shape_has_content(block: Block) -> bool:
    return bool(getattr(block.node, "children", None))


def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


def _make_change(
    cid:         int,
    change_type: str,
    heading:     Optional[str],
    order:       int,
    left:        Optional[Dict[str, Any]],
    right:       Optional[Dict[str, Any]],
    extra:       Optional[Dict[str, Any]] = None,
    seq_index:   int = 0,
) -> Dict[str, Any]:
    return {
        "id":          cid,
        "heading":     heading,
        "type":        change_type,
        "change_kind": _change_kind(left, right),
        "order":       order,
        "seq_index":   seq_index,
        "left":        left,
        "right":       right,
        **(extra or {}),
    }


def _process_paragraph(cid, a, b, ai, bj, a_blocks, b_blocks):
    old_raw = a.node.content.get("text", "")
    new_raw = b.node.content.get("text", "")
    old_display = a.node.content.get("text_display") or old_raw
    new_display = b.node.content.get("text_display") or new_raw
    if _norm(old_raw) == _norm(new_raw):
        return None
    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)
    return _make_change(
        cid=cid, change_type="paragraph_modified", heading=heading, order=order,
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw, old_display=old_display, new_display=new_display),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_heading(cid, a, b, ai, bj, a_blocks, b_blocks):
    old_raw   = a.node.content.get("text", "")
    new_raw   = b.node.content.get("text", "")
    old_norm  = _norm(old_raw)
    new_norm  = _norm(new_raw)
    old_level = int(a.node.content.get("level", 1) or 1)
    new_level = int(b.node.content.get("level", 1) or 1)
    if old_norm == new_norm and old_level == new_level:
        return None
    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)
    return _make_change(
        cid=cid, change_type="heading_modified", heading=heading, order=order,
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw) if old_norm != new_norm else None,
            "old_level":     old_level,
            "new_level":     new_level,
            "level_changed": old_level != new_level,
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_table(cid, a, b, ai, bj, a_blocks, b_blocks):
    from src.services.diff.table_diff import (
        _serialize_full_table, get_header_row, TABLE_RENDER_FULL,
        _table_has_nested
    )

    a_cols = int((a.node.content or {}).get("col_count", 0) or 0)
    b_cols = int((b.node.content or {}).get("col_count", 0) or 0)

    if (a_cols > 0 and b_cols > 0 and a_cols != b_cols
            and not _table_has_nested(a.node)
            and not _table_has_nested(b.node)):
        analysis = {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   True,
            "full_table_original": _serialize_full_table(a.node),
            "full_table_modified": _serialize_full_table(b.node),
            "header_row":          get_header_row(b.node),
            "added_rows": [], "deleted_rows": [], "table_changes": [],
        }
        heading = a.heading_ctx or b.heading_ctx
        return _make_change(
            cid=cid, change_type="table_modified", heading=heading,
            order=min(a.order, b.order),
            left=_serialize_block_side(a), right=_serialize_block_side(b),
            extra={
                "table_changes":  [],
                "table_analysis": analysis,
                "left_context":   _build_context(a_blocks, ai),
                "right_context":  _build_context(b_blocks, bj),
            },
        )

    table_changes = diff_table(a.node, b.node)
    analysis = analyze_table_change(a_tbl=a.node, b_tbl=b.node, table_changes=table_changes)
    if analysis is None:
        return None

    heading = a.heading_ctx or b.heading_ctx
    return _make_change(
        cid=cid, change_type="table_modified", heading=heading,
        order=min(a.order, b.order),
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "table_changes":  analysis.get("table_changes") or [],
            "table_analysis": analysis,
            "left_context":   _build_context(a_blocks, ai),
            "right_context":  _build_context(b_blocks, bj),
        },
    )

def _process_shape(cid, a, b, ai, bj, a_blocks, b_blocks):
    
    a_has_text = _shape_has_text(a)
    b_has_text = _shape_has_text(b)
    a_has_content = _shape_has_content(a)
    b_has_content = _shape_has_content(b)

    # ✅ FIX BUG #3: shape không có text nhưng có content (ảnh/bảng/...) vẫn phải xử lý
    if (not a_has_text and not b_has_text) and (not a_has_content and not b_has_content):
        return None

    left_side  = _serialize_shape_side(a)
    right_side = _serialize_shape_side(b)
    heading    = a.heading_ctx or b.heading_ctx
    order      = min(a.order, b.order)
    if a_has_text and not b_has_text:
        return _make_change(cid=cid, change_type="shape_modified", heading=heading, order=order,
            left=left_side, right=right_side,
            extra={"shape_cleared": True, "shape_changes": [],
                   "shape_text_preview": (left_side or {}).get("shape_text_lines", []),
                   "left_context": _build_context(a_blocks, ai),
                   "right_context": _build_context(b_blocks, bj)})
    if not a_has_text and b_has_text:
        return _make_change(cid=cid, change_type="shape_modified", heading=heading, order=order,
            left=left_side, right=right_side,
            extra={"shape_cleared": False, "shape_changes": [],
                   "shape_text_preview": (right_side or {}).get("shape_text_lines", []),
                   "left_context": _build_context(a_blocks, ai),
                   "right_context": _build_context(b_blocks, bj)})
    shape_changes = diff_shape(a.node, b.node)
    if not shape_changes:
        return None
    return _make_change(cid=cid, change_type="shape_modified", heading=heading, order=order,
        left=left_side, right=right_side,
        extra={"shape_cleared": False, "shape_changes": shape_changes,
               "shape_text_preview": (left_side or {}).get("shape_text_lines", []),
               "left_context": _build_context(a_blocks, ai),
               "right_context": _build_context(b_blocks, bj)})


def _process_image(cid, a, b, ai, bj, a_blocks, b_blocks):
    if images_equal(a.node, b.node):
        return None
    heading = a.heading_ctx or b.heading_ctx
    img_change = build_image_change(a.node, b.node)
    return _make_change(cid=cid, change_type="image_modified", heading=heading,
        order=min(a.order, b.order),
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "image_change": img_change,
            "left_img":     img_change.get("left_img"),   # ✅ bubble
            "right_img":    img_change.get("right_img"),  # ✅ bubble
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        })

def _process_insert(cid, b, bj, b_blocks):
    if b.type == "shape" and not _shape_has_text(b) and not _shape_has_content(b):
        return None
    right_side = _serialize_shape_side(b) if b.type == "shape" else _serialize_block_side(b)
    extra: Dict[str, Any] = {"left_context": None, "right_context": _build_context(b_blocks, bj)}
    if b.type == "table":
        extra["table_analysis"] = analyze_table_change(a_tbl=None, b_tbl=b.node, table_changes=[])
    if b.type == "shape":
        extra["shape_text_preview"] = (right_side or {}).get("shape_text_lines", [])
    if b.type == "image":
        img_change = build_image_change(None, b.node)
        extra["image_change"] = img_change
        extra["right_img"] = img_change.get("right_img")  # ✅ bubble
    return _make_change(cid=cid, change_type=f"{b.type}_inserted", heading=b.heading_ctx,
        order=b.order, left=None, right=right_side, extra=extra)


def _process_delete(cid, a, ai, a_blocks):
    if a.type == "shape" and not _shape_has_text(a) and not _shape_has_content(a):
        return None
    left_side = _serialize_shape_side(a) if a.type == "shape" else _serialize_block_side(a)
    extra: Dict[str, Any] = {"left_context": _build_context(a_blocks, ai), "right_context": None}
    if a.type == "table":
        extra["table_analysis"] = analyze_table_change(a_tbl=a.node, b_tbl=None, table_changes=[])
    if a.type == "shape":
        extra["shape_text_preview"] = (left_side or {}).get("shape_text_lines", [])
    if a.type == "image":
        img_change = build_image_change(a.node, None)
        extra["image_change"] = img_change
        extra["left_img"] = img_change.get("left_img")    # ✅ bubble
    return _make_change(cid=cid, change_type=f"{a.type}_deleted", heading=a.heading_ctx,
        order=a.order, left=left_side, right=None, extra=extra)


def build_ui_json(
    a_blocks: List[Block],
    b_blocks: List[Block],
    opcodes,
) -> Dict[str, Any]:
    """
    Build UI JSON từ aligned block opcodes.

    FIX SORT ORDER v4 — global_pending:
    Gom TẤT CẢ (seq, change) từ mọi opcode (insert/delete/replace) vào
    một global_pending duy nhất. Sort một lần. Gán id sau sort.

    Tại sao v3 vẫn lỗi:
    - v3 chỉ dùng pending bên trong từng replace opcode.
    - delete/insert opcode độc lập vẫn được _add() ngay → id gán trước
      khi biết seq của các replace opcode tiếp theo.
    - Khi align_blocks trả về thứ tự:
        replace(i1=163) → delete(i1=156)   ← mixed slice emit sai thứ tự
      json_builder xử lý replace trước (id=8, seq=16_300_000),
      rồi delete (id=9, seq=15_600_000).
      sort (seq, id): seq[8]=16_300_000 > seq[9]=15_600_000 → OUT OF ORDER.

    v4 fix: không _add() sớm, gom hết vào global_pending,
    sort một lần theo seq rồi gán id tăng dần → id luôn tương quan seq.
    """
    # ── DEBUG ──────────────────────────────────────────────────────────────────
    import logging
    logger = logging.getLogger(__name__)
    
    opcodes = list(opcodes)  # convert để dùng được nhiều lần
    
    logger.warning(f"[DEBUG] a_blocks={len(a_blocks)}, b_blocks={len(b_blocks)}")
    logger.warning(f"[DEBUG] opcodes={opcodes}")
    for b in a_blocks[:5]:
        logger.warning(f"[DEBUG] a_block: type={b.type} sig={b.signature[:40]!r}")
    for b in b_blocks[:5]:
        logger.warning(f"[DEBUG] b_block: type={b.type} sig={b.signature[:40]!r}")
    # ── END DEBUG ──────────────────────────────────────────────────────────────
    flat_changes: List[Dict[str, Any]]      = []

    # ── Global pending: gom tất cả (seq, change) trước khi gán id ─────────────
    # Key insight: id phải được gán SAU khi đã biết thứ tự seq của tất cả changes.
    # Nếu gán id sớm (trong vòng lặp opcode), id sẽ không tương quan với seq
    # → sort (seq_index, id) vô nghĩa.
    global_pending: List[Tuple[int, Dict[str, Any]]] = []

    # cid_counter vẫn cần cho _process_* (truyền vào nhưng chưa commit)
    # Sau sort global_pending, ta gán lại id theo thứ tự đúng.
    # _process_* nhận cid như placeholder — sẽ bị ghi đè.
    _cid_placeholder = [1]

    def _collect(change: Optional[Dict[str, Any]], seq: int) -> None:
        """Thêm vào global_pending thay vì _add ngay."""
        if change is None:
            return
        global_pending.append((seq, change))

    for tag, i1, i2, j1, j2 in opcodes:

        if tag == "equal":
            continue

        # ── INSERT ────────────────────────────────────────────────────────────
        if tag == "insert":
            for j in range(j1, j2):
                # anchor theo i1 (vị trí trong a ngay trước chỗ insert)
                # + offset j để preserve thứ tự giữa nhiều insert liên tiếp
                seq    = i1 * _SEQ_MULT + (j - j1)
                change = _process_insert(_cid_placeholder[0], b_blocks[j], j, b_blocks)
                _collect(change, seq)

        # ── DELETE ────────────────────────────────────────────────────────────
        elif tag == "delete":
            for i in range(i1, i2):
                seq    = i * _SEQ_MULT
                change = _process_delete(_cid_placeholder[0], a_blocks[i], i, a_blocks)
                _collect(change, seq)

        # ── REPLACE ───────────────────────────────────────────────────────────
        elif tag == "replace":
            a_slice = a_blocks[i1:i2]
            b_slice = b_blocks[j1:j2]
            pairs   = min(len(a_slice), len(b_slice))

            # Paired replace (1-1)
            for k in range(pairs):
                ai  = i1 + k
                bj  = j1 + k
                a   = a_blocks[ai]
                b   = b_blocks[bj]
                # seq dùng ai (vị trí trong a) — stable, không phụ thuộc b
                seq = ai * _SEQ_MULT

                change: Optional[Dict[str, Any]] = None
                if a.type == "paragraph" and b.type == "paragraph":
                    change = _process_paragraph(_cid_placeholder[0], a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "heading" and b.type == "heading":
                    change = _process_heading(_cid_placeholder[0], a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "table" and b.type == "table":
                    change = _process_table(_cid_placeholder[0], a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "shape" and b.type == "shape":
                    change = _process_shape(_cid_placeholder[0], a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "image" and b.type == "image":
                    change = _process_image(_cid_placeholder[0], a, b, ai, bj, a_blocks, b_blocks)
                else:
                    heading = a.heading_ctx or b.heading_ctx
                    change  = _make_change(
                        cid=_cid_placeholder[0],
                        change_type=f"{a.type}_to_{b.type}_modified",
                        heading=heading, order=min(a.order, b.order),
                        left=_serialize_block_side(a), right=_serialize_block_side(b),
                        extra={"left_context":  _build_context(a_blocks, ai),
                               "right_context": _build_context(b_blocks, bj)},
                    )

                _collect(change, seq)

            # Leftover delete (a không được pair)
            for i in range(i1 + pairs, i2):
                seq    = i * _SEQ_MULT
                change = _process_delete(_cid_placeholder[0], a_blocks[i], i, a_blocks)
                _collect(change, seq)

            # Leftover insert (b không được pair)
            # Anchor sau block a cuối cùng trong slice, trước block a tiếp theo
            anchor = (i2 - 1) * _SEQ_MULT + _SEQ_MULT // 2
            for j in range(j1 + pairs, j2):
                seq    = anchor + (j - (j1 + pairs))
                change = _process_insert(_cid_placeholder[0], b_blocks[j], j, b_blocks)
                _collect(change, seq)

    # ── Sort global_pending một lần duy nhất theo seq ─────────────────────────
    global_pending.sort(key=lambda x: x[0])

    # ── Gán id + build sections theo "runs" để giữ đúng thứ tự văn bản gốc ─────
    cid = 1
    flat_changes: List[Dict[str, Any]] = []
    ordered_sections: List[Dict[str, Any]] = []

    last_heading: Optional[str] = None
    current_section: Optional[Dict[str, Any]] = None

    for seq, change in global_pending:
        change["id"]        = cid
        change["seq_index"] = seq
        cid += 1

        heading = _section_key(change.get("heading"))

        # ✅ SECTION RUNS: tạo section mới khi heading đổi (cho phép lặp heading)
        if current_section is None or heading != last_heading:
            current_section = {"heading": heading, "changes": []}
            ordered_sections.append(current_section)
            last_heading = heading

        current_section["changes"].append(change)
        flat_changes.append(change)

    # ✅ Vì global_pending đã sort theo seq, nên changes trong từng section-run đã đúng thứ tự
    # Không cần sort lại theo (seq,id) nữa, nhưng giữ cũng không hại.
    sort_key = lambda x: (x.get("seq_index", 0), x.get("id", 0))
    for section in ordered_sections:
        section["changes"].sort(key=sort_key)

    
    return {
        "sections": ordered_sections,
        "changes": sorted(flat_changes, key=sort_key),
        "_debug_json_builder": "v4-section-runs"
    }

