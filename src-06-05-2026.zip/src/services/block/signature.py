"""
block/signature.py
~~~~~~~~~~~~~~~~~~
Tạo fingerprint ngắn gọn cho mỗi DocNode.

Nguyên tắc thiết kế:
1. STABLE     — cùng nội dung, khác vị trí trong file → signature giống nhau
2. SENSITIVE  — khác nội dung dù nhỏ → signature khác nhau
3. NO TRUNCATE — không cắt text trước khi hash (tránh collision bảng lớn)
4. SEMANTIC   — chỉ hash những gì có nghĩa với người dùng,
                bỏ qua metadata format (run_count, alignment None vs LEFT...)

Export công khai:
    signature(node, heading_ctx="") — hàm chính
    _norm_text                      — dùng bởi block_builder và sequence_align
    _split_heading                  — dùng bởi sequence_align
"""

from __future__ import annotations

import hashlib
import re
from typing import List, Tuple

from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm_text

# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _hash(value: str, length: int = 16) -> str:
    """
    MD5 hash, truncate tới `length` hex chars.
    Trả "empty" nếu value rỗng — giúp debug đọc signature dễ hơn.
    KHÔNG truncate value trước khi hash — tránh collision.
    """
    if not value:
        return "empty"
    return hashlib.md5(value.encode("utf-8")).hexdigest()[:length]


def _norm_alignment(align) -> str:
    """
    Chuẩn hoá alignment về string nhất quán.
    Word có thể trả None (= LEFT mặc định) hoặc WD_ALIGN_PARAGRAPH.LEFT
    → cả 2 đều map về "LEFT" để không tạo false diff.
    """
    if align is None:
        return "LEFT"
    s = str(align).upper().strip()
    if "." in s:
        s = s.split(".")[-1]
    return s or "LEFT"


# ══════════════════════════════════════════════════════════════════════════════
# Heading split — dùng chung bởi signature.py và sequence_align.py
# ══════════════════════════════════════════════════════════════════════════════

_CHAPTER_RE = re.compile(r"^(\d+(?:\.\d+)*)\s+(.*)", re.DOTALL)


def _split_heading(text: str) -> Tuple[str, str]:
    """
    Tách số chương khỏi nội dung heading.

    "5.2 Phân tích kết quả" → ("5.2", "phân tích kết quả")
    "Giới thiệu"            → ("",    "giới thiệu")

    Mục đích kép:
    1. sequence_align dùng body để match heading dù số chương thay đổi
       khi thêm/xóa section (heading shift bug).
    2. _heading_ctx_body dùng để chuẩn hoá heading_ctx trong content_sig
       của shape — stable trước heading shift nhưng vẫn phân biệt
       2 heading tên khác nhau (cross-match bug).
    """
    t = _norm_text(text).lower()
    m = _CHAPTER_RE.match(t)
    if m:
        return m.group(1), m.group(2).strip()
    return "", t


# ══════════════════════════════════════════════════════════════════════════════
# Per-type signature builders
# ══════════════════════════════════════════════════════════════════════════════

def _sig_heading(node: DocNode) -> str:
    """
    H{level}:{text_hash}

    Chỉ dùng text + level.
    Không dùng style vì heading style ("Heading 1") là redundant với level.

    Edge case: heading rỗng → H{level}:empty.
    Nhiều heading rỗng cùng level sẽ có signature giống nhau — chấp nhận
    được vì heading rỗng không mang nghĩa, diff đúng hơn là báo "identical".
    """
    txt   = _norm_text(node.content.get("text", ""))
    level = int(node.content.get("level", 0) or 0)
    return f"H{level}:{_hash(txt)}"


def _sig_paragraph(node: DocNode) -> str:
    """
    P:{text_hash}:{style_hash}:{alignment}

    Bỏ run_count vì cùng text có thể là 1 run hay 2 run tuỳ cách Word lưu.
    Bỏ space_before/after vì dễ tạo false diff khi copy-paste giữa template.
    Giữ alignment vì nó là thay đổi có nghĩa, nhưng chuẩn hoá None → LEFT.
    """
    txt   = _norm_text(node.content.get("text", ""))
    style = _norm_text(node.content.get("style", "") or "")
    align = _norm_alignment(node.content.get("alignment"))
    return f"P:{_hash(txt)}:{_hash(style, 8)}:{align}"


def _sig_table(node: DocNode) -> str:
    """
    T:{row_count}x{col_count}:{content_hash}

    Dùng row_count / col_count — khớp với key mà extract_table() và
    _parse_tbl_xml() lưu vào node.content.

    Nếu có children, hash toàn bộ row signature để cover nested table
    chính xác hơn dùng text thuần.
    """
    rows = int(node.content.get("row_count", 0) or 0)
    cols = int(node.content.get("col_count", 0) or 0)

    if node.children:
        children_sig = "|".join(_sig_row(r) for r in node.children if r.type == "row")
        return f"T:{rows}x{cols}:{_hash(children_sig)}"

    txt = _norm_text(node.content.get("text", ""))
    return f"T:{rows}x{cols}:{_hash(txt)}"


def _sig_row(node: DocNode) -> str:
    """
    R:{cells_hash}

    Không đưa row_index vào hash — index thay đổi khi thêm/xóa row
    ở đầu bảng, khiến tất cả row phía sau bị báo "modified" dù nội dung
    không đổi (row index shift bug).
    """
    if node.children:
        cells_sig = "|".join(_sig_cell(c) for c in node.children if c.type == "cell")
        return f"R:{_hash(cells_sig)}"

    row_text = _norm_text(node.content.get("text", ""))
    return f"R:{_hash(row_text)}"


def _sig_cell(node: DocNode) -> str:
    """
    C:{content_hash}

    Bỏ row_span/col_span khỏi signature.
    Lý do: span thay đổi khi layout merge/unmerge dù text không đổi
    → sig khác → SequenceMatcher báo rows khác nhau dù content giống
    → false diff (bảng máy tắc: layout đổi nhưng data giữ nguyên).
    """
    parts: List[str] = []

    if node.children:
        for child in node.children:
            if child.type == "paragraph":
                txt = _norm_text(child.content.get("text", ""))
                if txt:
                    parts.append(f"p:{txt}")
            elif child.type == "table":
                parts.append(f"t:{_sig_table(child)}")
            elif child.type == "image":
                parts.append(f"i:{_sig_image(child)}")
    else:
        txt = _norm_text(node.content.get("text", ""))
        if txt:
            parts.append(f"p:{txt}")

    combined = "|".join(parts)
    return f"C:{_hash(combined)}"

def _sig_image(node: DocNode) -> str:
    """
    I:{sha256}:{width}x{height}

    sha256 là hash nội dung ảnh — chính xác nhất.
    Fallback dần về name, data_uri, uid — theo thứ tự độ tin cậy giảm dần.
    """
    sha    = (node.content.get("sha256", "") or "").strip()
    width  = int(node.content.get("width_emu",  0) or 0)
    height = int(node.content.get("height_emu", 0) or 0)

    if sha:
        return f"I:{sha[:16]}:{width}x{height}"

    name = _norm_text(node.content.get("name", "") or "")
    if name:
        return f"I:{_hash(name, 12)}:{width}x{height}"

    data_uri = node.content.get("data_uri", "") or ""
    if data_uri:
        return f"I:{_hash(data_uri, 16)}:{width}x{height}"

    uid = getattr(node, "uid", "") or ""
    return f"I:nodata:{_hash(uid, 8)}:{width}x{height}"


def _sig_shape(node: DocNode, heading_ctx: str = "") -> str:
    """
    S:{shape_type}:{content_hash}

    heading_ctx được inject bởi block_builder để phân biệt 2 shape
    cùng text ở 2 section khác nhau (cross-match bug).

    Shape rỗng: dùng parent_uid + uid_suffix + heading_ctx để tạo
    identity tương đối — stable hơn uid/order tuyệt đối khi thêm/xóa block.
    """
    shape_type = node.content.get("shape_type", "") or ""
    texts: List[str] = []
    _collect_shape_texts(node, texts)
    combined = " | ".join(texts)

    if not combined:
        parent_uid = getattr(node, "parent_uid", "") or ""
        uid       = getattr(node, "uid", "") or ""
        stable_id = _hash(f"{parent_uid}:{uid}:{heading_ctx}", 8)
        return f"S:{shape_type}:empty:{stable_id}"

    # Inject heading_ctx để phân biệt shape cùng text ở section khác nhau
    if heading_ctx:
        combined = f"{heading_ctx}||{combined}"
    return f"S:{shape_type}:{_hash(combined)}"


def _collect_shape_texts(node: DocNode, out: List[str]) -> None:
    """
    Walk đệ quy vào shape để lấy tất cả text có nghĩa.

    Cover:
    - paragraph trực tiếp trong shape
    - shape lồng nhau (textbox trong textbox)
    - table trong textbox: dùng _sig_table để lấy fingerprint ổn định,
      không flatten text thô vì cell order và structure quan trọng.

    Trước đây bỏ qua table → 2 shape khác nhau chỉ ở nội dung bảng
    bên trong có thể có cùng signature (false equal bug).
    """
    for child in (node.children or []):
        if child.type == "paragraph":
            txt = _norm_text(child.content.get("text", ""))
            if txt:
                out.append(txt)
        elif child.type == "shape":
            _collect_shape_texts(child, out)
        elif child.type == "table":
            # Dùng signature của table thay vì flatten text thô —
            # giữ được cấu trúc (row/cell order) và cover nested table.
            out.append(_sig_table(child))


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def signature(node: DocNode, heading_ctx: str = "") -> str:
    """
    Tạo fingerprint cho node.

    Args:
        node:        DocNode cần tạo fingerprint.
        heading_ctx: Breadcrumb heading tại vị trí node, dùng để phân biệt
                     shape cùng text ở 2 section khác nhau. Default "" để
                     tương thích khi gọi không có context (vd: test, heading node).

    Đảm bảo:
    - STABLE:    cùng nội dung → cùng signature, bất kể vị trí trong file
    - SENSITIVE: khác nội dung → khác signature
    - SEMANTIC:  chỉ hash nội dung có nghĩa, bỏ qua metadata format

    heading_ctx chỉ được đưa vào signature của shape — các type khác
    (paragraph, table, image) đã có nội dung text đủ để phân biệt.
    """
    t = node.type

    if t == "heading":   return _sig_heading(node)
    if t == "paragraph": return _sig_paragraph(node)
    if t == "table":     return _sig_table(node)
    if t == "row":       return _sig_row(node)
    if t == "cell":      return _sig_cell(node)
    if t == "image":     return _sig_image(node)
    if t == "shape":     return _sig_shape(node, heading_ctx)

    # Unknown type — fallback
    txt = _norm_text(node.content.get("text", ""))
    return f"U:{t}:{_hash(txt, 12)}"