"""
extractor/image.py
~~~~~~~~~~~~~~~~~~
Extract ảnh inline (nằm trong dòng chữ) từ một Paragraph.

Chỉ xử lý:
    ✅ Ảnh inline (<wp:inline>) trong paragraph thường
    ✅ Ảnh inline trong cell (table.py gọi hàm này cho mỗi paragraph trong cell)

Không xử lý:
    ❌ Ảnh floating / anchor (<wp:anchor>) — do shape.py xử lý
    ❌ Ảnh trong textbox
    ❌ Ảnh trong header / footer

Import từ: utils.py
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from docx.text.paragraph import Paragraph
from lxml import etree

from src.services.models.docnode import DocNode
from src.services.extractor.utils import OrderRef, next_order
from src.services.utils.hash import bytes_to_data_uri, safe_sha256

# ── Namespaces ────────────────────────────────────────────────────────────────

_NS: Dict[str, str] = {
    "a":  "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r":  "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "w":  "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _pure(elm):
    """
    Chuyển BaseOxmlElement về lxml element thuần.
    python-docx 1.2.0 override .xpath() và không nhận tham số 'namespaces'
    nên phải serialize → parse lại để bypass.
    """
    return etree.fromstring(etree.tostring(elm))


def _get_image_size(drawing_elm) -> tuple[int, int]:
    """Lấy kích thước ảnh (width, height) tính bằng EMU từ wp:inline/wp:extent."""
    extents = drawing_elm.xpath(".//wp:inline/wp:extent", namespaces=_NS)
    if not extents:
        return 0, 0
    ext = extents[0]
    return _emu_to_int(ext.get("cx")), _emu_to_int(ext.get("cy"))


def _get_alt_text(drawing_elm) -> str:
    """Lấy alt text từ wp:docPr descr hoặc title."""
    doc_prs = drawing_elm.xpath(".//wp:inline/wp:docPr", namespaces=_NS)
    if not doc_prs:
        return ""
    doc_pr = doc_prs[0]
    return doc_pr.get("descr") or doc_pr.get("title") or ""


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_inline_images(
    par: Paragraph,
    uid_prefix: str = "img",
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> List[DocNode]:
    """
    Trích xuất tất cả ảnh inline từ một paragraph.

    Chỉ lấy wp:inline — bỏ qua wp:anchor (floating, do shape.py xử lý).

    Args:
        par:        Paragraph cần extract.
        uid_prefix: Prefix cho uid của các node ảnh.
        parent_uid: uid của node cha (paragraph hoặc cell).
        order_ref:  Mutable counter dùng chung toàn document.

    Returns:
        List DocNode(type="image"), rỗng nếu không có ảnh inline.
    """
    nodes: List[DocNode] = []

    for run_idx, run in enumerate(par.runs, start=1):
        r_elm = run._r
        if r_elm is None:
            continue

        r_pure   = _pure(r_elm)
        drawings = r_pure.xpath(".//w:drawing", namespaces=_NS)
        if not drawings:
            continue

        for draw_idx, drawing in enumerate(drawings, start=1):
            # Chỉ lấy inline — bỏ qua anchor (floating)
            if not drawing.xpath("wp:inline", namespaces=_NS):
                continue

            blip_rids = drawing.xpath(".//a:blip/@r:embed", namespaces=_NS)
            if not blip_rids:
                continue

            width_emu, height_emu = _get_image_size(drawing)
            alt_text              = _get_alt_text(drawing)

            for blip_idx, rid in enumerate(blip_rids, start=1):
                part = par.part.related_parts.get(rid)
                if part is None:
                    continue

                blob = part.blob
                if not blob:
                    continue

                mime     = getattr(part, "content_type", None) or "image/png"
                sha256   = safe_sha256(blob)
                data_uri = bytes_to_data_uri(blob, mime=mime)
                img_uid  = f"{uid_prefix}.r{run_idx}.d{draw_idx}.{blip_idx}"

                nodes.append(
                    DocNode(
                        type="image",
                        uid=img_uid,
                        parent_uid=parent_uid,
                        order=next_order(order_ref),
                        path=img_uid.replace(".", "/"),
                        content={
                            "rid":        rid,
                            "hash":       sha256,
                            "sha256":     sha256,
                            "mime":       mime,
                            "width_emu":  width_emu,
                            "height_emu": height_emu,
                            "alt_text":   alt_text,
                            "data_uri":   data_uri,
                            "run_index":  run_idx,
                            "draw_index": draw_idx,
                            "blip_index": blip_idx,
                        },
                    )
                )

    return nodes