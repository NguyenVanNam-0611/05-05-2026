"""
serializer/json_builder.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Build UI JSON từ aligned block opcodes.

Nguyên tắc thiết kế output:
  - paragraph  → text đầy đủ cả 2 bên + word_diff (spans highlight)
  - table      → table_analysis + từng dòng khác nhau (row-level changes)
  - shape      → shape_text_lines cả 2 bên + shape_changes (paragraph-level diff)
  - image      → image payload cả 2 bên để frontend render song song
  - heading    → text cả 2 bên (không word_diff — heading ngắn, toàn bộ là context)

Key fix so với cũ:
  1. Bỏ snapshot — không cần đường dẫn docx, không dep bên ngoài.
  2. equal opcode: KHÔNG check lại block.signature — tin hoàn toàn vào opcode.
     (block.signature của shape chứa heading_ctx đầy đủ có số chương,
      heading shift làm đổi số chương → signature khác dù content không đổi
      → nếu check lại sẽ emit replace sai khi thêm nội dung trước heading)
  3. paragraph: chỉ emit khi text thực sự khác (bỏ qua format-only change).
  4. table: emit đầy đủ table_analysis (render_mode, added/deleted/modified rows).
  5. shape: emit shape_text_lines để frontend render preview ngay.
  6. heading: emit heading_modified khi text heading thực sự đổi.
  7. change_kind tự suy từ left/right thay vì hardcode.
  8. sections group theo heading_ctx của block A (file gốc) — stable hơn.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.services.models.block import Block
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.table_diff import diff_table, analyze_table_change
from src.services.diff.shape_diff import diff_shape
from src.services.diff.image_diff import images_equal, build_image_change
from src.services.extractor.utils import norm_text as _norm, norm_for_diff


# ══════════════════════════════════════════════════════════════════════════════
# Helpers: normalize text
# ══════════════════════════════════════════════════════════════════════════════

def _display_text(content: dict) -> str:
    """
    Lấy text để hiển thị UI — ưu tiên text_display (giữ layout gốc),
    fallback về text (normalized).
    """
    return (content.get("text_display") or content.get("text") or "").strip()


# ══════════════════════════════════════════════════════════════════════════════
# Helpers: serialize
# ══════════════════════════════════════════════════════════════════════════════

def _serialize_node(node) -> Optional[Dict[str, Any]]:
    if not node:
        return None
    return {
        "uid":      getattr(node, "uid",  None),
        "type":     getattr(node, "type", None),
        "content":  getattr(node, "content", {}) or {},
        "children": [_serialize_node(c) for c in (getattr(node, "children", []) or [])],
    }


def _serialize_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    """Serialize một block thành side payload cơ bản."""
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
        "node":         _serialize_node(block.node),
    }


def _collect_shape_text_lines(node) -> List[str]:
    """
    Thu thập text lines từ shape, đệ quy vào shape lồng và table trong shape.
    Dùng để frontend render preview text của shape mà không cần parse node.
    Dùng text_display (giữ layout gốc) thay vì text normalized.
    """
    lines: List[str] = []
    for child in (getattr(node, "children", []) or []):
        t = getattr(child, "type", None)
        if t == "paragraph":
            content = getattr(child, "content", {}) or {}
            txt = _display_text(content)
            if txt:
                lines.append(txt)
        elif t == "shape":
            lines.extend(_collect_shape_text_lines(child))
        elif t == "table":
            for row in (getattr(child, "children", []) or []):
                if getattr(row, "type", None) != "row":
                    continue
                cell_texts = []
                for cell in (getattr(row, "children", []) or []):
                    if getattr(cell, "type", None) != "cell":
                        continue
                    content = getattr(cell, "content", {}) or {}
                    ct = _display_text(content)
                    if ct:
                        cell_texts.append(ct)
                if cell_texts:
                    lines.append(" | ".join(cell_texts))
    return lines


def _serialize_shape_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    """
    Serialize shape block side — thêm shape_text_lines để frontend render ngay.
    Không cần snapshot/docx_path.
    """
    if not block:
        return None
    base = _serialize_block_side(block)
    if base is None:
        return None
    base["shape_text_lines"] = _collect_shape_text_lines(block.node)
    return base


# ══════════════════════════════════════════════════════════════════════════════
# Helpers: context
# ══════════════════════════════════════════════════════════════════════════════

def _ctx_item(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
    }


def _build_context(blocks: List[Block], index: int) -> Dict[str, Any]:
    return {
        "previous": _ctx_item(blocks[index - 1] if index > 0              else None),
        "next":     _ctx_item(blocks[index + 1] if index + 1 < len(blocks) else None),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Helpers: change_kind
# ══════════════════════════════════════════════════════════════════════════════

def _change_kind(left: Any, right: Any) -> str:
    if left is not None and right is None:
        return "delete"
    if left is None and right is not None:
        return "insert"
    return "replace"


# ══════════════════════════════════════════════════════════════════════════════
# Helpers: shape text check
# ══════════════════════════════════════════════════════════════════════════════

def _shape_has_text(block: Block) -> bool:
    def _check(node) -> bool:
        for child in (getattr(node, "children", []) or []):
            if getattr(child, "type", None) == "paragraph":
                if _norm((getattr(child, "content", {}) or {}).get("text", "")):
                    return True
            elif getattr(child, "type", None) == "shape":
                if _check(child):
                    return True
        return False
    return _check(block.node)


def _shape_has_content(block: Block) -> bool:
    """Shape có bất kỳ child nào (text hoặc không)."""
    return bool(getattr(block.node, "children", None))


# ══════════════════════════════════════════════════════════════════════════════
# Change builders theo type
# ══════════════════════════════════════════════════════════════════════════════

def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


def _make_change(
    cid:         int,
    change_type: str,
    heading:     Optional[str],
    order:       int,
    left:        Optional[Dict[str, Any]],
    right:       Optional[Dict[str, Any]],
    extra:       Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "id":          cid,
        "heading":     heading,
        "type":        change_type,
        "change_kind": _change_kind(left, right),
        "order":       order,
        "left":        left,
        "right":       right,
        **(extra or {}),
    }


def _process_paragraph(
    cid:      int,
    a:        Block,
    b:        Block,
    ai:       int,
    bj:       int,
    a_blocks: List[Block],
    b_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """
    Paragraph replace.
    Chỉ emit khi text thực sự khác — bỏ qua format-only change.
    Output:
      left/right : block side đầy đủ (text, style, alignment)
      word_diff  : spans highlight theo word + char level
    """
    old_raw = a.node.content.get("text", "")
    new_raw = b.node.content.get("text", "")
    old_display = a.node.content.get("text_display") or old_raw  # ← thêm
    new_display = b.node.content.get("text_display") or new_raw  # ← thêm

    if _norm(old_raw) == _norm(new_raw):
        return None

    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)

    return _make_change(
        cid=cid,
        change_type="paragraph_modified",
        heading=heading,
        order=order,
        left=_serialize_block_side(a),
        right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw, old_display=old_display, new_display=new_display),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_heading(
    cid:      int,
    a:        Block,
    b:        Block,
    ai:       int,
    bj:       int,
    a_blocks: List[Block],
    b_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """
    Heading replace.
    Emit heading_modified khi text hoặc level thực sự đổi.

    NOTE: opcode "replace" cho heading xảy ra khi:
      - Tên heading đổi (body khác nhau)
      - Level đổi (H1 → H2)
    Heading shift (số chương đổi, tên giữ) được align là "equal" → không vào đây.
    """
    old_raw   = a.node.content.get("text", "")
    new_raw   = b.node.content.get("text", "")
    old_norm  = _norm(old_raw)
    new_norm  = _norm(new_raw)
    old_level = int(a.node.content.get("level", 1) or 1)
    new_level = int(b.node.content.get("level", 1) or 1)

    if old_norm == new_norm and old_level == new_level:
        return None

    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)

    return _make_change(
        cid=cid,
        change_type="heading_modified",
        heading=heading,
        order=order,
        left=_serialize_block_side(a),
        right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw) if old_norm != new_norm else None,
            "old_level":     old_level,
            "new_level":     new_level,
            "level_changed": old_level != new_level,
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_table(
    cid, a, b, ai, bj, a_blocks, b_blocks
) -> Optional[Dict[str, Any]]:

    a_cols = int((a.node.content or {}).get("col_count", 0) or 0)
    b_cols = int((b.node.content or {}).get("col_count", 0) or 0)

    # col_count khác → layout thay đổi → skip diff, hiện full 2 bảng
    if a_cols > 0 and b_cols > 0 and a_cols != b_cols:
        from src.services.diff.table_diff import (
            _serialize_full_table, get_header_row,
            TABLE_RENDER_FULL
        )
        analysis = {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   True,
            "full_table_original": _serialize_full_table(a.node),
            "full_table_modified": _serialize_full_table(b.node),
            "header_row":          get_header_row(b.node),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }
        heading = a.heading_ctx or b.heading_ctx
        order   = min(a.order, b.order)
        return _make_change(
            cid=cid,
            change_type="table_modified",
            heading=heading,
            order=order,
            left=_serialize_block_side(a),
            right=_serialize_block_side(b),
            extra={
                "table_changes":  [],
                "table_analysis": analysis,
                "left_context":   _build_context(a_blocks, ai),
                "right_context":  _build_context(b_blocks, bj),
            },
        )

    # col_count giống → chạy diff bình thường
    table_changes = diff_table(a.node, b.node)
    analysis = analyze_table_change(
        a_tbl=a.node,
        b_tbl=b.node,
        table_changes=table_changes,
    )

    # analyze trả None → không có thay đổi gì
    if analysis is None:
        return None

    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)

    return _make_change(
        cid=cid,
        change_type="table_modified",
        heading=heading,
        order=order,
        left=_serialize_block_side(a),
        right=_serialize_block_side(b),
        extra={
            "table_changes":  analysis.get("table_changes") or [],
            "table_analysis": analysis,
            "left_context":   _build_context(a_blocks, ai),
            "right_context":  _build_context(b_blocks, bj),
        },
    )
def _process_shape(
    cid:      int,
    a:        Block,
    b:        Block,
    ai:       int,
    bj:       int,
    a_blocks: List[Block],
    b_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """
    Shape replace.
    Output:
      left/right         : shape side với shape_text_lines
      shape_changes      : paragraph-level diff từ diff_shape
      shape_cleared      : True nếu shape bị xóa hết text
      shape_text_preview : text preview ngắn để section header hiển thị
    """
    a_has_text = _shape_has_text(a)
    b_has_text = _shape_has_text(b)

    if not a_has_text and not b_has_text:
        return None

    left_side  = _serialize_shape_side(a)
    right_side = _serialize_shape_side(b)
    heading    = a.heading_ctx or b.heading_ctx
    order      = min(a.order, b.order)

    if a_has_text and not b_has_text:
        return _make_change(
            cid=cid,
            change_type="shape_modified",
            heading=heading,
            order=order,
            left=left_side,
            right=right_side,
            extra={
                "shape_cleared":      True,
                "shape_changes":      [],
                "shape_text_preview": (left_side or {}).get("shape_text_lines", []),
                "left_context":  _build_context(a_blocks, ai),
                "right_context": _build_context(b_blocks, bj),
            },
        )

    if not a_has_text and b_has_text:
        return _make_change(
            cid=cid,
            change_type="shape_modified",
            heading=heading,
            order=order,
            left=left_side,
            right=right_side,
            extra={
                "shape_cleared":      False,
                "shape_changes":      [],
                "shape_text_preview": (right_side or {}).get("shape_text_lines", []),
                "left_context":  _build_context(a_blocks, ai),
                "right_context": _build_context(b_blocks, bj),
            },
        )

    shape_changes = diff_shape(a.node, b.node)
    if not shape_changes:
        return None

    return _make_change(
        cid=cid,
        change_type="shape_modified",
        heading=heading,
        order=order,
        left=left_side,
        right=right_side,
        extra={
            "shape_cleared":      False,
            "shape_changes":      shape_changes,
            "shape_text_preview": (left_side or {}).get("shape_text_lines", []),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_image(
    cid:      int,
    a:        Block,
    b:        Block,
    ai:       int,
    bj:       int,
    a_blocks: List[Block],
    b_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """
    Image replace.
    Output:
      image_change: {type, change_kind, left_img, right_img}
    """
    if images_equal(a.node, b.node):
        return None

    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)

    return _make_change(
        cid=cid,
        change_type="image_modified",
        heading=heading,
        order=order,
        left=_serialize_block_side(a),
        right=_serialize_block_side(b),
        extra={
            "image_change":  build_image_change(a.node, b.node),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


# ══════════════════════════════════════════════════════════════════════════════
# Insert / Delete builders
# ══════════════════════════════════════════════════════════════════════════════

def _process_insert(
    cid:      int,
    b:        Block,
    bj:       int,
    b_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """Block hoàn toàn mới ở B."""
    if b.type == "shape" and not _shape_has_text(b) and not _shape_has_content(b):
        return None

    right_side = (
        _serialize_shape_side(b)
        if b.type == "shape"
        else _serialize_block_side(b)
    )

    extra: Dict[str, Any] = {
        "left_context":  None,
        "right_context": _build_context(b_blocks, bj),
    }

    if b.type == "table":
        extra["table_analysis"] = analyze_table_change(
            a_tbl=None, b_tbl=b.node, table_changes=[]
        )

    if b.type == "shape":
        extra["shape_text_preview"] = (right_side or {}).get("shape_text_lines", [])

    return _make_change(
        cid=cid,
        change_type=f"{b.type}_inserted",
        heading=b.heading_ctx,
        order=b.order,
        left=None,
        right=right_side,
        extra=extra,
    )


def _process_delete(
    cid:      int,
    a:        Block,
    ai:       int,
    a_blocks: List[Block],
) -> Optional[Dict[str, Any]]:
    """Block bị xóa khỏi A."""
    if a.type == "shape" and not _shape_has_text(a) and not _shape_has_content(a):
        return None

    left_side = (
        _serialize_shape_side(a)
        if a.type == "shape"
        else _serialize_block_side(a)
    )

    extra: Dict[str, Any] = {
        "left_context":  _build_context(a_blocks, ai),
        "right_context": None,
    }

    if a.type == "table":
        extra["table_analysis"] = analyze_table_change(
            a_tbl=a.node, b_tbl=None, table_changes=[]
        )

    if a.type == "shape":
        extra["shape_text_preview"] = (left_side or {}).get("shape_text_lines", [])

    return _make_change(
        cid=cid,
        change_type=f"{a.type}_deleted",
        heading=a.heading_ctx,
        order=a.order,
        left=left_side,
        right=None,
        extra=extra,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def build_ui_json(
    a_blocks: List[Block],
    b_blocks: List[Block],
    opcodes,
) -> Dict[str, Any]:
    """
    Build UI JSON từ aligned block opcodes.

    Args:
        a_blocks: Block list của file original.
        b_blocks: Block list của file modified.
        opcodes:  Kết quả từ align_blocks() — list (tag, i1, i2, j1, j2).

    Returns:
        {
          sections: [{heading, changes: [...]}]  ← group theo heading
          changes:  [...]                         ← flat list, sorted theo order
        }

    QUAN TRỌNG — opcode "equal":
        Bỏ qua hoàn toàn, KHÔNG check lại block.signature.
        Lý do: block.signature của shape chứa heading_ctx đầy đủ (kể cả số
        chương). Khi thêm nội dung trước heading, số chương có thể đổi → signature
        khác dù content không đổi. Nếu check lại sẽ emit replace sai.
        align_blocks() đã dùng content_sig (stable) để align → tin opcode.
    """
    sections_map: Dict[str, Dict[str, Any]] = {}
    flat_changes: List[Dict[str, Any]]      = []
    cid = 1

    def _add(change: Optional[Dict[str, Any]]) -> None:
        nonlocal cid
        if change is None:
            return
        heading = _section_key(change.get("heading"))
        if heading not in sections_map:
            sections_map[heading] = {"heading": heading, "changes": []}
        sections_map[heading]["changes"].append(change)
        flat_changes.append(change)
        cid += 1

    for tag, i1, i2, j1, j2 in opcodes:

        if tag == "equal":
            continue

        if tag == "insert":
            for j in range(j1, j2):
                _add(_process_insert(cid, b_blocks[j], j, b_blocks))

        elif tag == "delete":
            for i in range(i1, i2):
                _add(_process_delete(cid, a_blocks[i], i, a_blocks))

        elif tag == "replace":
            a_slice = a_blocks[i1:i2]
            b_slice = b_blocks[j1:j2]
            pairs   = min(len(a_slice), len(b_slice))

            for k in range(pairs):
                ai = i1 + k
                bj = j1 + k
                a  = a_blocks[ai]
                b  = b_blocks[bj]

                change: Optional[Dict[str, Any]] = None

                if a.type == "paragraph" and b.type == "paragraph":
                    change = _process_paragraph(cid, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "heading" and b.type == "heading":
                    change = _process_heading(cid, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "table" and b.type == "table":
                    change = _process_table(cid, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "shape" and b.type == "shape":
                    change = _process_shape(cid, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "image" and b.type == "image":
                    change = _process_image(cid, a, b, ai, bj, a_blocks, b_blocks)
                else:
                    heading = a.heading_ctx or b.heading_ctx
                    order   = min(a.order, b.order)
                    change  = _make_change(
                        cid=cid,
                        change_type=f"{a.type}_to_{b.type}_modified",
                        heading=heading,
                        order=order,
                        left=_serialize_block_side(a),
                        right=_serialize_block_side(b),
                        extra={
                            "left_context":  _build_context(a_blocks, ai),
                            "right_context": _build_context(b_blocks, bj),
                        },
                    )

                _add(change)

            for i in range(i1 + pairs, i2):
                _add(_process_delete(cid, a_blocks[i], i, a_blocks))

            for j in range(j1 + pairs, j2):
                _add(_process_insert(cid, b_blocks[j], j, b_blocks))

    # ── Sort và trả về ────────────────────────────────────────────────────────
    sort_key = lambda x: (x.get("order", 0), x.get("id", 0))

    ordered_sections = sorted(
        sections_map.values(),
        key=lambda s: min(
            (c.get("order", 0) for c in s["changes"]),
            default=0,
        ),
    )
    for section in ordered_sections:
        section["changes"] = sorted(section["changes"], key=sort_key)

    return {
        "sections": ordered_sections,
        "changes":  sorted(flat_changes, key=sort_key),
    }