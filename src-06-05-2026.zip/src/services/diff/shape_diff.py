# src/services/diff/shape_diff.py
"""
So sánh text trong 2 shape node.

Fix so với cũ:
  - _text_paragraphs: walk vào table trong shape để lấy paragraph bên trong cell
    (trước đây bỏ qua → text trong table-in-textbox không được diff).
  - replace N≠M: dùng SequenceMatcher thay vì zip theo index — tránh pair sai
    khi số paragraph 2 bên lệch nhau (vd a=[p1,p2,p3], b=[p1,p3] → zip pair
    a[1]=p2 với b[1]=p3 thay vì detect p2 bị delete).
  - Emit equal paragraphs để frontend có đủ context hiển thị.
  - Bỏ qua thay đổi format-only (text giống nhau → paragraph_equal).
"""

from __future__ import annotations

import difflib
import hashlib
from typing import Any, Dict, List, Optional

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.extractor.utils import norm_text as _norm_text



def _serialize_node(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if node is None:
        return None
    return {
        "uid":      getattr(node, "uid",   None),
        "type":     node.type,
        "display_type": node.type,
        "order":    getattr(node, "order", 0),
        "path":     getattr(node, "path",  ""),
        "content":  node.content or {},
        "children": [_serialize_node(c) for c in (node.children or [])],
    }


def _text_paragraphs(shape_node: DocNode) -> List[DocNode]:
    """
    Thu thập tất cả paragraph có text từ shape, đệ quy vào:
      - shape lồng nhau (textbox trong textbox)
      - table trong textbox (walk vào cell → paragraph)

    Trước đây bỏ qua table → text trong table-in-textbox không được diff.
    """
    result: List[DocNode] = []
    for c in (shape_node.children or []):
        if c.type == "paragraph":
            if _norm_text(c.content.get("text", "")):
                result.append(c)
        elif c.type == "shape":
            result.extend(_text_paragraphs(c))
        elif c.type == "table":
            # Walk vào table → row → cell → paragraph
            for row in (c.children or []):
                if row.type != "row":
                    continue
                for cell in (row.children or []):
                    if cell.type != "cell":
                        continue
                    result.extend(_text_paragraphs_from_cell(cell))
    return result


def _text_paragraphs_from_cell(cell: DocNode) -> List[DocNode]:
    """Thu thập paragraph có text từ 1 cell (đệ quy nested table)."""
    result: List[DocNode] = []
    for c in (cell.children or []):
        if c.type == "paragraph":
            if _norm_text(c.content.get("text", "")):
                result.append(c)
        elif c.type == "table":
            for row in (c.children or []):
                if row.type != "row":
                    continue
                for child_cell in (row.children or []):
                    if child_cell.type == "cell":
                        result.extend(_text_paragraphs_from_cell(child_cell))
    return result


def _para_sig(node: DocNode) -> str:
    """
    Signature chỉ dựa trên text — bỏ qua style/alignment/format.

    Design decision: shape_diff chỉ diff nội dung text, không diff format.
    Hai paragraph cùng text nhưng khác bold/italic → coi là equal (paragraph_equal).
    Nếu cần diff format, caller cần xử lý riêng ở lớp trên.
    """
    txt = _norm_text(node.content.get("text", ""))
    h   = hashlib.md5(txt.encode("utf-8")).hexdigest()[:16] if txt else "empty"
    return f"P:{h}"


def _build_change(
    cid:         int,
    change_type: str,
    change_kind: str,
    original:    Optional[Dict[str, Any]],
    modified:    Optional[Dict[str, Any]],
    word_diff:   Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    # display_type = tên type bỏ suffix _modified/_inserted/_deleted/_equal
    display = (
        change_type
        .replace("_modified", "")
        .replace("_inserted", "")
        .replace("_deleted",  "")
        .replace("_equal",    "")
    )
    return {
        "id":            cid,
        "type":          change_type,
        "display_type":  display,
        "change_kind":   change_kind,
        "original":      original,
        "modified":      modified,
        "left_context":  original,
        "right_context": modified,
        "word_diff":     word_diff,
    }


def diff_shape(a_shape: DocNode, b_shape: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh text trong 2 shape node.

    Chỉ xét paragraph có text thực sự (qua _text_paragraphs).
    Bỏ qua: image standalone, paragraph rỗng, thay đổi format/style.
    Trả về [] nếu không có thay đổi text nào.

    Emit cả "equal" paragraphs để frontend có đủ context hiển thị toàn bộ shape
    — không chỉ highlight những dòng thay đổi.

    replace N≠M: dùng SequenceMatcher trên _para_sig thay vì zip theo index
    → pair đúng dù số paragraph 2 bên lệch nhau.
    """
    a_paras = _text_paragraphs(a_shape)
    b_paras = _text_paragraphs(b_shape)

    if not a_paras and not b_paras:
        return []

    a_sigs = [_para_sig(p) for p in a_paras]
    b_sigs = [_para_sig(p) for p in b_paras]

    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    opcodes = sm.get_opcodes()

    # Kiểm tra xem có thay đổi thực sự không
    has_real_change = any(tag != "equal" for tag, *_ in opcodes)
    if not has_real_change:
        return []

    changes: List[Dict[str, Any]] = []
    cid = 1

    for tag, i1, i2, j1, j2 in opcodes:

        # ── EQUAL ─────────────────────────────────────────────────────────────
        if tag == "equal":
            for k in range(i2 - i1):
                a_node = a_paras[i1 + k]
                b_node = b_paras[j1 + k]
                changes.append(_build_change(
                    cid=cid,
                    change_type="paragraph_equal",
                    change_kind="equal",
                    original=_serialize_node(a_node),
                    modified=_serialize_node(b_node),
                ))
                cid += 1
            continue

        # ── INSERT ────────────────────────────────────────────────────────────
        if tag == "insert":
            for node in b_paras[j1:j2]:
                changes.append(_build_change(
                    cid=cid,
                    change_type="paragraph_inserted",
                    change_kind="insert",
                    original=None,
                    modified=_serialize_node(node),
                ))
                cid += 1
            continue

        # ── DELETE ────────────────────────────────────────────────────────────
        if tag == "delete":
            for node in a_paras[i1:i2]:
                changes.append(_build_change(
                    cid=cid,
                    change_type="paragraph_deleted",
                    change_kind="delete",
                    original=_serialize_node(node),
                    modified=None,
                ))
                cid += 1
            continue

        # ── REPLACE ───────────────────────────────────────────────────────────
        # SequenceMatcher đã align tốt nhất có thể — dùng kết quả đó trực tiếp.
        # 1-1: pair và diff word
        # N-1 hoặc 1-M: pair những gì có thể, phần còn lại → delete/insert
        if tag == "replace":
            a_slice = a_paras[i1:i2]
            b_slice = b_paras[j1:j2]
            pairs   = min(len(a_slice), len(b_slice))

            # Pair 1-1 theo thứ tự — SequenceMatcher đã đảm bảo thứ tự tốt nhất
            for k in range(pairs):
                a_node = a_slice[k]
                b_node = b_slice[k]
                old    = _norm_text(a_node.content.get("text", ""))
                new    = _norm_text(b_node.content.get("text", ""))

                if old != new:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_modified",
                        change_kind="replace",
                        original=_serialize_node(a_node),
                        modified=_serialize_node(b_node),
                        word_diff=diff_words(
                        old, new,
                        old_display=a_node.content.get("text_display") or old,
                        new_display=b_node.content.get("text_display") or new,
                    ),
                    ))
                else:
                    # Text giống nhau (chỉ khác format) → emit equal
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_equal",
                        change_kind="equal",
                        original=_serialize_node(a_node),
                        modified=_serialize_node(b_node),
                    ))
                cid += 1

            # Phần dư bên a → delete
            for node in a_slice[pairs:]:
                changes.append(_build_change(
                    cid=cid,
                    change_type="paragraph_deleted",
                    change_kind="delete",
                    original=_serialize_node(node),
                    modified=None,
                ))
                cid += 1

            # Phần dư bên b → insert
            for node in b_slice[pairs:]:
                changes.append(_build_change(
                    cid=cid,
                    change_type="paragraph_inserted",
                    change_kind="insert",
                    original=None,
                    modified=_serialize_node(node),
                ))
                cid += 1

    return changes