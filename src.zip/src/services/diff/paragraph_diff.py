# src/services/diff/paragraph_diff.py
"""
So sánh 2 đoạn text ở mức word, với char-level diff bên trong từng word replace.

Fix so với cũ:
  - Cursor tracking đúng cho cả delete/insert (old_cursor và new_cursor độc lập)
  - char_diff tính trên toàn segment (không chỉ single word)
  - Guard empty input
  - Cursor +1 cho space chỉ áp dụng khi còn opcode phía sau — tránh over-count
    ở segment cuối của toàn bộ string
"""

from __future__ import annotations

import difflib
from typing import Any, Dict, List, Optional

from src.services.extractor.utils import norm_text as _norm, norm_for_diff


def _char_diff_spans(old_seg: str, new_seg: str) -> Dict[str, Any]:
    sm = difflib.SequenceMatcher(a=list(old_seg), b=list(new_seg), autojunk=False)
    old_chars: List[Dict[str, Any]] = []
    new_chars: List[Dict[str, Any]] = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        old_part = old_seg[i1:i2]
        new_part = new_seg[j1:j2]

        if tag == "equal":
            old_chars.append({"type": "equal", "text": old_part})
            new_chars.append({"type": "equal", "text": new_part})
        elif tag == "delete":
            old_chars.append({"type": "delete", "text": old_part})
        elif tag == "insert":
            new_chars.append({"type": "insert", "text": new_part})
        elif tag == "replace":
            old_chars.append({"type": "delete", "text": old_part})
            new_chars.append({"type": "insert", "text": new_part})

    return {"old_chars": old_chars, "new_chars": new_chars}


def diff_words(
    old_text: str,
    new_text: str,
    old_display: Optional[str] = None,
    new_display: Optional[str] = None,
) -> Dict[str, Any]:
    # norm_for_diff để tokenize — xử lý đúng punctuation và ngoặc
    old_norm = norm_for_diff(old_text or "")
    new_norm = norm_for_diff(new_text or "")

    # raw display giữ nguyên
    old_raw = (old_display or "").strip() or norm_for_diff(old_text or "")
    new_raw = (new_display or "").strip() or norm_for_diff(new_text or "")
    if not old_norm and not new_norm:
        return {"old_full_text": old_raw, "new_full_text": new_raw, "spans": []}

    if old_norm == new_norm:
        return {
            "old_full_text": old_raw,
            "new_full_text": new_raw,
            "spans": [{
                "type":      "equal",
                "action":    "equal",
                "side":      "both",
                "old_text":  old_raw,
                "new_text":  new_raw,
                "text":      old_raw,
                "old_start": 0,
                "old_end":   len(old_norm),
                "new_start": 0,
                "new_end":   len(new_norm),
                "char_diff": None,
            }],
        }

    a = old_norm.split()
    b = new_norm.split()

    def _word_offsets(words: List[str]) -> List[int]:
        offsets = []
        pos = 0
        for w in words:
            offsets.append(pos)
            pos += len(w) + 1
        return offsets

    a_offsets = _word_offsets(a)
    b_offsets = _word_offsets(b)

    sm    = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    spans: List[Dict[str, Any]] = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        old_words   = a[i1:i2]
        new_words   = b[j1:j2]
        old_segment = " ".join(old_words)
        new_segment = " ".join(new_words)

        old_start = a_offsets[i1] if i1 < len(a_offsets) else len(old_norm)
        new_start = b_offsets[j1] if j1 < len(b_offsets) else len(new_norm)
        old_end   = old_start + len(old_segment)
        new_end   = new_start + len(new_segment)

        if tag == "equal":
            if old_segment:
                spans.append({
                    "type": "equal", "action": "equal", "side": "both",
                    "old_text": old_segment, "new_text": old_segment, "text": old_segment,
                    "old_start": old_start, "old_end": old_end,
                    "new_start": new_start, "new_end": new_end,
                    "char_diff": None,
                })
            continue

        if tag == "delete":
            if old_segment:
                spans.append({
                    "type": "delete", "action": "delete", "side": "left",
                    "old_text": old_segment, "new_text": "", "text": old_segment,
                    "old_start": old_start, "old_end": old_end,
                    "new_start": new_start, "new_end": new_start,
                    "char_diff": None,
                })
            continue

        if tag == "insert":
            if new_segment:
                spans.append({
                    "type": "insert", "action": "insert", "side": "right",
                    "old_text": "", "new_text": new_segment, "text": new_segment,
                    "old_start": old_start, "old_end": old_start,
                    "new_start": new_start, "new_end": new_end,
                    "char_diff": None,
                })
            continue

        if tag == "replace":
            char_diff: Optional[Dict[str, Any]] = None
            if old_segment and new_segment:
                char_diff = _char_diff_spans(old_segment, new_segment)
            spans.append({
                "type": "replace", "action": "replace", "side": "both",
                "old_text": old_segment, "new_text": new_segment, "text": old_segment,
                "old_start": old_start, "old_end": old_end,
                "new_start": new_start, "new_end": new_end,
                "char_diff": char_diff,
            })

    return {
        "old_full_text": old_raw,
        "new_full_text": new_raw,
        "spans":         spans,
    }