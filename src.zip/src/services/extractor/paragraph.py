"""
extractor/paragraph.py
~~~~~~~~~~~~~~~~~~~~~~
Extract paragraph và heading từ docx thành DocNode.

Chịu trách nhiệm:
    - Detect heading style và level
    - Trích xuất runs (text + formatting)
    - Build paragraph/heading DocNode (kể cả ảnh inline)
    - Shape tách ra ngoài thành sibling node

KHÔNG xử lý: table, cell, TOC tracking, shape extraction.
Import từ: utils.py, image.py, shape.py
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional

from docx.text.paragraph import Paragraph

from src.services.models.docnode import DocNode
from src.services.extractor.image import extract_inline_images
from src.services.extractor.shape import extract_shapes_from_paragraph
from src.services.extractor.utils import OrderRef, norm_text, next_order, safe_pt


# ══════════════════════════════════════════════════════════════════════════════
# Heading helpers
# ══════════════════════════════════════════════════════════════════════════════

_HEADING_RE = re.compile(r"heading\s*(\d+)", re.IGNORECASE)


def heading_level(style_name: str) -> int:
    """Trả level 1–9 nếu là heading style, else 0."""
    if not style_name:
        return 0
    m = _HEADING_RE.search(style_name.strip())
    return int(m.group(1)) if m else 0


def is_heading(par: Paragraph) -> bool:
    name = (par.style.name if par.style else "") or ""
    return name.strip().lower().startswith("heading")


# ══════════════════════════════════════════════════════════════════════════════
# Run extractor
# ══════════════════════════════════════════════════════════════════════════════

def extract_runs(par: Paragraph) -> List[Dict]:
    """
    Trích xuất từng run với định dạng đầy đủ.
    Chỉ bỏ qua run hoàn toàn rỗng (text == "").
    """
    runs = []
    for idx, run in enumerate(par.runs):
        text = run.text
        if text == "":
            continue

        font = run.font

        try:
            color = str(font.color.rgb) if font.color.rgb else None
        except Exception:
            color = None

        try:
            highlight = str(font.highlight_color) if font.highlight_color else None
        except Exception:
            highlight = None

        runs.append({
            "index":     idx,
            "text":      text,
            "bold":      bool(run.bold)      if run.bold      is not None else False,
            "italic":    bool(run.italic)    if run.italic    is not None else False,
            "underline": bool(run.underline) if run.underline is not None else False,
            "font_name": font.name           if font else None,
            "font_size": font.size.pt        if font and font.size else None,
            "color":     color,
            "highlight": highlight,
        })

    return runs


# ══════════════════════════════════════════════════════════════════════════════
# Line spacing helper
# ══════════════════════════════════════════════════════════════════════════════

def extract_line_spacing(pf) -> Optional[Dict]:
    try:
        ls = pf.line_spacing
        if ls is None:
            return None
        if hasattr(ls, "pt"):
            return {"type": "exact_pt", "value": ls.pt}
        return {"type": "multiple", "value": float(ls)}
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph content builder
# ══════════════════════════════════════════════════════════════════════════════

def build_paragraph_content(
    par: Paragraph,
    imgs: List[DocNode],
    shapes: List[DocNode],
    in_toc: bool,
) -> Dict:
    """Tạo content dict dùng chung cho cả paragraph và heading."""
    style_name = (par.style.name if par.style else "") or ""
    pf         = par.paragraph_format
    text       = norm_text(par.text)

    return {
        "text":              text,
        "style":             style_name,
        "alignment":         par.alignment,
        "is_heading":        is_heading(par),
        "heading_level":     heading_level(style_name),
        "space_before":      safe_pt(pf.space_before),
        "space_after":       safe_pt(pf.space_after),
        "left_indent":       safe_pt(pf.left_indent),
        "right_indent":      safe_pt(pf.right_indent),
        "first_line_indent": safe_pt(pf.first_line_indent),
        "line_spacing":      extract_line_spacing(pf),
        "keep_together":     bool(pf.keep_together)     if pf.keep_together     is not None else False,
        "keep_with_next":    bool(pf.keep_with_next)    if pf.keep_with_next    is not None else False,
        "page_break_before": bool(pf.page_break_before) if pf.page_break_before is not None else False,
        "widow_control":     bool(pf.widow_control)     if pf.widow_control     is not None else False,
        "run_count":         len(par.runs),
        "runs":              extract_runs(par),
        "image_count":       len(imgs),
        "shape_count":       len(shapes),
        "in_toc":            in_toc,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_paragraph_nodes(
    par: Paragraph,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    in_toc: bool = False,
) -> List[DocNode]:
    imgs   = extract_inline_images(
        par,
        uid_prefix=f"{uid}.img",
        parent_uid=uid,
        order_ref=None,          
    )
    shapes = extract_shapes_from_paragraph(
        par,
        uid_prefix=f"{uid}.shp",
        parent_uid=parent_uid,
        order_ref=None,          # ← tương tự
    )
    text    = norm_text(par.text)
    content = build_paragraph_content(par, imgs, shapes, in_toc)

    # ── Heading ───────────────────────────────────────────────────────────────
    if is_heading(par):
        node = DocNode(
            type="heading",
            uid=uid,
            parent_uid=parent_uid,
            order=next_order(order_ref),
            path=uid.replace(".", "/"),
            content={
                **content,
                "level": heading_level(par.style.name if par.style else ""),
            },
        )
        # Gán order thực cho từng image sau khi chắc chắn heading được tạo
        for img in imgs:
            img.order = next_order(order_ref)
            node.add_child(img)
        return [node]

    # ── Paragraph thường ──────────────────────────────────────────────────────
    nodes: List[DocNode] = []

    if text or imgs:
        pnode = DocNode(
            type="paragraph",
            uid=uid,
            parent_uid=parent_uid,
            order=next_order(order_ref),
            path=uid.replace(".", "/"),
            content=content,
        )
        # Gán order thực cho từng image sau khi chắc chắn paragraph được tạo
        for img in imgs:
            img.order = next_order(order_ref)
            pnode.add_child(img)
        nodes.append(pnode)

    # Shape là sibling, không phải child của paragraph.
    # Gán order thực tại đây (shapes luôn được emit dù paragraph rỗng).
    for shp in shapes:
        shp.order = next_order(order_ref)
        nodes.append(shp)

    return nodes