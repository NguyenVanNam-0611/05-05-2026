"""
extractor/utils.py
~~~~~~~~~~~~~~~~~~
Các helper thuần tuý dùng chung cho toàn bộ extractor.

Chỉ chứa những thứ KHÔNG phụ thuộc vào docx object:
    - norm_text  : chuẩn hoá chuỗi để so sánh / diff
    - raw_text   : giữ layout gốc để hiển thị UI
    - next_order : tăng counter thứ tự (None-safe)
    - safe_pt    : lấy giá trị pt an toàn
    - OrderRef   : type alias cho mutable counter

Iterator nằm trong file dùng chúng:
    - document.py → _iter_block_items
    - table.py    → _iter_cell_items
"""

from __future__ import annotations

import unicodedata
from typing import Dict, Optional
import re
# ── Types ─────────────────────────────────────────────────────────────────────

OrderRef = Dict[str, int]   # {"value": int} — mutable int counter


# ══════════════════════════════════════════════════════════════════════════════
# Internal: translation tables (build once at import time)
# ══════════════════════════════════════════════════════════════════════════════

# Space variants → space thường
# (non-breaking space, en/em space, thin space, CJK space, …)
_SPACE_VARIANTS = (
    "\u00a0"  # non-breaking space
    "\u2002"  # en space
    "\u2003"  # em space
    "\u2004"  # three-per-em space
    "\u2005"  # four-per-em space
    "\u2006"  # six-per-em space
    "\u2007"  # figure space
    "\u2008"  # punctuation space
    "\u2009"  # thin space
    "\u200a"  # hair space
    "\u202f"  # narrow no-break space
    "\u3000"  # ideographic space (CJK)
)

# Ký tự zero-width và Word internal break → xóa hẳn
# Rất phổ biến trong văn bản tiếng Việt copy-paste vào Word
_DROP_CHARS = (
    "\u200b"  # zero-width space
    "\u200c"  # zero-width non-joiner
    "\u200d"  # zero-width joiner
    "\u2060"  # word joiner
    "\ufeff"  # BOM / zero-width no-break space
    "\u00ad"  # soft hyphen
    "\x0b"    # vertical tab — Word dùng cho Shift+Enter trong cell
    "\x0c"    # form feed — page break
    "\x1c"    # file separator
    "\x1d"    # group separator
    "\x1e"    # record separator
)

_TO_SPACE_TABLE = str.maketrans(_SPACE_VARIANTS, " " * len(_SPACE_VARIANTS))
_DROP_TABLE     = str.maketrans("", "", _DROP_CHARS)
_PUNCT_SPACE_RE = re.compile(r'([,;.])\s*(?=[\w(])')

# Xóa space thừa bên trong ngoặc: "ST( Ashitaka )" → "ST(Ashitaka)"
_PAREN_INNER_RE = re.compile(r'\(\s+|\s+\)')
_PUNCT_DETACH_RE = re.compile(r'([,;.])')

# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def norm_text(s: str) -> str:
    """
    Chuẩn hoá text để so sánh / diff — KHÔNG dùng để hiển thị UI.

    Pipeline:
      1. NFC normalize  → đảm bảo dấu tiếng Việt nhất quán
      2. Xóa zero-width + Word internal break characters
      3. Map space variants → space thường; \\n \\r \\t → space
      4. Normalize dấu phẩy/chấm phẩy: luôn có đúng 1 space sau, không có space trước
         "OT4,OT5" → "OT4, OT5"  |  "OT4 , OT5" → "OT4, OT5"
      5. Xóa space thừa bên trong ngoặc
         "ST( Ashitaka )" → "ST(Ashitaka)"
      6. Collapse whitespace và strip
    """
    if not s:
        return ""

    # 1. NFC
    s = unicodedata.normalize("NFC", s)

    # 2. Xóa zero-width + Word internal breaks
    s = s.translate(_DROP_TABLE)

    # 3. Space variants và control chars → space thường
    s = s.translate(_TO_SPACE_TABLE)
    s = s.replace("\n", " ").replace("\r", " ").replace("\t", " ")

    # 4. Normalize dấu phẩy/chấm phẩy
    # space trước dấu câu → xóa: "OT4 , OT5" → "OT4, OT5"
    # không có space sau → thêm: "OT4,OT5" → "OT4, OT5"
    # nhiều space sau → collapse: "OT4,  OT5" → "OT4, OT5"
    s = re.sub(r'\s*([,;])\s*', r'\1 ', s)

    # 5. Xóa space thừa bên trong ngoặc
    # "ST( Ashitaka )" → "ST(Ashitaka)"
    # "ST( Single Mesh )" → "ST(Single Mesh)"
    s = re.sub(r'\(\s+', '(', s)
    s = re.sub(r'\s+\)', ')', s)

    # 6. Collapse và strip
    return " ".join(s.split())

def norm_for_diff(s: str) -> str:
    """
    Chuẩn hoá để diff word-level chính xác hơn.
    Dùng thay cho norm_text khi tính token để so sánh.

    Thêm so với norm_text:
      1. Xóa space thừa bên trong ngoặc
         "ST( Ashitaka)" → "ST(Ashitaka)"
      2. Tách dấu câu thành token riêng
         "ST(Ashitaka),"  → "ST(Ashitaka) ,"
         "Mesh),ST"       → "Mesh) , ST"
      3. Space sau dấu câu nếu theo sau là chữ/số/ngoặc mở
         "Mesh).\nST"     → "Mesh) . ST"
      4. \n / \r / \t đã được norm_text collapse về space trước bước này
    """
    s = norm_text(s)
    s = _PAREN_INNER_RE.sub(lambda m: m.group().strip(), s)  # xóa space thừa trong ngoặc
    s = _PUNCT_DETACH_RE.sub(r' \1 ', s)                     # tách dấu câu thành token riêng
    return ' '.join(s.split())                                # collapse

def raw_text(s: str) -> str:
    """
    Giữ nguyên layout gốc để hiển thị UI.

    Chỉ:
      - NFC normalize (dấu tiếng Việt nhất quán)v
      - Thay space variants → space thường (vẫn giữ newline)
      - Xóa zero-width silently
      - Strip đầu/cuối
    """
    if not s:
        return ""

    s = unicodedata.normalize("NFC", s)
    s = s.translate(_DROP_TABLE)
    s = s.translate(_TO_SPACE_TABLE)
    return s.strip()


def next_order(order_ref: Optional[OrderRef]) -> int:
    """
    Tăng counter và trả về giá trị mới.
    Trả 0 nếu order_ref là None (dùng trong shape.py khi không có context).
    """
    if order_ref is None:
        return 0
    order_ref["value"] += 1
    return order_ref["value"]


def safe_pt(value) -> Optional[float]:
    """Lấy giá trị pt từ Length object, trả None nếu không có."""
    try:
        return value.pt if value is not None else None
    except Exception:
        return None