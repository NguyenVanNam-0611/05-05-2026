"""
models/docnode.py
~~~~~~~~~~~~~~~~~
Node cơ bản trong cây tài liệu.

Cây có dạng:
    document
    ├── heading
    │         └── image
    ├── paragraph (content: text)
    │         └── image
    ├── table
    │   └── row
    │       └── cell
    │           ├── paragraph (content: text)
    │           │         └── image
    │           ├── table          ← nested table
    │           └── shape
    └── shape
            ├── image
            ├── paragraph (content: text)
            └── table

Quy tắc con hợp lệ (VALID_CHILDREN):
    document  → heading, paragraph, image, table, shape
    table     → row
    row       → cell
    cell      → paragraph, image, table, shape
    shape     → image, paragraph, table
    paragraph → image
    heading   → image
    image     → (leaf)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

# ---------------------------------------------------------------------------
# Quy tắc cây — immutable để tránh bị mutate ngoài ý muốn
# ---------------------------------------------------------------------------

VALID_CHILDREN: Dict[str, frozenset] = {
    "document":  frozenset({"heading", "paragraph", "image", "table", "shape"}),
    "table":     frozenset({"row"}),
    "row":       frozenset({"cell"}),
    "cell":      frozenset({"paragraph", "image", "table", "shape"}),
    "shape":     frozenset({"image", "paragraph", "table"}),
    "paragraph": frozenset({"image"}),
    "heading":   frozenset({"image"}),
    "image":     frozenset(),
}

# ---------------------------------------------------------------------------
# DocNode
# ---------------------------------------------------------------------------

@dataclass
class DocNode:
    """
    Một node trong cây tài liệu.

    Attributes:
        type:       Loại node — phải khớp với key trong VALID_CHILDREN,
                    hoặc là type mở rộng chưa đăng ký (không bị reject).
        content:    Dữ liệu thô của node (text, alt_text, src, …).
        children:   Các node con theo thứ tự tài liệu.
        uid:        ID duy nhất do pipeline gán; None nếu chưa gán.
        parent_uid: uid của node cha; None nếu là root hoặc chưa gán.
        order:      Thứ tự xuất hiện trong node cha (0-based).
        path:       Đường dẫn nguồn (tên file, sheet, …).
        parent:     Tham chiếu ngược tới node cha — không serialize,
                    không tham gia so sánh, không hiện trong repr.
    """

    type: str
    content: Dict[str, Any] = field(default_factory=dict)
    children: List["DocNode"] = field(default_factory=list)

    uid: Optional[str] = None
    parent_uid: Optional[str] = None
    order: int = 0
    path: Optional[str] = None

    parent: Optional["DocNode"] = field(default=None, repr=False, compare=False)

    # ── Validation ────────────────────────────────────────────────────────────

    def __post_init__(self) -> None:
        if not self.type:
            raise ValueError("DocNode.type must not be empty.")

    def _assert_valid_child(self, child: "DocNode") -> None:
        """
        Kiểm tra child.type có được phép nằm dưới self.type không.
        Bỏ qua nếu self.type chưa có trong VALID_CHILDREN (extensible).
        """
        allowed = VALID_CHILDREN.get(self.type)
        if allowed is None:
            return  # type mở rộng — không enforce
        if child.type not in allowed:
            label = sorted(allowed) if allowed else "không có (leaf node)"
            raise ValueError(
                f"'{child.type}' không được phép là con của '{self.type}'. "
                f"Hợp lệ: {label}"
            )

    # ── Tree manipulation ─────────────────────────────────────────────────────

    def add_child(self, child: "DocNode") -> None:
        """
        Thêm node con vào cuối danh sách children.

        Tự động set child.parent = self và child.parent_uid = self.uid.
        Raise TypeError nếu child không phải DocNode.
        Raise ValueError nếu child.type không được phép theo VALID_CHILDREN.
        """
        if not isinstance(child, DocNode):
            raise TypeError(f"Expected DocNode, got {type(child).__name__!r}.")
        self._assert_valid_child(child)
        child.parent = self
        child.parent_uid = self.uid
        self.children.append(child)

    def is_leaf(self) -> bool:
        """True nếu node không có children."""
        return len(self.children) == 0

    # ── Convenience iterators ─────────────────────────────────────────────────

    @property
    def text(self) -> str:
        """Shortcut lấy text từ content (paragraph / heading)."""
        return self.content.get("text", "")

    def iter_tables(self) -> Iterator["DocNode"]:
        """Yield tất cả node type='table' trong cây (kể cả nested)."""
        yield from self.find("table")

    def iter_images(self) -> Iterator["DocNode"]:
        """Yield tất cả node type='image' trong cây."""
        yield from self.find("image")

    def iter_cells(self) -> Iterator["DocNode"]:
        """Yield tất cả node type='cell' trong cây."""
        yield from self.find("cell")

    # ── Traversal ─────────────────────────────────────────────────────────────

    def walk(self) -> Iterator["DocNode"]:
        """
        DFS pre-order generator qua toàn bộ cây.
        Không build list trung gian trong memory.
        """
        yield self
        for child in self.children:
            yield from child.walk()

    def find(self, node_type: str) -> Iterator["DocNode"]:
        """Yield tất cả node có type == node_type trong cây."""
        for node in self.walk():
            if node.type == node_type:
                yield node

    # ── Equality & hashing ────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        """
        So sánh theo uid nếu cả hai đều có uid.
        Fallback về identity nếu thiếu uid — tránh false positive.
        """
        if not isinstance(other, DocNode):
            return NotImplemented
        if self.uid is not None and other.uid is not None:
            return self.uid == other.uid
        return self is other

    def __hash__(self) -> int:
        return hash(self.uid) if self.uid is not None else id(self)

    # ── Serialization ─────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize thành dict thuần (JSON-safe).
        Trường `parent` bị bỏ qua để tránh circular reference.
        """
        return {
            "uid":        self.uid,
            "parent_uid": self.parent_uid,
            "order":      self.order,
            "path":       self.path,
            "type":       self.type,
            "content":    self.content,
            "children":   [c.to_dict() for c in self.children],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DocNode":
        """
        Dựng lại cây từ dict (output của to_dict).
        Dùng add_child để parent / parent_uid được set đúng ở mọi tầng.
        """
        node = cls(
            type=data["type"],
            content=data.get("content", {}),
            uid=data.get("uid"),
            parent_uid=data.get("parent_uid"),
            order=data.get("order", 0),
            path=data.get("path"),
        )
        for child_data in data.get("children", []):
            node.add_child(cls.from_dict(child_data))
        return node

    # ── Debug ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"DocNode("
            f"type={self.type!r}, "
            f"uid={self.uid!r}, "
            f"order={self.order}, "
            f"children={len(self.children)}"
            f")"
        )