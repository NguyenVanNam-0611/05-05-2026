"""
models/block.py
~~~~~~~~~~~~~~~
Block là wrapper phẳng của DocNode, dùng cho bước align và diff.

Mỗi Block đại diện cho 1 đơn vị so sánh ở document level:
    - heading
    - paragraph
    - image
    - shape
    - table     ← diff nội dung bên trong do TableDiff xử lý riêng

KHÔNG tạo Block cho: row, cell (chỉ tồn tại bên trong TableDiff).

block_builder.py chịu trách nhiệm duyệt DocNode tree và tạo List[Block].
Block không tự tính signature — signature được inject từ signature.py.

Equality:
    - Có signature → so sánh theo nội dung (content-based).
      Hai block khác uid nhưng nội dung giống nhau sẽ bằng nhau.
      Dùng `a is b` nếu cần so sánh identity.
    - Không có signature → so sánh theo uid.
    - Không có cả hai → fallback identity (self is other).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from src.services.models.docnode import DocNode

BlockType = str

BLOCK_TYPES: frozenset[str] = frozenset({
    "heading",
    "paragraph",
    "image",
    "shape",
    "table",
})

# ---------------------------------------------------------------------------
# Block
# ---------------------------------------------------------------------------

@dataclass
class Block:
    """
    Wrapper phẳng của một DocNode, dùng cho bước align và diff.

    Attributes:
        type:          Loại block — phải thuộc BLOCK_TYPES.
        node:          DocNode gốc.
        signature:     Hash nội dung — inject từ signature.py sau khi build.
        heading_ctx:   Tiêu đề cha gần nhất — inject từ block_builder.
        heading_level: Cấp heading (1–6) — inject từ block_builder.
        uid:           Auto-fill từ node.uid nếu không truyền vào.
        parent_uid:    Auto-fill từ node.parent_uid nếu không truyền vào.
        path:          Auto-fill từ node.path nếu không truyền vào.
        order:         Auto-fill từ node.order nếu không truyền vào (None).
    """

    type: BlockType
    node: DocNode

    # inject từ signature.py sau khi build
    signature: str = ""

    # inject từ block_builder sau khi duyệt cây
    heading_ctx: Optional[str] = None
    heading_level: int = 0

    # auto-fill từ node trong __post_init__
    uid: Optional[str] = None
    parent_uid: Optional[str] = None
    path: Optional[str] = None
    order: Optional[int] = None  # None = chưa set; 0 là vị trí hợp lệ

    # flags — tính từ type, không nhận từ caller
    is_heading:   bool = field(default=False, init=False)
    is_paragraph: bool = field(default=False, init=False)
    is_image:     bool = field(default=False, init=False)
    is_shape:     bool = field(default=False, init=False)
    is_table:     bool = field(default=False, init=False)

    # text ngắn cho log / debug
    preview_text: str = field(default="", init=False)

    # ── Init ──────────────────────────────────────────────────────────────────

    def __post_init__(self) -> None:
        if not isinstance(self.node, DocNode):
            raise TypeError(
                f"Block.node must be DocNode, got {type(self.node).__name__!r}."
            )
        if self.type not in BLOCK_TYPES:
            raise ValueError(
                f"Block.type {self.type!r} không hợp lệ. "
                f"Hợp lệ: {sorted(BLOCK_TYPES)}"
            )

        # Auto-fill metadata từ node
        if self.uid is None:
            self.uid = self.node.uid
        if self.parent_uid is None:
            self.parent_uid = self.node.parent_uid
        if self.path is None:
            self.path = self.node.path
        if self.order is None:
            self.order = self.node.order

        # Flags
        self.is_heading   = self.type == "heading"
        self.is_paragraph = self.type == "paragraph"
        self.is_image     = self.type == "image"
        self.is_shape     = self.type == "shape"
        self.is_table     = self.type == "table"

        self.preview_text = self._build_preview()

    # ── Preview ───────────────────────────────────────────────────────────────

    def _build_preview(self) -> str:
        """
        Tạo chuỗi mô tả ngắn (tối đa 200 ký tự) cho log / debug.
        Không dùng cho diff — dùng get_text() cho mục đích đó.
        """
        content = self.node.content

        if self.type in ("heading", "paragraph"):
            text = content.get("text") or ""

        elif self.type == "image":
            alt  = content.get("alt_text") or ""
            text = f"[IMAGE: {alt}]" if alt else "[IMAGE]"

        elif self.type == "shape":
            # Lấy text từ child paragraph đầu tiên
            para  = next(
                (c for c in self.node.children if c.type == "paragraph"),
                None,
            )
            inner = (para.content.get("text") or "") if para else ""
            text  = f"[SHAPE: {inner}]" if inner else "[SHAPE]"

        elif self.type == "table":
            rows   = self.node.children
            n_rows = len(rows)
            n_cols = len(rows[0].children) if rows else 0
            text   = f"[TABLE {n_rows}×{n_cols}]"

        else:
            text = ""

        return text[:200].strip()

    # ── Text helpers ──────────────────────────────────────────────────────────

    def get_text(self) -> str:
        """
        Text đầy đủ, đúng nguồn theo từng type.
        Dùng cho diff / align — không truncate.
        """
        if self.type in ("heading", "paragraph"):
            return self.node.content.get("text") or ""

        if self.type == "shape":
            return " ".join(
                c.content.get("text") or ""
                for c in self.node.children
                if c.type == "paragraph"
            )

        # image, table — không có text đại diện
        return ""

    def get_runs(self) -> list:
        """
        Runs của paragraph / heading (cho diff inline).
        Trả về list rỗng nếu không có runs.
        """
        return self.node.content.get("runs") or []

    def has_children(self) -> bool:
        """True nếu node gốc có ít nhất một node con."""
        return len(self.node.children) > 0

    # ── Equality & hashing ────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        """
        Thứ tự ưu tiên:
          1. Cả hai có signature → so sánh nội dung (content-based).
          2. Không có signature  → so sánh uid.
          3. Không có uid        → fallback identity.

        Dùng `a is b` nếu cần so sánh identity tuyệt đối.
        """
        if not isinstance(other, Block):
            return NotImplemented
        if self.signature and other.signature:
            return self.signature == other.signature
        if self.uid is not None and other.uid is not None:
            return self.uid == other.uid
        return self is other

    def __hash__(self) -> int:
        # Ưu tiên hash theo signature để nhất quán với __eq__
        if self.signature:
            return hash(self.signature)
        if self.uid is not None:
            return hash(self.uid)
        return id(self)

    # ── Debug ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"Block("
            f"type={self.type!r}, "
            f"uid={self.uid!r}, "
            f"order={self.order!r}, "
            f"heading_ctx={self.heading_ctx!r}, "
            f"preview={self.preview_text!r}"
            f")"
        )