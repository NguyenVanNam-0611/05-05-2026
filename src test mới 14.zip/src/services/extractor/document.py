"""
extractor/document.py
~~~~~~~~~~~~~~~~~~~~~
Entry point: đọc file .docx và chuyển thành cây DocNode.

Chỉ chịu trách nhiệm:
    - Duyệt block item ở document level (paragraph, table)
    - Track trạng thái TOC field
    - Gọi paragraph.py và table.py để extract từng loại
    - Trả về root DocNode(type="document")

KHÔNG chứa logic extract chi tiết — xem paragraph.py và table.py.
Import từ: utils.py, paragraph.py, table.py

Iterator _iter_block_items nằm ở đây vì chỉ document.py dùng.

Cây trả về:
    document
    ├── heading
    │   └── image       (inline trong heading)
    ├── paragraph
    │   └── image       (inline)
    ├── table
    │   └── row
    │       └── cell
    │           ├── paragraph
    │           │   └── image
    │           └── table  (nested)
    └── shape

TOC tracking — các trường hợp được cover:
    1. TOC đơn giản : begin → instrText(TOC) → end trong 1 paragraph
    2. TOC phức tạp : begin/instrText/end trải qua nhiều paragraph
    3. Nested field : dùng depth counter, không phải bool flag
    4. TOC style    : paragraph dùng style "TOC 1", "TOC 2", …
    5. Thoát TOC    : depth giảm xuống dưới toc_depth → reset
"""

from __future__ import annotations

import re
from typing import Iterator, Union

from docx import Document
from docx.document import Document as _Document
from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table
from docx.text.paragraph import Paragraph

from src.services.models.docnode import DocNode
from src.services.extractor.paragraph import extract_paragraph_nodes
from src.services.extractor.table import extract_table
from src.services.extractor.utils import OrderRef, next_order

# ── Types ─────────────────────────────────────────────────────────────────────

BlockItem = Union[Paragraph, Table]


# ══════════════════════════════════════════════════════════════════════════════
# Document iterator
# ══════════════════════════════════════════════════════════════════════════════

def _iter_block_items(doc: _Document) -> Iterator[BlockItem]:
    """
    Duyệt các phần tử con trực tiếp của document body.
    Yield Paragraph hoặc Table theo đúng thứ tự XML.

    Không lọc — giữ nguyên toàn bộ kể cả paragraph rỗng
    (TOC tracker cần xử lý mọi paragraph).
    """
    for child in doc.element.body.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, doc)
        elif isinstance(child, CT_Tbl):
            yield Table(child, doc)


# ══════════════════════════════════════════════════════════════════════════════
# TOC field tracker
# ══════════════════════════════════════════════════════════════════════════════

class _TocFieldTracker:
    """
    Track trạng thái field TOC khi duyệt qua từng paragraph.

    Word dùng 3 loại w:fldChar để đánh dấu field:
        fldCharType="begin"    → bắt đầu field
        fldCharType="separate" → hết phần instruction, bắt đầu content
        fldCharType="end"      → kết thúc field
    và w:instrText chứa lệnh (vd: " TOC \\o \\"1-3\\" \\h \\z \\u ").

    State được quản lý bằng hai biến:
        _depth     : độ sâu field hiện tại (nested field → depth > 1)
        _toc_depth : depth tại thời điểm phát hiện TOC field
                     (0 = chưa vào TOC hoặc đã thoát)

    inside_toc = True khi _toc_depth > 0 và _depth >= _toc_depth.
    Không dùng bool flag riêng → không thể drift giữa hai biến.
    """

    def __init__(self) -> None:
        self._depth: int     = 0
        self._toc_depth: int = 0
        self._pending_check: bool = False

    @property
    def inside_toc(self) -> bool:
        """True nếu đang nằm trong TOC field."""
        return self._toc_depth > 0 and self._depth >= self._toc_depth

    def process_paragraph(self, par: Paragraph) -> bool:
        """
        Cập nhật state dựa trên paragraph hiện tại.
        Trả True nếu paragraph này nằm trong TOC field.

        Gọi theo thứ tự duyệt document — không gọi lại trên paragraph cũ.
        """
        for elem in par._p.iter():
            tag = elem.tag

            if tag == qn("w:fldChar"):
                fld_type = elem.get(qn("w:fldCharType"), "")

                if fld_type == "begin":
                    self._depth += 1
                    self._pending_check = True

                elif fld_type == "separate":
                    # Hết phần instruction — không còn chờ instrText nữa
                    self._pending_check = False

                elif fld_type == "end":
                    if self._depth > 0:
                        self._depth -= 1
                    # Nếu depth giảm xuống dưới toc_depth → đã thoát TOC
                    if self._toc_depth > 0 and self._depth < self._toc_depth:
                        self._toc_depth = 0
                    self._pending_check = False

            elif tag == qn("w:instrText"):
                # Chỉ xử lý khi đang trong instruction phase (trước "separate")
                if self._pending_check:
                    instr = (elem.text or "").strip().upper()
                    if "TOC" in instr:
                        self._toc_depth = self._depth
                    self._pending_check = False

        return self.inside_toc

    @staticmethod
    def is_toc_style(par: Paragraph) -> bool:
        """True nếu paragraph dùng style TOC 1, TOC 2, … (case-insensitive)."""
        style_name = (par.style.name if par.style else "") or ""
        return bool(re.match(r"toc\s*\d+", style_name.strip(), re.IGNORECASE))


def _is_toc_paragraph(par: Paragraph, tracker: _TocFieldTracker) -> bool:
    """
    True nếu paragraph thuộc TOC — theo field hoặc theo style.

    process_paragraph phải được gọi trước is_toc_style để đảm bảo
    tracker state luôn được cập nhật, kể cả khi is_toc_style đã True.
    """
    in_field = tracker.process_paragraph(par)
    in_style = _TocFieldTracker.is_toc_style(par)
    return in_field or in_style


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_doc_tree(docx_path: str) -> DocNode:
    """
    Entry point chính.
    Đọc file .docx và trả về cây DocNode đại diện toàn bộ tài liệu.

    uid của mỗi block item được lấy từ order_ref (nguồn duy nhất),
    đảm bảo uid và order nhất quán trong toàn bộ cây.

    Args:
        docx_path: Đường dẫn tuyệt đối tới file .docx.

    Returns:
        DocNode với type="document" là root của cây.

    Raises:
        FileNotFoundError: Nếu file không tồn tại.
        ValueError:        Nếu file không phải .docx hợp lệ.
    """
    doc        = Document(docx_path)
    order_ref: OrderRef = {"value": 0}
    toc_tracker = _TocFieldTracker()

    root = DocNode(
        type="document",
        uid="document",
        parent_uid=None,
        order=0,
        path="document",
        content={"source": docx_path},
    )

    for item in _iter_block_items(doc):
        # uid lấy từ order_ref — nguồn duy nhất, không đếm song song
        uid = f"n{next_order(order_ref)}"

        if isinstance(item, Paragraph):
            in_toc = _is_toc_paragraph(item, toc_tracker)
            for node in extract_paragraph_nodes(
                item,
                uid=uid,
                parent_uid="document",
                order_ref=order_ref,
                in_toc=in_toc,
            ):
                root.add_child(node)

        else:  # Table
            root.add_child(
                extract_table(
                    item,
                    uid=uid,
                    parent_uid="document",
                    order_ref=order_ref,
                )
            )

    return root