"""
extractor/table.py
~~~~~~~~~~~~~~~~~~
Extract table và cell từ docx thành DocNode.

Chịu trách nhiệm:
    - Duyệt table → row → cell (kể cả merged cell, colspan, rowspan)
    - Extract nội dung cell theo đúng thứ tự XML: paragraph, nested table
    - Tính merge info (col_span, row_span, is_merged)
    - Lọc paragraph rỗng trong cell (Word tự thêm)
    - Tính các trường phục vụ diff: cell_type, col_span_pattern, text flatten

KHÔNG xử lý: paragraph ở document level, TOC, shape ở document level.
Import từ: utils.py, paragraph.py

Cây trả về từ extract_table():
    table
    └── row
        └── cell
            ├── paragraph   (text + runs + ảnh inline)
            │   └── image
            └── table       (nested — đệ quy)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCHEMA PHỤC VỤ DIFF — đọc trước khi sửa
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Table content:
    row_count         : int   — số row vật lý
    col_count         : int   — số cột logic (từ XML gridSpan)
    text              : str   — flatten toàn bộ bảng, dùng cho so sánh nhanh

Row content:
    row_index         : int
    col_count         : int   — số cột logic của row này (tổng gridSpan)
                                → diff layer dùng để detect layout change
    col_span_pattern  : list  — [gridSpan của từng tc]  vd [1, 2, 1]
                                → so sánh 2 pattern để phát hiện merge/split
    text              : str   — join cell text bằng " | "
                                → SequenceMatcher dùng để align rows

Cell content:
    row_index         : int
    col_index         : int   — logical col (đã tính gridSpan của các tc trước)
    col_span          : int   — số cột cell này chiếm
    row_span          : int   — số row cell này chiếm
    is_merged         : bool  — True nếu col_span>1 hoặc row_span>1

    text              : str   — norm_text flatten toàn bộ cell kể cả nested table
                                → dùng để tính row signature, align, so sánh
    text_display      : str   — raw_text (giữ newline) chỉ từ paragraph trực tiếp
                                → dùng để hiển thị UI

    cell_type         : str   — "text" | "image" | "table" | "mixed" | "empty"
                                → diff layer dùng để chọn strategy
    has_text          : bool
    has_image         : bool
    has_table         : bool  — có nested table không

    para_count        : int   — số paragraph trực tiếp trong cell
    image_count       : int   — tổng ảnh trong cell (kể cả trong nested table)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LOGIC PHÁT HIỆN LAYOUT CHANGE (dùng ở diff layer, không ở đây)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Bước 1 — Table level:
    delta = abs(left.col_count - right.col_count)
    delta == 0          → tiếp tục align rows
    1 <= delta <= 2     → LAYOUT_MINOR, vẫn align rows
    delta > 2           → LAYOUT_MAJOR, show side-by-side

Bước 2 — Row level (chỉ khi delta <= 2):
    Với mỗi cặp row đã match:
    left.col_span_pattern == right.col_span_pattern
        → align cell 1-1 theo col_index → diff bình thường
    left.col_span_pattern != right.col_span_pattern
        → ROW_LAYOUT_CHANGE, show row as-is cả 2 phía

Bước 3 — Cell level (chỉ khi pattern khớp):
    So sánh cell_type:
        same + text   → word-level diff (norm_for_diff)
        same + image  → hash compare
        same + table  → đệ quy TableDiff
        khác nhau     → TYPE_CHANGE, show as-is cả 2 phía
"""

from __future__ import annotations

from typing import Dict, Iterator, List, Optional, Tuple, Union

from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph

from src.services.models.docnode import DocNode
from src.services.extractor.paragraph import extract_paragraph_nodes
from src.services.extractor.utils import OrderRef, next_order, norm_text, raw_text

# ── Types ─────────────────────────────────────────────────────────────────────

BlockItem = Union[Paragraph, Table]


# ══════════════════════════════════════════════════════════════════════════════
# Cell iterator
# ══════════════════════════════════════════════════════════════════════════════

def _iter_cell_items(cell: _Cell) -> Iterator[BlockItem]:
    """
    Yield Paragraph (có nội dung) hoặc Table theo đúng thứ tự XML trong cell.

    Lọc paragraph hoàn toàn rỗng (Word tự thêm ở cuối mỗi cell) để tránh
    noise cho diff. Paragraph được giữ lại khi có text hoặc có ảnh.

    Detect ảnh bằng par._p.find() thay vì duyệt từng run — đơn giản hơn
    và cover cả w:drawing lẫn w:pict (VML) kể cả khi không nằm trong run.
    """
    for child in cell._tc.iterchildren():
        if isinstance(child, CT_P):
            par = Paragraph(child, cell)
            has_text  = bool(norm_text(par.text))
            has_image = (
                child.find(qn("w:drawing")) is not None
                or child.find(qn("w:pict"))  is not None
            )
            if has_text or has_image:
                yield par

        elif isinstance(child, CT_Tbl):
            yield Table(child, cell)


# ══════════════════════════════════════════════════════════════════════════════
# XML / merge helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_xml_rows(tbl: Table) -> List[List]:
    """
    Trả về list[list[tc_element]] — physical cells từ XML.

    KHÔNG dùng tbl.rows[r].cells vì python-docx tự deduplicate merged cell
    theo cách không nhất quán, dẫn đến row text bị lặp hoặc thiếu cell.
    """
    TR = qn("w:tr")
    TC = qn("w:tc")
    return [
        list(tr.iterchildren(TC))
        for tr in tbl._tbl.iterchildren(TR)
    ]


def _tc_col_span(tc) -> int:
    """Số cột mà tc này chiếm (w:gridSpan). Default 1."""
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1
    gs = tcPr.find(qn("w:gridSpan"))
    return int(gs.get(qn("w:val"), 1)) if gs is not None else 1


def _count_cols_from_xml(xml_rows: List[List]) -> int:
    """
    Tính số cột logic của table từ XML rows.

    Ưu tiên rows có > 1 physical cell để tránh header row (1 cell spanning
    toàn bộ) làm lệch col_count. Fallback về tất cả rows nếu không có.
    """
    if not xml_rows:
        return 0
    multi = [row for row in xml_rows if len(row) > 1]
    rows  = multi if multi else xml_rows
    return max(sum(_tc_col_span(tc) for tc in row) for row in rows)


def _get_merge_info(tc) -> Tuple[int, bool, bool]:
    """
    Trả về (col_span, is_restart, is_continue).

    is_restart  = cell này bắt đầu vMerge group (w:vMerge val="restart")
    is_continue = cell này là continuation của vMerge (w:vMerge không có val
                  hoặc val="") → bỏ qua khi build tree
    """
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1, False, False

    gs       = tcPr.find(qn("w:gridSpan"))
    col_span = int(gs.get(qn("w:val"), 1)) if gs is not None else 1

    vMerge = tcPr.find(qn("w:vMerge"))
    if vMerge is None:
        return col_span, False, False

    val = vMerge.get(qn("w:val"), "")
    if val == "restart":
        return col_span, True, False
    return col_span, False, True


def _count_row_span(xml_rows: List[List], row_idx: int, grid_col: int) -> int:
    """
    Đếm số row mà cell tại (row_idx, grid_col) chiếm bằng cách đi xuống
    và đếm các vMerge continuation liên tiếp.
    """
    span = 1
    for r in range(row_idx + 1, len(xml_rows)):
        pos      = 0
        found_tc = None

        for tc in xml_rows[r]:
            if pos == grid_col:
                found_tc = tc
                break
            pos += _tc_col_span(tc)
            if pos > grid_col:
                break

        if found_tc is None:
            break

        tcPr   = found_tc.find(qn("w:tcPr"))
        vMerge = tcPr.find(qn("w:vMerge")) if tcPr is not None else None

        if vMerge is None:
            break
        if vMerge.get(qn("w:val"), "") == "restart":
            break

        span += 1

    return span


# ══════════════════════════════════════════════════════════════════════════════
# Cell text helpers
# ══════════════════════════════════════════════════════════════════════════════

def _flatten_cell_text(cell: _Cell) -> str:
    """
    Flatten toàn bộ text trong cell thành một chuỗi norm_text.

    Bao gồm cả nested table (đệ quy) — dùng để tính row signature
    và so sánh cell-level trong diff. KHÔNG dùng để hiển thị UI.

    Paragraph join bằng space; nested table join bằng newline.
    """
    parts: List[str] = []
    for item in _iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = norm_text(item.text)
            if t:
                parts.append(t)
        else:
            # Nested table — flatten đệ quy
            nested_parts: List[str] = []
            xml_rows_nested = _get_xml_rows(item)
            for r_idx, xml_row in enumerate(xml_rows_nested):
                row_parts = []
                for tc in xml_row:
                    nested_cell = _Cell(tc, item)
                    t = _flatten_cell_text(nested_cell)
                    if t:
                        row_parts.append(t)
                if row_parts:
                    nested_parts.append(" | ".join(row_parts))
            if nested_parts:
                parts.append("\n".join(nested_parts))
    return " ".join(parts)


def _display_cell_text(cell: _Cell) -> str:
    """
    Text hiển thị UI — chỉ từ paragraph trực tiếp trong cell,
    giữ newline giữa các paragraph (raw_text).

    Không flatten nested table vì UI sẽ render nested table riêng.
    """
    parts: List[str] = []
    for item in _iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = raw_text(item.text)
            if t:
                parts.append(t)
    return "\n".join(parts)


# ══════════════════════════════════════════════════════════════════════════════
# Cell extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_cell(
    cell      : _Cell,
    uid_prefix: str,
    parent_uid: Optional[str],
    order_ref : OrderRef,
    row_index : int,
    col_index : int,
    col_span  : int = 1,
    row_span  : int = 1,
    is_merged : bool = False,
) -> DocNode:
    """
    Extract một cell thành DocNode(type="cell").

    Duyệt _iter_cell_items theo đúng thứ tự XML để giữ nguyên vị trí
    tương đối của text, ảnh, nested table trong văn bản gốc.

    Heading trong cell bị downgrade thành paragraph vì heading style
    trong cell thường là do copy format, không phải heading thật.
    Content đồng bộ (is_heading=False, heading_level=0) để tránh
    diff layer nhầm phân loại.
    """
    # Tính các trường summary trước khi build children
    flat_text    = _flatten_cell_text(cell)
    display_text = _display_cell_text(cell)

    # has_image dùng XML thô — nhanh, không cần build cây trước.
    # image_count chính xác (kể cả ảnh trong nested table) được tính
    # sau khi build children xong bằng cell_node.iter_images().
    has_text  = bool(flat_text)
    has_image = (
        cell._tc.find(qn("w:drawing")) is not None
        or cell._tc.find(qn("w:pict")) is not None
    )
    has_table = any(isinstance(i, Table) for i in _iter_cell_items(cell))

    n_content = sum([has_text, has_image, has_table])
    if n_content == 0:
        cell_type = "empty"
    elif n_content > 1:
        cell_type = "mixed"
    elif has_table:
        cell_type = "table"
    elif has_image:
        cell_type = "image"
    else:
        cell_type = "text"

    cell_node = DocNode(
        type="cell",
        uid=uid_prefix,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid_prefix.replace(".", "/"),
        content={
            # ── Grid position ─────────────────────────────────────────────
            "row_index":   row_index,
            "col_index":   col_index,
            "col_span":    col_span,
            "row_span":    row_span,
            "is_merged":   is_merged,

            # ── Text (diff + display) ─────────────────────────────────────
            "text":         flat_text,      # dùng cho signature / align / compare
            "text_display": display_text,   # dùng cho UI

            # ── Content type (diff strategy) ──────────────────────────────
            "cell_type":   cell_type,       # "text"|"image"|"table"|"mixed"|"empty"
            "has_text":    has_text,
            "has_image":   has_image,
            "has_table":   has_table,

            # ── Counts ────────────────────────────────────────────────────
            "para_count":  0,               # update sau khi add children
            "image_count": 0,               # update sau khi add children
        },
    )

    # ── Build children theo thứ tự XML ────────────────────────────────────
    child_idx  = 0
    para_count = 0

    for item in _iter_cell_items(cell):

        child_idx += 1

        if isinstance(item, Table):
            # Nested table — đệ quy
            cell_node.add_child(
                extract_table(
                    item,
                    uid=f"{uid_prefix}.t{child_idx}",
                    parent_uid=uid_prefix,
                    order_ref=order_ref,
                )
            )
            continue

        # ── Paragraph ─────────────────────────────────────────────────────
        assert isinstance(item, Paragraph)

        nodes = extract_paragraph_nodes(
            item,
            uid=f"{uid_prefix}.p{child_idx}",
            parent_uid=uid_prefix,
            order_ref=order_ref,
            in_toc=False,
        )

        for node in nodes:
            # Downgrade heading → paragraph trong cell
            if node.type == "heading":
                node.type = "paragraph"
                node.content["is_heading"]    = False
                node.content["heading_level"] = 0
                node.content.pop("level", None)

            cell_node.add_child(node)
            if node.type == "paragraph":
                para_count += 1

    cell_node.content["para_count"]  = para_count
    cell_node.content["image_count"] = sum(1 for _ in cell_node.iter_images())
    return cell_node


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_table(
    tbl       : Table,
    uid       : Optional[str] = None,
    parent_uid: Optional[str] = None,
    order_ref : Optional[OrderRef] = None,
) -> DocNode:
    """
    Extract một Table docx thành DocNode (kể cả nested table đệ quy).

    Args:
        tbl:        Table object từ python-docx.
        uid:        UID của table node (vd: "n3", "n3.r1.c2.t1").
        parent_uid: UID của node cha.
        order_ref:  Mutable counter dùng chung toàn document.

    Returns:
        DocNode(type="table") với cây con đầy đủ row → cell → ...
    """
    if order_ref is None:
        order_ref = {"value": 0}

    # Parse XML rows một lần duy nhất — dùng lại ở mọi bước bên dưới.
    # KHÔNG dùng tbl.rows[r].cells vì python-docx deduplicate merged cell
    # không nhất quán → cell text bị lặp.
    xml_rows = _get_xml_rows(tbl)
    n_rows   = len(xml_rows)
    n_cols   = _count_cols_from_xml(xml_rows)

    # Table text: flatten toàn bộ bảng — dùng để so sánh nhanh ở ngoài
    table_text = "\n".join(
        " | ".join(
            _flatten_cell_text(_Cell(tc, tbl))
            for tc in xml_row
        )
        for xml_row in xml_rows
    )

    table_node = DocNode(
        type="table",
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=(uid or "").replace(".", "/"),
        content={
            "row_count": n_rows,
            "col_count": n_cols,
            "text":      table_text,
        },
    )

    # skip_map: (row_idx, logical_col) → True
    # Đánh dấu các ô là vMerge continuation để bỏ qua khi build tree.
    skip_map: Dict[Tuple[int, int], bool] = {}

    for r_idx, xml_tcs in enumerate(xml_rows):

        row_uid = f"{uid}.r{r_idx}" if uid else f"row.{r_idx}"

        # col_span_pattern: [gridSpan của từng tc trong row]
        # → diff layer dùng để detect merge/split (layout change ở row level)
        col_span_pattern = [_tc_col_span(tc) for tc in xml_tcs]

        # col_count của row = tổng gridSpan = số cột logic row này chiếm
        row_col_count = sum(col_span_pattern)

        # row text: join cell text bằng " | "
        # → SequenceMatcher dùng để align rows (bước 1 của TableDiff)
        row_text = " | ".join(
            _flatten_cell_text(_Cell(tc, tbl))
            for tc in xml_tcs
        )

        row_node = DocNode(
            type="row",
            uid=row_uid,
            parent_uid=uid,
            order=next_order(order_ref),
            path=row_uid.replace(".", "/"),
            content={
                "row_index":        r_idx,
                "col_count":        row_col_count,        # số cột logic
                "col_span_pattern": col_span_pattern,     # [1,2,1] — layout fingerprint
                "text":             row_text,              # cho SequenceMatcher
            },
        )
        table_node.add_child(row_node)

        logical_col = 0

        for tc in xml_tcs:
            # Bỏ qua ô đã được đánh dấu là vMerge continuation
            if skip_map.get((r_idx, logical_col)):
                logical_col += _tc_col_span(tc)
                continue

            col_span, is_restart, is_continue = _get_merge_info(tc)

            if is_continue:
                logical_col += col_span
                continue

            row_span  = 1
            is_merged = col_span > 1

            if is_restart:
                row_span  = _count_row_span(xml_rows, r_idx, logical_col)
                is_merged = True
                # Đánh dấu tất cả ô continuation để bỏ qua
                for dr in range(1, row_span):
                    for dc in range(col_span):
                        skip_map[(r_idx + dr, logical_col + dc)] = True

            cell_uid = (
                f"{uid}.r{r_idx}.c{logical_col}"
                if uid else
                f"cell.r{r_idx}.c{logical_col}"
            )

            row_node.add_child(
                _extract_cell(
                    cell=_Cell(tc, tbl),
                    uid_prefix=cell_uid,
                    parent_uid=row_uid,
                    order_ref=order_ref,
                    row_index=r_idx,
                    col_index=logical_col,
                    col_span=col_span,
                    row_span=row_span,
                    is_merged=is_merged,
                )
            )

            logical_col += col_span

    return table_node