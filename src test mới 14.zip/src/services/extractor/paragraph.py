"""
extractor/paragraph.py
~~~~~~~~~~~~~~~~~~~~~~
Extract paragraph và heading từ docx thành DocNode.

Chịu trách nhiệm:
    - Detect heading style và level
    - Trích xuất runs (text + formatting)
    - Build paragraph/heading DocNode (kể cả ảnh inline)
    - Shape tách ra ngoài thành sibling node

KHÔNG xử lý: table, cell, TOC tracking, shape extraction.
Import từ: utils.py, image.py, shape.py

Các trường hợp được cover:
    A. Paragraph / heading bình thường
    B. Paragraph có ảnh inline
    C. Paragraph có shape (→ sibling node)
    D. Paragraph chứa Shift+Enter (\\x0b)
         D1. Part đầu là heading → heading node
         D2. Các part sau → paragraph node
         D3. Image/shape thuộc về paragraph gốc → gán vào part đầu
         D4. Toàn bộ part rỗng → trả về []  (documented intentional)
    E. Paragraph rỗng không có content (text/image/shape)
         → trả về [] (bị drop, caller biết trước)
    F. Paragraph có page_break_before → giữ nguyên flag trong content
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from docx.text.paragraph import Paragraph

from src.services.models.docnode import DocNode
from src.services.extractor.image import extract_inline_images
from src.services.extractor.shape import extract_shapes_from_paragraph
from src.services.extractor.utils import OrderRef, norm_text, next_order, safe_pt


# ══════════════════════════════════════════════════════════════════════════════
# Heading helpers
# ══════════════════════════════════════════════════════════════════════════════

_HEADING_RE = re.compile(r"heading\s*(\d+)", re.IGNORECASE)


def heading_level(style_name: str) -> int:
    """Trả level 1–9 nếu là heading style, else 0."""
    if not style_name:
        return 0
    m = _HEADING_RE.search(style_name.strip())
    return int(m.group(1)) if m else 0


def is_heading(par: Paragraph) -> bool:
    name = (par.style.name if par.style else "") or ""
    return name.strip().lower().startswith("heading")


# ══════════════════════════════════════════════════════════════════════════════
# Run extractor
# ══════════════════════════════════════════════════════════════════════════════

def extract_runs(par: Paragraph) -> List[Dict]:
    """
    Trích xuất từng run với định dạng đầy đủ.
    Chỉ bỏ qua run hoàn toàn rỗng (text == "").
    """
    runs = []
    for idx, run in enumerate(par.runs):
        text = run.text
        if text == "":
            continue

        font = run.font

        try:
            color = str(font.color.rgb) if font.color.rgb else None
        except Exception:
            color = None

        try:
            highlight = str(font.highlight_color) if font.highlight_color else None
        except Exception:
            highlight = None

        runs.append({
            "index":     idx,
            "text":      text,
            "bold":      bool(run.bold)      if run.bold      is not None else False,
            "italic":    bool(run.italic)    if run.italic    is not None else False,
            "underline": bool(run.underline) if run.underline is not None else False,
            "font_name": font.name           if font else None,
            "font_size": font.size.pt        if font and font.size else None,
            "color":     color,
            "highlight": highlight,
        })

    return runs


# ══════════════════════════════════════════════════════════════════════════════
# Line spacing helper
# ══════════════════════════════════════════════════════════════════════════════

def extract_line_spacing(pf) -> Optional[Dict]:
    try:
        ls = pf.line_spacing
        if ls is None:
            return None
        if hasattr(ls, "pt"):
            return {"type": "exact_pt", "value": ls.pt}
        return {"type": "multiple", "value": float(ls)}
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph format helper
# ══════════════════════════════════════════════════════════════════════════════

def _base_format(par: Paragraph) -> Dict:
    """Trích xuất các trường format chung, dùng lại ở cả hai path."""
    style_name = (par.style.name if par.style else "") or ""
    pf         = par.paragraph_format
    return {
        "style":             style_name,
        "alignment":         par.alignment,
        "is_heading":        is_heading(par),
        "heading_level":     heading_level(style_name),
        "space_before":      safe_pt(pf.space_before),
        "space_after":       safe_pt(pf.space_after),
        "left_indent":       safe_pt(pf.left_indent),
        "right_indent":      safe_pt(pf.right_indent),
        "first_line_indent": safe_pt(pf.first_line_indent),
        "line_spacing":      extract_line_spacing(pf),
        "keep_together":     bool(pf.keep_together)     if pf.keep_together     is not None else False,
        "keep_with_next":    bool(pf.keep_with_next)    if pf.keep_with_next    is not None else False,
        "page_break_before": bool(pf.page_break_before) if pf.page_break_before is not None else False,
        "widow_control":     bool(pf.widow_control)     if pf.widow_control     is not None else False,
    }


def build_paragraph_content(
    par: Paragraph,
    imgs: List[DocNode],
    shapes: List[DocNode],
    in_toc: bool,
) -> Dict:
    """Tạo content dict dùng chung cho cả paragraph và heading."""
    fmt  = _base_format(par)
    text = norm_text(par.text)
    return {
        **fmt,
        "text":        text,
        "run_count":   len(par.runs),
        "runs":        extract_runs(par),
        "image_count": len(imgs),
        "shape_count": len(shapes),
        "in_toc":      in_toc,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Node builders (internal)
# ══════════════════════════════════════════════════════════════════════════════

def _make_heading_node(
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    content: Dict,
    imgs: List[DocNode],
) -> DocNode:
    """Tạo heading node và attach ảnh inline làm children."""
    node = DocNode(
        type="heading",
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid.replace(".", "/"),
        content=content,
    )
    for img in imgs:
        img.order = next_order(order_ref)
        node.add_child(img)
    return node


def _make_paragraph_node(
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    content: Dict,
    imgs: List[DocNode],
) -> DocNode:
    """Tạo paragraph node và attach ảnh inline làm children."""
    node = DocNode(
        type="paragraph",
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid.replace(".", "/"),
        content=content,
    )
    for img in imgs:
        img.order = next_order(order_ref)
        node.add_child(img)
    return node


# ══════════════════════════════════════════════════════════════════════════════
# Shift+Enter path (path D)
# ══════════════════════════════════════════════════════════════════════════════

def _split_runs_by_vbreak(par: Paragraph) -> List[List[Dict]]:
    """
    Phân phối runs vào các segment tương ứng với từng part của Shift+Enter.

    Word biểu diễn Shift+Enter bằng <w:br w:type="textWrapping"/> trong XML.
    par.runs không expose break trực tiếp — cần đọc XML để biết run nào
    chứa break và split tại đó.

    Trả về list các list-of-run-dict, tương ứng 1-1 với parts của
    par.text.split("\\x0b").
    """
    from docx.oxml.ns import qn

    segments: List[List[Dict]] = [[]]

    all_runs = extract_runs(par)
    # Key bằng id(run._r) — tránh lệch index khi extract_runs bỏ qua run rỗng

    # Build map đúng: ghép par.runs (có cả run rỗng) với all_runs (đã lọc)
    _all_run_iter = iter(all_runs)
    _elem_to_dict: Dict[int, Dict] = {}
    for run in par.runs:
        text = run.text
        if text != "":  # chỉ run có text mới có entry trong all_runs
            rd = next(_all_run_iter, None)
            if rd is not None:
                _elem_to_dict[id(run._r)] = rd

    for run in par.runs:
        run_dict = _elem_to_dict.get(id(run._r))
        # Kiểm tra xem run có chứa w:br không
        has_break = run._r.find(qn("w:br")) is not None

        if run_dict:
            segments[-1].append(run_dict)

        if has_break:
            segments.append([])

    return segments


def _handle_vbreak_paragraph(
    par: Paragraph,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    in_toc: bool,
    imgs: List[DocNode],
    shapes: List[DocNode],
) -> List[DocNode]:
    """
    Path D: paragraph chứa Shift+Enter (\\x0b).

    Chiến lược:
    - Split text theo \\x0b → các part
    - Split runs theo w:br XML → gán runs đúng vào từng part
    - Image và shape được gán vào part đầu tiên có nội dung
    - Part rỗng sau strip → bỏ qua
    - Toàn bộ rỗng → trả [] (intentional, documented)
    - Part 0 của heading → heading node; phần sau → paragraph node
    """
    raw   = par.text or ""
    parts = raw.split("\x0b")
    fmt   = _base_format(par)
    style_name = fmt["style"]

    run_segments = _split_runs_by_vbreak(par)
    # Đảm bảo run_segments có đủ slot cho mọi part
    while len(run_segments) < len(parts):
        run_segments.append([])

    nodes: List[DocNode] = []
    images_assigned = False

    for k, part in enumerate(parts):
        text = norm_text(part)
        if not text:
            continue  # bỏ part rỗng

        part_uid  = f"{uid}.s{k}"
        part_runs = run_segments[k]

        # Image và shape chỉ gán vào part đầu tiên có nội dung
        part_imgs:   List[DocNode] = []
        part_shapes: List[DocNode] = []
        if not images_assigned:
            part_imgs   = imgs
            part_shapes = shapes
            images_assigned = True

        content = {
            **fmt,
            "text":        text,
            "is_heading":  False,       # phần sau Shift+Enter không phải heading
            "heading_level": 0,
            "run_count":   len(part_runs),
            "runs":        part_runs,
            "image_count": len(part_imgs),
            "shape_count": len(part_shapes),
            "in_toc":      in_toc,
        }

        if k == 0 and is_heading(par):
            content["is_heading"]    = True
            content["heading_level"] = heading_level(style_name)
            content["level"]         = heading_level(style_name)
            node = _make_heading_node(part_uid, parent_uid, order_ref, content, part_imgs)
        else:
            node = _make_paragraph_node(part_uid, parent_uid, order_ref, content, part_imgs)

        nodes.append(node)

        # Shape là sibling, không phải child
        for shp in part_shapes:
            shp.order = next_order(order_ref)
            nodes.append(shp)

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_paragraph_nodes(
    par: Paragraph,
    uid: str,
    parent_uid: Optional[str],
    order_ref: OrderRef,
    in_toc: bool = False,
) -> List[DocNode]:
    """
    Chuyển một Paragraph docx thành 0..N DocNode.

    Trả về [] nếu paragraph không có nội dung (text, image, shape đều rỗng).
    Caller không cần check — list rỗng là hợp lệ.

    Thứ tự node trong list:
        [heading/paragraph node] [shape siblings...]

    Image inline là children của paragraph/heading, không phải siblings.
    """
    # Extract image và shape trước — dùng cho cả hai path
    # Image order được set bên trong extract_inline_images;
    # KHÔNG gọi next_order thêm lần nữa khi attach vào node.
    imgs = extract_inline_images(
        par,
        uid_prefix=f"{uid}.img",
        parent_uid=uid,
        order_ref=order_ref,
    )
    shapes = extract_shapes_from_paragraph(
        par,
        uid_prefix=f"{uid}.shp",
        parent_uid=parent_uid,
        order_ref=order_ref,
    )

    # ── Path D: có Shift+Enter ─────────────────────────────────────────────
    raw = par.text or ""
    if "\x0b" in raw:
        return _handle_vbreak_paragraph(
            par, uid, parent_uid, order_ref, in_toc, imgs, shapes
        )

    # ── Path A–C: paragraph bình thường ───────────────────────────────────
    text    = norm_text(raw)
    content = build_paragraph_content(par, imgs, shapes, in_toc)

    # Path E: rỗng hoàn toàn — không tạo node
    if not text and not imgs and not shapes:
        return []

    nodes: List[DocNode] = []

    if text or imgs:
        if is_heading(par):
            style_name = (par.style.name if par.style else "") or ""
            content    = {
                **content,
                "level": heading_level(style_name),
            }
            node = _make_heading_node(uid, parent_uid, order_ref, content, imgs)
        else:
            node = _make_paragraph_node(uid, parent_uid, order_ref, content, imgs)
        nodes.append(node)

    # Shape là sibling của paragraph, không phải child
    for shp in shapes:
        shp.order = next_order(order_ref)
        nodes.append(shp)

    return nodes