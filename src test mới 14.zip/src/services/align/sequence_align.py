"""
align/sequence_align.py
~~~~~~~~~~~~~~~~~~~~~~~
Align block list A (original) với block list B (modified) thành list opcodes.

Fixes so với cũ:
1. HEADING SHIFT BUG — khi thêm heading mới đẩy các block xuống (5.1 Nam, 5.2 Nga
   → 5.1 Nam, 5.2 Son, 5.3 Nga), heading_ctx của "Nga" thay đổi từ "5.2" → "5.3"
   khiến signature đổi hoàn toàn → SequenceMatcher không match được.
   FIX: dùng CONTENT-ONLY signature (không có heading_ctx) cho SequenceMatcher.
   Với shape: dùng ctx_body (tên heading bỏ số chương) thay vì heading_ctx đầy đủ
   → stable khi số chương đổi nhưng vẫn phân biệt heading tên khác nhau.

2. CROSS-MATCH BUG — 2 shape cùng text ở 2 heading tên khác nhau bị match nhầm
   vì content_sig giống nhau hoàn toàn.
   FIX: đưa ctx_body vào content_sig của shape.
   "shape|abc|quy trình a" ≠ "shape|abc|quy trình b" → không match nhầm.

3. _match_mixed_slice INDEX BUG — phần emit delete/insert không được sort
   → opcodes có thể không tăng dần theo index.
   FIX: sort matched_a và unmatched_b trước khi emit.

4. N-N table pairing — giữ lại nhưng guard thêm.

5. SIMILAR BLOCK DEDUP — nhiều block có content thay đổi y hệt nhau
   → SequenceMatcher có thể match nhầm. _block_similarity với heading bonus
   được dùng ở bước quyết định replace vs delete+insert để tránh false match.

6. EMPTY SHAPE CONTENT SIG — trước dùng absolute order → không stable khi
   thêm/xóa block phía trước. FIX: dùng uid_suffix + ctx_body thay cho order.

7. SHAPE WITH TEXT CONTENT SIG — trước bị paste nhầm trả "shape|empty|..."
   dù có text, và dùng biến uid_suffix không tồn tại trong nhánh đó.
   FIX: nhánh có text trả đúng f"shape|{h}|p{para_count}|{ctx_body}".

8. MIXED SLICE OPCODE ORDER BUG — _match_mixed_slice emit replace theo ki
   nhưng delete được emit sau toàn bộ replace, với i1 có thể nhỏ hơn i1 của
   replace cuối → opcodes không tăng dần theo i1 → json_builder tính
   seq_index sai → thứ tự hiển thị bị đảo.
   FIX: sau khi _match_mixed_slice emit xong, sort toàn bộ refined theo
   (i1, j1) để đảm bảo tăng dần tuyệt đối trước khi trả về.
"""

from __future__ import annotations

import difflib
import hashlib
from typing import List, Set, Tuple

from src.services.block.block_builder import _norm
from src.services.block.signature import _split_heading, _norm_text
from src.services.models.block import Block

Opcode = Tuple[str, int, int, int, int]


# ══════════════════════════════════════════════════════════════════════════════
# Text helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_text(block: Block) -> str:
    """Thu thập toàn bộ text paragraph trong shape, đệ quy vào shape lồng nhau."""
    def _collect(node) -> list:
        parts = []
        for child in (node.children or []):
            if child.type == "paragraph":
                txt = _norm_text(child.content.get("text", ""))
                if txt:
                    parts.append(txt)
            elif child.type == "shape":
                parts.extend(_collect(child))
        return parts

    return " ".join(_collect(block.node))


def _count_text_paragraphs(node) -> int:
    count = 0
    for child in (getattr(node, "children", []) or []):
        t = getattr(child, "type", None)
        if t == "paragraph":
            txt = _norm_text((getattr(child, "content", {}) or {}).get("text", ""))
            if txt:
                count += 1
        elif t == "shape":
            count += _count_text_paragraphs(child)
    return count


# ══════════════════════════════════════════════════════════════════════════════
# Heading context normalizer
# ══════════════════════════════════════════════════════════════════════════════

def _heading_ctx_body(heading_ctx: str) -> str:
    """
    Chuẩn hoá heading_ctx thành chuỗi chỉ gồm tên heading, bỏ số chương.

    "5.1 Quy trình A > 5.1.2 Bước kiểm tra"
    → "quy trình a > bước kiểm tra"

    Giải quyết đồng thời 2 yêu cầu xung đột:

    HEADING SHIFT: "5.1 Quy trình A" và "5.3 Quy trình A" (sau khi thêm heading)
    → cùng ctx_body "quy trình a" → shape bên dưới vẫn match được.

    CROSS-MATCH: "Quy trình A" và "Quy trình B" → ctx_body khác nhau
    → shape cùng text ở 2 heading tên khác nhau không bị match nhầm.
    """
    if not heading_ctx:
        return ""
    parts = heading_ctx.split(" > ")
    bodies = []
    for part in parts:
        _, body = _split_heading(part)
        bodies.append(body)
    return " > ".join(bodies)


# ══════════════════════════════════════════════════════════════════════════════
# Similarity
# ══════════════════════════════════════════════════════════════════════════════

def _order_bonus(a: Block, b: Block) -> float:
    """
    Bonus nếu 2 block gần nhau theo order.

    Chỉ dùng trong _block_similarity để tiebreak — không dùng trong
    _content_sig vì order tuyệt đối không stable cross-document.
    """
    ao = a.order or 0
    bo = b.order or 0
    d = abs(ao - bo)
    if d <= 1:
        return 0.25
    if d <= 3:
        return 0.15
    if d <= 8:
        return 0.05
    return 0.0


def _block_similarity(a: Block, b: Block) -> float:
    if a.type != b.type:
        return 0.0

    same_heading = a.heading_ctx == b.heading_ctx

    if a.type == "shape":
        a_text = _shape_text(a)
        b_text = _shape_text(b)

        if not a_text and not b_text:
            base = 0.45 if same_heading else 0.05
            return base

        if not a_text or not b_text:
            base = 0.45 if same_heading else 0.0
            return base

        text_ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
        heading_bonus = 0.2 if same_heading else 0.0
        return min(1.0, text_ratio + heading_bonus)

    if a.type == "table":
        a_text = (a.signature or "").strip()
        b_text = (b.signature or "").strip()
        text_ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
        if same_heading:
            return min(1.0, text_ratio + 0.35)  # bonus nhưng không force >= 0.5
        return min(1.0, text_ratio + 0.15)

    heading_bonus = 0.35 if same_heading else 0.15
    a_text = (a.signature or "").strip()
    b_text = (b.signature or "").strip()
    text_ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
    return min(1.0, text_ratio + heading_bonus)


# ══════════════════════════════════════════════════════════════════════════════
# Content-only signature (không dùng heading_ctx đầy đủ)
# ══════════════════════════════════════════════════════════════════════════════

def _content_sig(block: Block) -> str:
    t = block.type

    if t == "shape":
        txt = _shape_text(block)
        ctx_body = _heading_ctx_body(block.heading_ctx or "")

        if not txt:
            uid      = getattr(block.node, "uid", "") or ""
            uid_hash = hashlib.md5(uid.encode("utf-8")).hexdigest()[:8]
            return f"shape|empty|{uid_hash}|{ctx_body}"

        h          = hashlib.md5(txt.encode("utf-8")).hexdigest()[:16]
        para_count = _count_text_paragraphs(block.node)
        return f"shape|{h}|p{para_count}|{ctx_body}"

    if t == "heading":
        level = int(block.node.content.get("level", 1) or 1)
        txt   = _norm_text(block.node.content.get("text", ""))
        chapter, body = _split_heading(txt)
        chapter_depth = len(chapter.split(".")) if chapter else 0
        h = hashlib.md5(body.encode("utf-8")).hexdigest()[:12]
        return f"H{level}|d{chapter_depth}|{h}"

    return f"{t}|{block.signature or ''}"


# ══════════════════════════════════════════════════════════════════════════════
# Opcode sort key
# ══════════════════════════════════════════════════════════════════════════════
def _opcode_sort_key(op: Opcode) -> tuple:
    tag, i1, i2, j1, j2 = op
    return (i1, j1)
# ══════════════════════════════════════════════════════════════════════════════
# Main aligner
# ══════════════════════════════════════════════════════════════════════════════

def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    """
    Align 2 block list, trả về list opcode (tag, i1, i2, j1, j2).

    Luồng:
    1. SequenceMatcher trên content-only signature → raw opcodes
    2. Với mỗi replace opcode: refine thành pair replace hoặc delete+insert
       dựa trên _block_similarity (có heading bonus)
    3. Mixed slice (N-M replace) → greedy matching
    4. Sort toàn bộ refined theo (i1, j1) — đảm bảo tăng dần tuyệt đối.
       _match_mixed_slice có thể emit replace(i1=163) trước delete(i1=156)
       vì pairs được emit trước, unmatched được emit sau → lộn xộn.
       Sort này fix hoàn toàn vấn đề đó mà không ảnh hưởng logic matching.
    """
    a_sigs = [_content_sig(b) for b in a_blocks]
    b_sigs = [_content_sig(b) for b in b_blocks]

    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    raw_opcodes = sm.get_opcodes()
    refined: List[Opcode] = []

    for tag, i1, i2, j1, j2 in raw_opcodes:
        if tag != "replace":
            refined.append((tag, i1, i2, j1, j2))
            continue

        a_slice = a_blocks[i1:i2]
        b_slice = b_blocks[j1:j2]

        # ── 1-1 replace ───────────────────────────────────────────────────────
        if len(a_slice) == 1 and len(b_slice) == 1:
            similarity = _block_similarity(a_slice[0], b_slice[0])
            if similarity >= 0.45:
                refined.append(("replace", i1, i2, j1, j2))
            else:
                refined.append(("delete", i1, i2, j1, j1))
                refined.append(("insert", i2, i2, j1, j2))
            continue

        # ── N-N table pairing theo thứ tự ─────────────────────────────────────
        if (
            len(a_slice) == len(b_slice)
            and len(a_slice) > 0
            and all(b.type == "table" for b in a_slice)
            and all(b.type == "table" for b in b_slice)
        ):
            for k in range(len(a_slice)):
                sim = _block_similarity(a_slice[k], b_slice[k])
                if sim >= 0.45:
                    refined.append(("replace", i1 + k, i1 + k + 1, j1 + k, j1 + k + 1))
                else:
                    refined.append(("delete", i1 + k, i1 + k + 1, j1 + k, j1 + k))
                    refined.append(("insert", i1 + k + 1, i1 + k + 1, j1 + k, j1 + k + 1))
            continue

        # ── Mixed N-M replace → greedy ────────────────────────────────────────
        if len(a_slice) > 0 and len(b_slice) > 0:
            _match_mixed_slice(refined, a_blocks, b_blocks, i1, i2, j1, j2)
            continue

        refined.append((tag, i1, i2, j1, j2))

    # ── FIX OPCODE ORDER BUG ──────────────────────────────────────────────────
    # Sort toàn bộ refined theo (i1, j1) để đảm bảo tăng dần tuyệt đối.
    #
    # Tại sao cần sort ở đây thay vì chỉ sort trong _match_mixed_slice:
    # _match_mixed_slice emit pairs (replace) trước, unmatched (delete) sau.
    # Nếu có replace(i1=163) và delete(i1=156) trong cùng một mixed slice,
    # delete được append sau replace → refined không tăng dần.
    #
    # Tại sao sort (i1, j1) là safe:
    # - equal/insert/delete từ SequenceMatcher đã tăng dần theo i1 (j1)
    # - replace từ 1-1 và N-N cũng tăng dần
    # - Chỉ _match_mixed_slice mới có thể emit lộn xộn
    # - Sort stable (Python timsort) → preserve order của các opcode cùng i1
    #
    # json_builder.py dùng i1 (= ai trong replace) để tính seq_index
    # → sau khi sort, seq_index tăng dần đúng thứ tự văn bản gốc.
    refined.sort(key=_opcode_sort_key)

    return refined


# ══════════════════════════════════════════════════════════════════════════════
# Mixed slice matching
# ══════════════════════════════════════════════════════════════════════════════

def _match_mixed_slice(
    refined: List[Opcode],
    a_blocks: List[Block],
    b_blocks: List[Block],
    i1: int, i2: int,
    j1: int, j2: int,
) -> None:
    """
    Greedy matching cho N-M replace slice.

    Emit thứ tự: pairs (replace) trước, unmatched delete/insert sau.
    Thứ tự này có thể không tăng dần theo i1 — được fix bởi sort
    trong align_blocks() sau khi hàm này return.

    Ties: dùng order distance để ưu tiên match block gần nhau.
    """
    a_slice = a_blocks[i1:i2]
    b_slice = b_blocks[j1:j2]

    THRESHOLD = 0.3

    candidates: List[Tuple[float, int, int]] = []
    for ki, a in enumerate(a_slice):
        for kj, b in enumerate(b_slice):
            sim = _block_similarity(a, b)
            if sim >= THRESHOLD:
                candidates.append((sim, ki, kj))

    def _tie_key(item):
        sim, ki, kj = item
        ao = a_slice[ki].order or 0
        bo = b_slice[kj].order or 0
        return (-sim, abs(ao - bo), ki, kj)

    candidates.sort(key=_tie_key)

    matched_a: Set[int] = set()
    matched_b: Set[int] = set()
    pairs: List[Tuple[int, int]] = []

    for sim, ki, kj in candidates:
        if ki in matched_a or kj in matched_b:
            continue
        matched_a.add(ki)
        matched_b.add(kj)
        pairs.append((ki, kj))

    # Sort theo ki để emit replace theo thứ tự a
    pairs.sort(key=lambda x: x[0])

    for ki, kj in pairs:
        refined.append(("replace", i1 + ki, i1 + ki + 1, j1 + kj, j1 + kj + 1))

    # Unmatched a → delete
    # Note: i1+ki < i1+(ki+1) nhưng có thể i1+ki < i1 của replace trước đó
    # → được fix bởi sort trong align_blocks()
    for ki in sorted(ki for ki in range(len(a_slice)) if ki not in matched_a):
        refined.append(("delete", i1 + ki, i1 + ki + 1, j1, j1))
    # Unmatched b → insert
    for kj in sorted(kj for kj in range(len(b_slice)) if kj not in matched_b):
        refined.append(("insert", i2, i2, j1 + kj, j1 + kj + 1))