# src/services/diff/paragraph_diff.py
"""
So sánh 2 đoạn text ở mức word, trả về span list cho frontend highlight.

Normalize pipeline:
  norm_for_diff  : tách phẩy/chấm phẩy thành token riêng
                   → SequenceMatcher detect insert/delete dấu câu độc lập
  norm_for_align : xóa phẩy → coi \\n và "," là tương đương
                   → dùng để align lines trong multiline diff
  _detokenize    : join token list về string tự nhiên (không space trước phẩy)

space_before:
  Mỗi span mang field "space_before" (bool) — Python tính tại nguồn.
  Logic: không có space trước dấu câu ,;.!?:) và sau dấu mở ngoặc (.

Span fields:
  type         : "equal" | "delete" | "insert" | "replace" | "newline"
  action       : same as type (alias cho JS)
  side         : "both" | "left" | "right"
  old_text     : text bên original
  new_text     : text bên modified
  text         : text hiển thị chính (= old_text với equal/delete/replace, new_text với insert)
  space_before : bool — có cần thêm space trước khi ghép span này không

Span "newline" chỉ có field "type": "newline" — frontend render <br>.
"""

from __future__ import annotations

import difflib
from typing import Any, Dict, List, Optional

from src.services.extractor.utils import (
    norm_text    as _norm,
    norm_for_diff,
    norm_for_align,
    _detokenize,
)

# ── Punct sets cho space_before ──────────────────────────────────────────────
_NO_SPACE_BEFORE = {",", ";", ".", "!", "?", ":", ")"}
_NO_SPACE_AFTER  = {"("}


def _space_before(prev_tokens: List[str], cur_token: str) -> bool:
    """
    True nếu cần space trước cur_token khi ghép vào chuỗi hiển thị.
    False nếu span đầu tiên, cur_token là dấu đóng, hoặc token trước là dấu mở.
    """
    if not prev_tokens:
        return False
    if cur_token in _NO_SPACE_BEFORE:
        return False
    if prev_tokens[-1] in _NO_SPACE_AFTER:
        return False
    return True


def _space_before_replace(
    prev_old: List[str], prev_new: List[str],
    old_first: str, new_first: str,
) -> bool:
    """
    space_before cho replace span — tính cả 2 bên.
    Trả True chỉ khi cả old_side lẫn new_side đều cần space.
    """
    old_sb = _space_before(prev_old, old_first) if old_first else False
    new_sb = _space_before(prev_new, new_first) if new_first else False
    # Dùng OR — nếu một bên cần space thì emit space (safer cho hiển thị)
    return old_sb or new_sb


# ══════════════════════════════════════════════════════════════════════════════
# Single-line word diff
# ══════════════════════════════════════════════════════════════════════════════

def diff_words(
    old_text: str,
    new_text: str,
    old_display: Optional[str] = None,
    new_display: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Diff 2 text ở mức word. Trả dict:
      old_full_text : str
      new_full_text : str
      spans         : List[span_dict]

    Nếu text có \\n → delegate sang _diff_multiline.
    """
    old_raw = (old_display or "").strip() or (old_text or "").strip()
    new_raw = (new_display or "").strip() or (new_text or "").strip()

    # Multiline
    if "\n" in old_raw or "\n" in new_raw:
        return _diff_multiline(old_text, new_text, old_raw, new_raw)

    old_norm = norm_for_diff(old_text or "")
    new_norm = norm_for_diff(new_text or "")

    # Cả 2 rỗng
    if not old_norm and not new_norm:
        return {"old_full_text": old_raw, "new_full_text": new_raw, "spans": []}

    # Giống nhau
    if old_norm == new_norm:
        return {
            "old_full_text": old_raw,
            "new_full_text": new_raw,
            "spans": [{
                "type": "equal", "action": "equal", "side": "both",
                "old_text": old_raw, "new_text": new_raw, "text": old_raw,
                "space_before": False,
            }],
        }

    a = old_norm.split()
    b = new_norm.split()
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)

    spans: List[Dict[str, Any]] = []
    prev_old: List[str] = []
    prev_new: List[str] = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        ow = a[i1:i2]
        nw = b[j1:j2]
        os = _detokenize(ow)
        ns = _detokenize(nw)
        of = ow[0] if ow else ""
        nf = nw[0] if nw else ""

        if tag == "equal":
            if os:
                spans.append({
                    "type": "equal", "action": "equal", "side": "both",
                    "old_text": os, "new_text": os, "text": os,
                    "space_before": _space_before(prev_old, of),
                })
                prev_old = ow
                prev_new = nw

        elif tag == "delete":
            if os:
                spans.append({
                    "type": "delete", "action": "delete", "side": "left",
                    "old_text": os, "new_text": "", "text": os,
                    "space_before": _space_before(prev_old, of),
                })
                prev_old = ow

        elif tag == "insert":
            if ns:
                spans.append({
                    "type": "insert", "action": "insert", "side": "right",
                    "old_text": "", "new_text": ns, "text": ns,
                    "space_before": _space_before(prev_new, nf),
                })
                prev_new = nw

        elif tag == "replace":
            sb = _space_before_replace(prev_old, prev_new, of, nf)
            spans.append({
                "type": "replace", "action": "replace", "side": "both",
                "old_text": os, "new_text": ns, "text": os,
                "space_before": sb,
            })
            if ow:
                prev_old = ow
            if nw:
                prev_new = nw

    return {"old_full_text": old_raw, "new_full_text": new_raw, "spans": spans}


# ══════════════════════════════════════════════════════════════════════════════
# Multiline diff
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_line(
    ol: str, nl: str,
    on: str, nn: str,
    out: List[Dict[str, Any]],
) -> None:
    """Diff 1 cặp dòng và append spans vào out."""
    if on == nn:
        out.append({
            "type": "equal", "action": "equal", "side": "both",
            "old_text": ol, "new_text": nl, "text": ol,
            "space_before": False,
        })
        return

    result = diff_words(ol, nl, old_display=ol, new_display=nl)
    line_spans = result.get("spans", [])
    if line_spans:
        out.extend(line_spans)
    else:
        out.append({
            "type": "replace", "action": "replace", "side": "both",
            "old_text": ol, "new_text": nl, "text": ol,
            "space_before": False,
        })


def _add_newline(spans: List[Dict[str, Any]]) -> None:
    if spans:
        spans.append({"type": "newline"})


def _diff_multiline(
    old_text: str, new_text: str,
    old_raw:  str, new_raw:  str,
) -> Dict[str, Any]:
    """
    Diff từng dòng, chèn span {"type":"newline"} giữa các dòng.
    Dùng norm_for_align để align — coi \\n và phẩy là tương đương.
    """
    old_lines  = old_raw.split("\n")
    new_lines  = new_raw.split("\n")
    old_norms  = [norm_for_align(l) for l in old_lines]
    new_norms  = [norm_for_align(l) for l in new_lines]

    sm = difflib.SequenceMatcher(a=old_norms, b=new_norms, autojunk=False)
    spans: List[Dict[str, Any]] = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():

        if tag == "equal":
            for i in range(i1, i2):
                _add_newline(spans)
                spans.append({
                    "type": "equal", "action": "equal", "side": "both",
                    "old_text": old_lines[i], "new_text": old_lines[i],
                    "text": old_lines[i], "space_before": False,
                })

        elif tag == "replace":
            ob = old_lines[i1:i2];  nb = new_lines[j1:j2]
            on = old_norms[i1:i2];  nn = new_norms[j1:j2]

            inner = difflib.SequenceMatcher(a=on, b=nn, autojunk=False)
            for it, ii1, ii2, ij1, ij2 in inner.get_opcodes():

                if it == "equal":
                    for k in range(ii1, ii2):
                        _add_newline(spans)
                        spans.append({
                            "type": "equal", "action": "equal", "side": "both",
                            "old_text": ob[k], "new_text": ob[k],
                            "text": ob[k], "space_before": False,
                        })

                elif it == "replace":
                    n_pairs = min(ii2 - ii1, ij2 - ij1)
                    for k in range(n_pairs):
                        _add_newline(spans)
                        _diff_one_line(ob[ii1+k], nb[ij1+k],
                                       on[ii1+k], nn[ij1+k], spans)
                    for k in range(ii1+n_pairs, ii2):
                        _add_newline(spans)
                        spans.append({
                            "type":"delete","action":"delete","side":"left",
                            "old_text":ob[k],"new_text":"","text":ob[k],
                            "space_before":False,
                        })
                    for k in range(ij1+n_pairs, ij2):
                        _add_newline(spans)
                        spans.append({
                            "type":"insert","action":"insert","side":"right",
                            "old_text":"","new_text":nb[k],"text":nb[k],
                            "space_before":False,
                        })

                elif it == "delete":
                    for k in range(ii1, ii2):
                        _add_newline(spans)
                        spans.append({
                            "type":"delete","action":"delete","side":"left",
                            "old_text":ob[k],"new_text":"","text":ob[k],
                            "space_before":False,
                        })

                elif it == "insert":
                    for k in range(ij1, ij2):
                        _add_newline(spans)
                        spans.append({
                            "type":"insert","action":"insert","side":"right",
                            "old_text":"","new_text":nb[k],"text":nb[k],
                            "space_before":False,
                        })

        elif tag == "delete":
            for i in range(i1, i2):
                _add_newline(spans)
                spans.append({
                    "type":"delete","action":"delete","side":"left",
                    "old_text":old_lines[i],"new_text":"","text":old_lines[i],
                    "space_before":False,
                })

        elif tag == "insert":
            for j in range(j1, j2):
                _add_newline(spans)
                spans.append({
                    "type":"insert","action":"insert","side":"right",
                    "old_text":"","new_text":new_lines[j],"text":new_lines[j],
                    "space_before":False,
                })

    return {"old_full_text": old_raw, "new_full_text": new_raw, "spans": spans}