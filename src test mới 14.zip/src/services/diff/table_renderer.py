"""
diff/table_renderer.py
~~~~~~~~~~~~~~~~~~~~~~
Render TableDiffResult → dict cấu trúc cho frontend.

Output là list "visual rows" — mỗi item là 1 row trong UI diff table.
Frontend chỉ cần render dict này, không cần biết logic diff.

Schema output (1 visual row):
{
    "row_type":   str,          # EQUAL | CELL_MODIFIED | ROW_INSERTED | ROW_DELETED
                                # | ROW_LAYOUT_CHANGE | LAYOUT_MAJOR
    "show_left":  bool,         # có hiển thị cột trái không
    "show_right": bool,         # có hiển thị cột phải không
    "cells_left":  list[CellView],
    "cells_right": list[CellView],
    "meta": dict,               # thêm thông tin cho renderer (layout info, v.v.)
}

CellView schema:
{
    "col_index":  int,
    "col_span":   int,
    "cell_type":  str,          # text | image | table | mixed | empty
    "change":     str,          # SAME | MODIFIED | INSERTED | DELETED | TYPE_CHANGE
    "content":    ContentView,  # tuỳ theo cell_type
}

ContentView tuỳ cell_type:
    text:  { "spans": [{"text": str, "tag": str}] }
    image: { "data_uri": str, "width": int, "height": int, "same": bool }
    table: { "nested_rows": list[VisualRow] }   ← đệ quy
    mixed: { "text_spans": [...], "image": {...}, "table": {...} }
    empty: {}

Hiển thị theo yêu cầu:
    - ROW_INSERTED: cells_left rỗng, cells_right đầy đủ, bg xanh
    - ROW_DELETED:  cells_left đầy đủ, cells_right rỗng, bg đỏ
    - CELL_MODIFIED: cả 2 phía, word-diff highlight từng cell
    - ROW_LAYOUT_CHANGE: badge "layout changed", show as-is cả 2 phía
    - LAYOUT_MAJOR: 1 row duy nhất, show bảng nguyên cả 2 phía,
                    badge "layout thay đổi lớn"

EQUAL rows: render hay skip là tuỳ frontend (flag "show_equal" trong options).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.services.diff.table_diff import (
    CellDiffResult,
    RowDiffResult,
    TableDiffResult,
    WordSpan,
    diff_tables,
)
from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text


# ── Types ─────────────────────────────────────────────────────────────────────

CellView  = Dict[str, Any]
VisualRow = Dict[str, Any]


# ══════════════════════════════════════════════════════════════════════════════
# Cell content renderers
# ══════════════════════════════════════════════════════════════════════════════

def _render_spans(spans: List[WordSpan]) -> List[Dict]:
    return [{"text": s.text, "tag": s.tag} for s in spans]


def _render_plain_text(cell: DocNode) -> List[Dict]:
    """Text không có diff → tất cả tag = equal."""
    text = norm_text(cell.content.get("text", ""))
    if not text:
        return []
    return [{"text": text, "tag": "equal"}]


def _render_image_content(cell: DocNode, same: bool) -> Dict:
    """Tìm image node đầu tiên trong cell và trả info cần thiết."""
    for node in cell.walk():
        if node.type == "image":
            return {
                "data_uri":   node.content.get("data_uri", ""),
                "sha256":     node.content.get("sha256", ""),
                "width_emu":  node.content.get("width_emu", 0),
                "height_emu": node.content.get("height_emu", 0),
                "same":       same,
            }
    return {"data_uri": "", "same": same}


def _render_nested_diff(nested: TableDiffResult, show_equal: bool = False) -> Dict:
    """Đệ quy render nested TableDiffResult."""
    return {
        "nested_rows": render_table_diff(nested, show_equal=show_equal),
        "col_count_a": nested.col_count_a,
        "col_count_b": nested.col_count_b,
        "is_major":    nested.is_major_layout_change,
    }


def _render_cell_content(
    cell_result: CellDiffResult,
    side: str,              # "left" | "right"
    show_equal: bool,
) -> CellView:
    """
    Render 1 cell thành CellView cho 1 phía (left hoặc right).

    side="left"  → dùng node_a, spans_a
    side="right" → dùng node_b, spans_b
    """
    node   = cell_result.node_a if side == "left" else cell_result.node_b
    spans  = cell_result.spans_a if side == "left" else cell_result.spans_b
    cspan  = cell_result.col_span_a if side == "left" else cell_result.col_span_b
    change = cell_result.change_type

    if node is None:
        # Phía không tồn tại (INSERTED nhìn từ left, DELETED nhìn từ right)
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": "empty",
            "change":    "EMPTY_PLACEHOLDER",
            "content":   {},
        }

    cell_type = node.content.get("cell_type", "text")

    # ── Empty ────────────────────────────────────────────────────────────────
    if cell_type == "empty":
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": "empty",
            "change":    "SAME",
            "content":   {},
        }

    # ── Nested table diff ────────────────────────────────────────────────────
    if change == "TABLE_DIFF" and cell_result.nested_diff:
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": "table",
            "change":    "TABLE_DIFF",
            "content":   _render_nested_diff(cell_result.nested_diff, show_equal),
        }

    # ── TYPE_CHANGE: show as-is với badge ────────────────────────────────────
    if change == "TYPE_CHANGE":
        content = _build_raw_content(node)
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": cell_type,
            "change":    "TYPE_CHANGE",
            "content":   content,
        }

    # ── Image ────────────────────────────────────────────────────────────────
    if change in ("IMAGE_SAME", "IMAGE_MODIFIED"):
        same = (change == "IMAGE_SAME")
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": "image",
            "change":    "SAME" if same else "MODIFIED",
            "content":   {"image": _render_image_content(node, same)},
        }

    # ── Text (bao gồm CELL_INSERTED, CELL_DELETED, TEXT_SAME, TEXT_MODIFIED) ──
    if change == "TEXT_SAME":
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": cell_type,
            "change":    "SAME",
            "content":   {"spans": _render_plain_text(node)},
        }

    if change == "TEXT_MODIFIED":
        return {
            "col_index": cell_result.col_index,
            "col_span":  cspan,
            "cell_type": cell_type,
            "change":    "MODIFIED",
            "content":   {"spans": _render_spans(spans)},
        }

    # CELL_INSERTED / CELL_DELETED — show đầy đủ nội dung, không highlight
    raw_change = "INSERTED" if change == "CELL_INSERTED" else "DELETED"
    return {
        "col_index": cell_result.col_index,
        "col_span":  cspan,
        "cell_type": cell_type,
        "change":    raw_change,
        "content":   _build_raw_content(node),
    }


def _build_raw_content(node: DocNode) -> Dict:
    """
    Build content không có diff highlight — dùng cho as-is display
    (TYPE_CHANGE, INSERTED, DELETED, ROW_LAYOUT_CHANGE).
    """
    cell_type = node.content.get("cell_type", "text")

    if cell_type == "empty":
        return {}

    if cell_type == "image":
        return {"image": _render_image_content(node, same=False)}

    if cell_type == "table":
        tbl = next((c for c in (node.children or []) if c.type == "table"), None)
        if tbl:
            return {"table_text": norm_text(tbl.content.get("text", ""))}
        return {}

    # text hoặc mixed
    text = norm_text(node.content.get("text", "") or
                     node.content.get("text_display", ""))
    spans = [{"text": text, "tag": "equal"}] if text else []

    content: Dict = {"spans": spans}

    # mixed: thêm image nếu có
    if cell_type == "mixed":
        for child in (node.children or []):
            if child.type == "image":
                content["image"] = _render_image_content(node, same=False)
                break

    return content


# ══════════════════════════════════════════════════════════════════════════════
# Row renderers
# ══════════════════════════════════════════════════════════════════════════════

def _render_row_equal(row: RowDiffResult, show_equal: bool) -> Optional[VisualRow]:
    """EQUAL row — skip nếu không cần hiển thị."""
    if not show_equal:
        return None

    cells_left  = []
    cells_right = []

    for cr in (row.cells or []):
        if cr.node_a:
            cells_left.append({
                "col_index": cr.col_index,
                "col_span":  cr.col_span_a,
                "cell_type": cr.node_a.content.get("cell_type", "text"),
                "change":    "SAME",
                "content":   _build_raw_content(cr.node_a),
            })
        if cr.node_b:
            cells_right.append({
                "col_index": cr.col_index,
                "col_span":  cr.col_span_b,
                "cell_type": cr.node_b.content.get("cell_type", "text"),
                "change":    "SAME",
                "content":   _build_raw_content(cr.node_b),
            })

    return {
        "row_type":    "EQUAL",
        "show_left":   True,
        "show_right":  True,
        "cells_left":  cells_left,
        "cells_right": cells_right,
        "meta":        {},
    }


def _render_row_modified(row: RowDiffResult, show_equal: bool) -> VisualRow:
    """CELL_MODIFIED — 2 cột song song, word-diff highlight."""
    cells_left  = [_render_cell_content(cr, "left",  show_equal) for cr in row.cells]
    cells_right = [_render_cell_content(cr, "right", show_equal) for cr in row.cells]

    return {
        "row_type":    "CELL_MODIFIED",
        "show_left":   True,
        "show_right":  True,
        "cells_left":  cells_left,
        "cells_right": cells_right,
        "meta":        {},
    }


def _render_row_inserted(row: RowDiffResult) -> VisualRow:
    """ROW_INSERTED — phía trái trống, phải đầy đủ."""
    assert row.row_b is not None
    cells_right = []
    for cr in row.cells:
        if cr.node_b:
            cells_right.append({
                "col_index": cr.col_index,
                "col_span":  cr.col_span_b,
                "cell_type": cr.node_b.content.get("cell_type", "text"),
                "change":    "INSERTED",
                "content":   _build_raw_content(cr.node_b),
            })

    return {
        "row_type":    "ROW_INSERTED",
        "show_left":   False,
        "show_right":  True,
        "cells_left":  [],
        "cells_right": cells_right,
        "meta":        {},
    }


def _render_row_deleted(row: RowDiffResult) -> VisualRow:
    """ROW_DELETED — phía trái đầy đủ, phải trống."""
    assert row.row_a is not None
    cells_left = []
    for cr in row.cells:
        if cr.node_a:
            cells_left.append({
                "col_index": cr.col_index,
                "col_span":  cr.col_span_a,
                "cell_type": cr.node_a.content.get("cell_type", "text"),
                "change":    "DELETED",
                "content":   _build_raw_content(cr.node_a),
            })

    return {
        "row_type":    "ROW_DELETED",
        "show_left":   True,
        "show_right":  False,
        "cells_left":  cells_left,
        "cells_right": [],
        "meta":        {},
    }


def _render_row_layout_change(row: RowDiffResult, show_equal: bool) -> VisualRow:
    """
    ROW_LAYOUT_CHANGE — col_span_pattern khác nhau.

    Hiển thị as-is cả 2 phía với badge "layout changed".
    Cell vẫn được diff theo col_index để cung cấp thông tin tham khảo,
    nhưng không highlight word-diff (do col mapping có thể sai).
    """
    def _raw_cells(cells, side: str):
        out = []
        for cr in cells:
            node = cr.node_a if side == "left" else cr.node_b
            cspan = cr.col_span_a if side == "left" else cr.col_span_b
            if node:
                out.append({
                    "col_index": cr.col_index,
                    "col_span":  cspan,
                    "cell_type": node.content.get("cell_type", "text"),
                    "change":    "LAYOUT_CHANGE",
                    "content":   _build_raw_content(node),
                })
        return out

    return {
        "row_type":    "ROW_LAYOUT_CHANGE",
        "show_left":   True,
        "show_right":  True,
        "cells_left":  _raw_cells(row.cells, "left"),
        "cells_right": _raw_cells(row.cells, "right"),
        "meta": {
            "pattern_a": row.pattern_a,
            "pattern_b": row.pattern_b,
            "badge":     "layout thay đổi",
        },
    }


def _render_layout_major(result: TableDiffResult) -> List[VisualRow]:
    """
    LAYOUT_MAJOR — 1 visual row duy nhất, show toàn bảng 2 phía.
    Frontend quyết định cách render (2 bảng nhỏ bên cạnh nhau, v.v.)
    """
    def _flatten_table(tbl: Optional[DocNode]) -> str:
        if not tbl:
            return ""
        return norm_text(tbl.content.get("text", ""))

    return [{
        "row_type":    "LAYOUT_MAJOR",
        "show_left":   True,
        "show_right":  True,
        "cells_left":  [],   # frontend dùng table_a trực tiếp
        "cells_right": [],
        "meta": {
            "badge":       "cấu trúc bảng thay đổi lớn",
            "col_count_a": result.col_count_a,
            "col_count_b": result.col_count_b,
            "table_text_a": _flatten_table(result.table_a),
            "table_text_b": _flatten_table(result.table_b),
            # Frontend có thể truy cập table_a/table_b trực tiếp từ
            # TableDiffResult nếu cần render chi tiết hơn
        },
    }]


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def render_table_diff(
    result: TableDiffResult,
    show_equal: bool = False,
) -> List[VisualRow]:
    """
    Render TableDiffResult thành list VisualRow cho frontend.

    Args:
        result:     Kết quả từ diff_tables().
        show_equal: Có include EQUAL rows không (default False — skip).

    Returns:
        List[VisualRow] — mỗi item là 1 row trong UI diff table.
        Frontend render theo thứ tự list này.
    """
    if result.is_major_layout_change:
        return _render_layout_major(result)

    visual_rows: List[VisualRow] = []

    for row in result.rows:
        vr: Optional[VisualRow] = None

        if row.change_type == "EQUAL":
            vr = _render_row_equal(row, show_equal)

        elif row.change_type == "CELL_MODIFIED":
            vr = _render_row_modified(row, show_equal)

        elif row.change_type == "ROW_INSERTED":
            vr = _render_row_inserted(row)

        elif row.change_type == "ROW_DELETED":
            vr = _render_row_deleted(row)

        elif row.change_type == "ROW_LAYOUT_CHANGE":
            vr = _render_row_layout_change(row, show_equal)

        if vr is not None:
            visual_rows.append(vr)

    return visual_rows


def render_table_diff_from_nodes(
    table_a: DocNode,
    table_b: DocNode,
    show_equal: bool = False,
) -> List[VisualRow]:
    """
    Convenience wrapper: diff + render trong 1 bước.

    Args:
        table_a:    Table DocNode từ file gốc.
        table_b:    Table DocNode từ file đã sửa.
        show_equal: Hiển thị cả row giống nhau không.

    Returns:
        List[VisualRow] sẵn sàng cho frontend.
    """
    result = diff_tables(table_a, table_b)
    return render_table_diff(result, show_equal=show_equal)