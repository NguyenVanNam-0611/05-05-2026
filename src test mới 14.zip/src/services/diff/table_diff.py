# src/services/diff/table_diff.py
"""
So sánh 2 table node ở mức row → cell → paragraph / image / nested table.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHANGE TYPES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Row level:
  table_row_added          insert  — row mới
  table_row_deleted        delete  — row bị xóa
  table_row_modified       replace — ≥1 cell thay đổi
  table_row_merged         replace — N rows cũ → 1 row mới

Cell level (trong cell_changes của row):
  table_cell_unchanged     equal   — nội dung không đổi
  table_cell_modified      replace — nội dung thay đổi
  table_cell_span_changed  replace — colspan/rowspan đổi (text có thể đổi hoặc không)
  table_cell_added         insert  — cột mới
  table_cell_deleted       delete  — cột bị xóa
  table_cell_type_changed  replace — cell_type flip (text↔image↔table↔mixed)

Inner cell (trong changes của cell_change):
  paragraph_unchanged      equal
  paragraph_modified       replace — kèm word_diff
  paragraph_inserted       insert
  paragraph_deleted        delete
  image_unchanged          equal
  image_modified           replace
  image_added              insert
  image_deleted            delete
  nested_table_unchanged   equal
  nested_table_modified    replace — đệ quy diff_table
  nested_table_inserted    insert
  nested_table_deleted     delete
  nested_table_to_text     replace — content type flip: table → paragraph
  text_to_nested_table     replace — content type flip: paragraph → table
  nested_table_promoted    replace — nested table N×M expand thành sub-cells

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LUỒNG
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

diff_table(a, b)
  1. _row_sig cho mỗi row → SequenceMatcher align
  2. insert/delete → emit trực tiếp
  3. replace → _handle_replace_region:
       a. Promoted detection (nested expand → sub-cells)
       b. N→1: merge detection
       c. N↔M bình thường: inner SequenceMatcher → _diff_one_row per pair

_diff_one_row(ar, br)
  - Build col_map kể cả rowspan carry-over
  - Với mỗi cột: detect span change, add, delete, rồi _diff_cell

_diff_cell(ac, bc)
  - Type flip: nested↔text, mixed cases
  - Paragraphs: SequenceMatcher + similarity-based replace matching
  - Images: index-based pair
  - Nested tables: index-based pair, đệ quy diff_table

analyze_table_change(a, b, changes)
  → quyết định render_mode, filter noise, dedup
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

from __future__ import annotations

import difflib
import hashlib
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change, serialize_image
from src.services.extractor.utils import norm_text as _norm, norm_for_diff
from src.services.block.signature import _sig_row as _row_sig_fn

_EMU_TO_PX = 96 / 914400


# ══════════════════════════════════════════════════════════════════════════════
# Tree helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_rows(tbl: DocNode) -> List[DocNode]:
    return [c for c in (tbl.children or []) if c.type == "row"]

def _get_cells(row: DocNode) -> List[DocNode]:
    return [c for c in (row.children or []) if c.type == "cell"]

def _get_col_index(cell: DocNode) -> int:
    return int((cell.content or {}).get("col_index") or 0)

def _get_col_span(cell: DocNode) -> int:
    return int((cell.content or {}).get("col_span") or 1)

def _get_row_span(cell: DocNode) -> int:
    return int((cell.content or {}).get("row_span") or 1)

def _table_col_count(tbl: DocNode) -> int:
    cc = int((tbl.content or {}).get("col_count") or 0)
    if cc > 0:
        return cc
    # Fallback: tính từ cells
    best = 0
    for r in _get_rows(tbl):
        for c in _get_cells(r):
            end = _get_col_index(c) + _get_col_span(c)
            best = max(best, end)
    return best or max(
        (len(_get_cells(r)) for r in _get_rows(tbl)),
        default=0,
    )

def _cell_norm_text(cell: Optional[DocNode]) -> str:
    if not cell:
        return ""
    return norm_for_diff(cell.content.get("text", ""))

def _cell_display_text(cell: Optional[DocNode]) -> str:
    if not cell:
        return ""
    return cell.content.get("text_display", "") or _norm(cell.content.get("text", ""))

def _row_text(row: Optional[DocNode]) -> str:
    if not row:
        return ""
    return _norm(row.content.get("text", ""))

def _row_sig(row: DocNode) -> str:
    return _row_sig_fn(row)


# ══════════════════════════════════════════════════════════════════════════════
# Serialization
# ══════════════════════════════════════════════════════════════════════════════

def _ser_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None
    out: Dict[str, Any] = {
        "uid":      getattr(node, "uid",   None),
        "type":     node.type,
        "content":  node.content or {},
        "children": [_ser_node(c) for c in (node.children or [])],
    }
    if node.type == "image":
        c = node.content or {}
        out["data_uri"] = c.get("data_uri")
        out["image"] = {
            "data_uri":  c.get("data_uri"),
            "width_px":  round(c.get("width_emu",  0) * _EMU_TO_PX) or None,
            "height_px": round(c.get("height_emu", 0) * _EMU_TO_PX) or None,
            "mime":      c.get("mime"),
            "sha256":    c.get("sha256"),
            "floating":  c.get("floating", False),
        }
    return out


def _ser_cell(cell: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if cell is None:
        return None
    c = cell.content or {}

    # Bubble image data_uris lên top-level list
    image_uris: List[str] = []
    for ch in (cell.children or []):
        if ch.type == "image":
            uri = (ch.content or {}).get("data_uri")
            if uri:
                image_uris.append(uri)
        elif ch.type == "paragraph":
            for gch in (ch.children or []):
                if gch.type == "image":
                    uri = (gch.content or {}).get("data_uri")
                    if uri:
                        image_uris.append(uri)

    return {
        "uid":          getattr(cell, "uid", None),
        "type":         "cell",
        "text":         _norm(c.get("text", "")),
        "text_display": c.get("text_display", "") or _norm(c.get("text", "")),
        "row_index":    c.get("row_index"),
        "col_index":    c.get("col_index"),
        "row_span":     c.get("row_span", 1),
        "col_span":     c.get("col_span", 1),
        "is_merged":    c.get("is_merged", False),
        "cell_type":    c.get("cell_type", "text"),
        "has_text":     c.get("has_text",  False),
        "has_image":    c.get("has_image", False),
        "has_table":    c.get("has_table", False),
        "image_count":  c.get("image_count", 0),
        "images":       image_uris,
        "children":     [_ser_node(ch) for ch in (cell.children or [])],
    }


def _ser_row(row: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    cells = _get_cells(row)
    return {
        "uid":       getattr(row, "uid", None),
        "type":      "row",
        "row_index": (row.content or {}).get("row_index"),
        "text":      (row.content or {}).get("text", ""),
        "cells":     [_ser_cell(c) for c in cells],
    }


def _ser_full_table(tbl: DocNode) -> Dict[str, Any]:
    rows = _get_rows(tbl)
    return {
        "uid":       getattr(tbl, "uid", None),
        "type":      "table",
        "content":   tbl.content or {},
        "rows":      [_ser_row(r) for r in rows],
        "all_cells": [[_ser_cell(c) for c in _get_cells(r)] for r in rows],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Row display cells — grid layout kể cả rowspan carry-over
# ══════════════════════════════════════════════════════════════════════════════

def _build_row_display_cells(
    tbl: DocNode,
    target_row: DocNode,
) -> List[Optional[Dict[str, Any]]]:
    """
    Trả list cell serialized theo grid position của target_row,
    kể cả cell từ rowspan của row trên chiếm xuống (virtual cells).

    active[col] = {
        master_ser : serialized cell của master
        remain     : số row còn lại cần carry
        start_col  : col_index của master (để phân biệt master vs extension)
        col_span   : col_span của master
    }
    """
    rows      = _get_rows(tbl)
    col_count = _table_col_count(tbl)
    if col_count == 0:
        return [_ser_cell(c) for c in _get_cells(target_row)]

    target_id = id(target_row)
    # active là dict col → entry, mỗi col có entry riêng (tránh shared ref bug)
    active: Dict[int, Dict[str, Any]] = {}

    for r in rows:
        ri = int((r.content or {}).get("row_index", -1) or -1)
        is_target = id(r) == target_id

        # Build grid cho row này
        grid: List[Optional[Dict]] = [None] * col_count

        # 1. Apply carried-over rowspan từ active
        for col in range(col_count):
            entry = active.get(col)
            if entry is None:
                continue
            sc = entry["start_col"]
            if sc != col:
                # Đây là extension slot, sẽ được điền khi process sc
                continue
            master = entry["master_ser"]
            cs = entry["col_span"]
            # Virtual cell — placeholder cho rowspan carry
            virtual = dict(master)
            virtual["virtual_from_merge"] = True
            virtual["row_span"] = 1
            virtual["row_index"] = ri
            grid[col] = virtual
            for k in range(1, cs):
                if col + k < col_count:
                    grid[col + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": master.get("uid"),
                    }

        # 2. Place actual cells of this row
        for cell in _get_cells(r):
            ci = _get_col_index(cell)
            cs = _get_col_span(cell)
            rs = _get_row_span(cell)
            if ci < 0 or ci >= col_count:
                continue
            ser = _ser_cell(cell) or {}
            ser["virtual_from_merge"] = False
            grid[ci] = ser
            for k in range(1, cs):
                if ci + k < col_count:
                    grid[ci + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": ser.get("uid"),
                    }
            # Register rowspan carry
            if rs > 1:
                entry = {
                    "master_ser": ser,
                    "remain":     rs - 1,
                    "start_col":  ci,
                    "col_span":   cs,
                }
                for k in range(cs):
                    if ci + k < col_count:
                        active[ci + k] = entry

        if is_target:
            return grid

        # 3. Decrement remain, clear exhausted entries
        to_clear: List[int] = []
        seen_starts: Set[int] = set()
        for col in range(col_count):
            entry = active.get(col)
            if entry is None:
                continue
            sc = entry["start_col"]
            if sc in seen_starts:
                continue
            seen_starts.add(sc)
            entry["remain"] -= 1
            if entry["remain"] <= 0:
                cs = entry["col_span"]
                for k in range(cs):
                    if sc + k < col_count:
                        to_clear.append(sc + k)
        for col in to_clear:
            active.pop(col, None)

    # Fallback nếu không tìm được target_row trong rows
    return [_ser_cell(c) for c in _get_cells(target_row)]


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph sig + similarity (dùng trong cell và row diff)
# ══════════════════════════════════════════════════════════════════════════════

def _para_sig(node: DocNode) -> str:
    txt = _norm(node.content.get("text", ""))
    h   = hashlib.md5(txt.encode()).hexdigest()[:16] if txt else "empty"
    return f"P:{h}"


def _para_similarity(a: DocNode, b: DocNode) -> float:
    at = _norm(a.content.get("text", ""))
    bt = _norm(b.content.get("text", ""))
    if not at and not bt:
        return 1.0
    if not at or not bt:
        return 0.0
    return difflib.SequenceMatcher(a=at, b=bt, autojunk=False).ratio()


# ══════════════════════════════════════════════════════════════════════════════
# Replace-slice matching (similarity-based, không zip mù)
# ══════════════════════════════════════════════════════════════════════════════

def _match_para_slice(
    a_sl: List[DocNode],
    b_sl: List[DocNode],
    threshold: float = 0.25,
) -> List[Tuple[Optional[int], Optional[int]]]:
    """
    Greedy similarity matching, trả (ai, bi) pairs ordered theo ai.
    ai=None → insert từ b; bi=None → delete từ a.
    """
    if not a_sl:
        return [(None, j) for j in range(len(b_sl))]
    if not b_sl:
        return [(i, None) for i in range(len(a_sl))]

    cands = []
    for i, a in enumerate(a_sl):
        for j, b in enumerate(b_sl):
            sim = _para_similarity(a, b)
            if sim >= threshold:
                cands.append((sim, i, j))
    cands.sort(key=lambda x: -x[0])

    used_a: Set[int] = set()
    used_b: Set[int] = set()
    pairs: List[Tuple[int, int]] = []
    for _, i, j in cands:
        if i in used_a or j in used_b:
            continue
        used_a.add(i); used_b.add(j)
        pairs.append((i, j))
    pairs.sort(key=lambda x: x[0])

    result: List[Tuple[Optional[int], Optional[int]]] = []
    pair_map     = dict(pairs)
    pair_map_rev = {j: i for i, j in pairs}
    j_emitted: Set[int] = set()
    last_j = -1

    for i in range(len(a_sl)):
        j = pair_map.get(i)
        if j is not None:
            for jj in range(last_j + 1, j):
                if jj not in pair_map_rev:
                    result.append((None, jj))
                    j_emitted.add(jj)
            last_j = j
            result.append((i, j))
            j_emitted.add(j)
        else:
            result.append((i, None))

    for j in range(len(b_sl)):
        if j not in j_emitted:
            result.append((None, j))

    return result


# ══════════════════════════════════════════════════════════════════════════════
# Cell content grouping
# ══════════════════════════════════════════════════════════════════════════════

def _group_cell_children(cell: DocNode) -> Tuple[
    List[DocNode], List[DocNode], List[DocNode]
]:
    paras: List[DocNode] = []
    imgs:  List[DocNode] = []
    tbls:  List[DocNode] = []
    for c in (cell.children or []):
        if c.type == "paragraph":
            paras.append(c)
        elif c.type == "image":
            imgs.append(c)
        elif c.type == "table":
            tbls.append(c)
    return paras, imgs, tbls


# ══════════════════════════════════════════════════════════════════════════════
# Cell diff
# ══════════════════════════════════════════════════════════════════════════════

def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    """
    Diff nội dung bên trong 2 cell.
    Trả [] nếu không có thay đổi thực sự.

    Thứ tự xử lý:
    1. Type flip toàn phần: nested_table↔text, xử lý riêng
    2. Paragraphs: SequenceMatcher + similarity-based matching
    3. Images: index-based pair
    4. Nested tables: index-based pair, đệ quy diff_table
    """
    changes: List[Dict[str, Any]] = []

    a_paras, a_imgs, a_tbls = _group_cell_children(a)
    b_paras, b_imgs, b_tbls = _group_cell_children(b)

    a_has_text  = bool(a_paras)
    b_has_text  = bool(b_paras)
    a_has_table = bool(a_tbls)
    b_has_table = bool(b_tbls)
    a_has_img   = bool(a_imgs)
    b_has_img   = bool(b_imgs)

    # ── Type flip: nested table → text (pure, không mixed) ───────────────────
    if a_has_table and not a_has_text and not a_has_img \
            and b_has_text and not b_has_table and not b_has_img:
        a_text = " ".join(
            _norm(t.content.get("text", "")) for t in a_tbls
        )
        b_text = " ".join(_norm(p.content.get("text", "")) for p in b_paras)
        changes.append({
            "type":           "nested_table_to_text",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_text,
            "new_text":       b_text,
            "original_table": _ser_node(a_tbls[0]) if a_tbls else None,
            "modified_paras": [_ser_node(p) for p in b_paras],
        })
        return changes

    # ── Type flip: text → nested table (pure) ────────────────────────────────
    if b_has_table and not b_has_text and not b_has_img \
            and a_has_text and not a_has_table and not a_has_img:
        a_text = " ".join(_norm(p.content.get("text", "")) for p in a_paras)
        b_text = " ".join(
            _norm(t.content.get("text", "")) for t in b_tbls
        )
        changes.append({
            "type":           "text_to_nested_table",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_text,
            "new_text":       b_text,
            "original_paras": [_ser_node(p) for p in a_paras],
            "modified_table": _ser_node(b_tbls[0]) if b_tbls else None,
        })
        return changes

    # ── Paragraphs ────────────────────────────────────────────────────────────
    if a_paras or b_paras:
        a_sigs = [_para_sig(p) for p in a_paras]
        b_sigs = [_para_sig(p) for p in b_paras]
        sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)

        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                for k in range(i2 - i1):
                    changes.append({
                        "type":        "paragraph_unchanged",
                        "change_kind": "equal",
                        "original":    _ser_node(a_paras[i1 + k]),
                        "modified":    _ser_node(b_paras[j1 + k]),
                    })

            elif tag == "insert":
                for p in b_paras[j1:j2]:
                    changes.append({
                        "type":        "paragraph_inserted",
                        "change_kind": "insert",
                        "original":    None,
                        "modified":    _ser_node(p),
                    })

            elif tag == "delete":
                for p in a_paras[i1:i2]:
                    changes.append({
                        "type":        "paragraph_deleted",
                        "change_kind": "delete",
                        "original":    _ser_node(p),
                        "modified":    None,
                    })

            elif tag == "replace":
                a_sl = a_paras[i1:i2]
                b_sl = b_paras[j1:j2]
                pairs = _match_para_slice(a_sl, b_sl)

                for ai, bi in pairs:
                    if ai is not None and bi is not None:
                        ap = a_sl[ai]; bp = b_sl[bi]
                        old_t = _norm(ap.content.get("text", ""))
                        new_t = _norm(bp.content.get("text", ""))
                        if old_t != new_t:
                            wd = diff_words(
                                old_t, new_t,
                                old_display=ap.content.get("text_display") or old_t,
                                new_display=bp.content.get("text_display") or new_t,
                            )
                            # Merge image diff into paragraph diff if paragraph has images
                            ap_imgs = [c for c in (ap.children or []) if c.type == "image"]
                            bp_imgs = [c for c in (bp.children or []) if c.type == "image"]
                            inner: List[Dict] = [{
                                "type":             "paragraph_modified",
                                "old_full_text":    wd.get("old_full_text", old_t),
                                "new_full_text":    wd.get("new_full_text", new_t),
                                "spans":            wd.get("spans", []),
                                "original_content": ap.content,
                                "modified_content": bp.content,
                            }]
                            for ii in range(max(len(ap_imgs), len(bp_imgs))):
                                ai2 = ap_imgs[ii] if ii < len(ap_imgs) else None
                                bi2 = bp_imgs[ii] if ii < len(bp_imgs) else None
                                inner.append(build_image_change(ai2, bi2))
                            changes.append({
                                "type":        "paragraph_container_modified",
                                "change_kind": "replace",
                                "original":    _ser_node(ap),
                                "modified":    _ser_node(bp),
                                "changes":     inner,
                            })
                        else:
                            changes.append({
                                "type":        "paragraph_unchanged",
                                "change_kind": "equal",
                                "original":    _ser_node(ap),
                                "modified":    _ser_node(bp),
                            })
                    elif ai is not None:
                        changes.append({
                            "type":        "paragraph_deleted",
                            "change_kind": "delete",
                            "original":    _ser_node(a_sl[ai]),
                            "modified":    None,
                        })
                    elif bi is not None:
                        changes.append({
                            "type":        "paragraph_inserted",
                            "change_kind": "insert",
                            "original":    None,
                            "modified":    _ser_node(b_sl[bi]),
                        })

    # ── Images (direct in cell, không qua paragraph) ──────────────────────────
    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        changes.append(build_image_change(ai, bi))

    # ── Nested tables ─────────────────────────────────────────────────────────
    for i in range(max(len(a_tbls), len(b_tbls))):
        at = a_tbls[i] if i < len(a_tbls) else None
        bt = b_tbls[i] if i < len(b_tbls) else None

        if at is None:
            changes.append({
                "type":        "nested_table_inserted",
                "change_kind": "insert",
                "original":    None,
                "modified":    _ser_node(bt),
                "changes":     [],
            })
        elif bt is None:
            changes.append({
                "type":        "nested_table_deleted",
                "change_kind": "delete",
                "original":    _ser_node(at),
                "modified":    None,
                "changes":     [],
            })
        else:
            nested_ch = diff_table(at, bt)
            if nested_ch:
                changes.append({
                    "type":        "nested_table_modified",
                    "change_kind": "replace",
                    "original":    _ser_node(at),
                    "modified":    _ser_node(bt),
                    "changes":     nested_ch,
                })
            else:
                changes.append({
                    "type":        "nested_table_unchanged",
                    "change_kind": "equal",
                    "original":    _ser_node(at),
                    "modified":    _ser_node(bt),
                    "changes":     [],
                })

    # Filter out all-unchanged result
    has_real = any(
        c.get("change_kind") not in ("equal",)
        for c in changes
    )
    if not has_real:
        return []

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Col map — kể cả rowspan carry-over từ rows trên
# ══════════════════════════════════════════════════════════════════════════════

def _build_col_map_for_row(
    tbl: DocNode,
    target_row: DocNode,
) -> Dict[int, DocNode]:
    """
    Build map col_index → cell node cho target_row,
    kể cả cells từ rowspan của row trên đang occupy xuống.

    Trả dict col → DocNode. Col không có cell → không có entry.
    Cells có col_span > 1 được expand: col, col+1, ..., col+cs-1
    đều map về cùng cell node.
    """
    rows      = _get_rows(tbl)
    target_id = id(target_row)
    col_count = _table_col_count(tbl)

    # active: col → {cell: DocNode, remain: int, start_col: int, col_span: int}
    active: Dict[int, Dict[str, Any]] = {}

    for r in rows:
        # Apply carried-over rowspan
        col_map: Dict[int, DocNode] = {}
        seen_starts: Set[int] = set()
        for col in range(col_count):
            entry = active.get(col)
            if entry and entry["start_col"] == col and entry["start_col"] not in seen_starts:
                seen_starts.add(entry["start_col"])
                cell = entry["cell"]
                cs   = entry["col_span"]
                for k in range(cs):
                    if col + k < col_count:
                        col_map[col + k] = cell

        # Place actual cells
        for cell in _get_cells(r):
            ci = _get_col_index(cell)
            cs = _get_col_span(cell)
            rs = _get_row_span(cell)
            for k in range(cs):
                col_map[ci + k] = cell
            if rs > 1:
                entry = {"cell": cell, "remain": rs - 1,
                         "start_col": ci, "col_span": cs}
                for k in range(cs):
                    if ci + k < col_count:
                        active[ci + k] = entry

        if id(r) == target_id:
            return col_map

        # Decrement
        to_clear: List[int] = []
        seen2: Set[int] = set()
        for col in range(col_count):
            entry = active.get(col)
            if not entry or entry["start_col"] in seen2:
                continue
            seen2.add(entry["start_col"])
            entry["remain"] -= 1
            if entry["remain"] <= 0:
                cs = entry["col_span"]
                sc = entry["start_col"]
                for k in range(cs):
                    if sc + k < col_count:
                        to_clear.append(sc + k)
        for col in to_clear:
            active.pop(col, None)

    # Fallback
    col_map = {}
    for cell in _get_cells(target_row):
        ci = _get_col_index(cell)
        cs = _get_col_span(cell)
        for k in range(cs):
            col_map[ci + k] = cell
    return col_map


# ══════════════════════════════════════════════════════════════════════════════
# _diff_one_row
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_row(
    changes:  List[Dict[str, Any]],
    ar:       DocNode,
    br:       DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> None:
    """
    Diff 1 cặp row. Emit table_row_modified nếu có thay đổi.

    Dùng col_map kể cả rowspan carry-over để không bỏ sót cell.
    """
    a_map     = _build_col_map_for_row(a_tbl, ar)
    b_map     = _build_col_map_for_row(b_tbl, br)
    col_count = _table_col_count(b_tbl) or _table_col_count(a_tbl)
    all_cols  = sorted(set(a_map) | set(b_map))

    row_changed      = False
    row_cell_changes: List[Dict[str, Any]] = []

    # Track processed cell pairs to avoid duplicate diffs for rowspan-expanded cells
    processed: Set[Tuple[Any, Any]] = set()

    for col in all_cols:
        ac = a_map.get(col)
        bc = b_map.get(col)

        # Skip if this exact (ac, bc) pair was already processed (rowspan expansion)
        pair_key = (id(ac) if ac else None, id(bc) if bc else None)
        if pair_key in processed:
            continue
        processed.add(pair_key)

        # Determine if these cells are "primary" at this column
        ac_ci = _get_col_index(ac) if ac else col
        bc_ci = _get_col_index(bc) if bc else col

        # Both continuation (neither starts here)
        ac_is_cont = (ac is not None and ac_ci != col)
        bc_is_cont = (bc is not None and bc_ci != col)
        if ac_is_cont and bc_is_cont:
            continue

        # bc continuation, ac primary → ac deleted
        if bc_is_cont and not ac_is_cont and ac is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_deleted",
                "change_kind": "delete",
                "col_index":   col,
                "left_cell":   _ser_cell(ac),
                "right_cell":  None,
                "left_text":   _cell_norm_text(ac),
                "right_text":  "",
                "changes":     [],
            })
            continue

        # ac continuation, bc primary → bc added
        if ac_is_cont and not bc_is_cont and bc is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_added",
                "change_kind": "insert",
                "col_index":   col,
                "left_cell":   None,
                "right_cell":  _ser_cell(bc),
                "left_text":   "",
                "right_text":  _cell_norm_text(bc),
                "changes":     [],
            })
            continue

        if bc is None and ac is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_deleted",
                "change_kind": "delete",
                "col_index":   col,
                "left_cell":   _ser_cell(ac),
                "right_cell":  None,
                "left_text":   _cell_norm_text(ac),
                "right_text":  "",
                "changes":     [],
            })
            continue

        if ac is None and bc is not None:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_added",
                "change_kind": "insert",
                "col_index":   col,
                "left_cell":   None,
                "right_cell":  _ser_cell(bc),
                "left_text":   "",
                "right_text":  _cell_norm_text(bc),
                "changes":     [],
            })
            continue

        if ac is None or bc is None:
            continue

        a_cs = _get_col_span(ac);  b_cs = _get_col_span(bc)
        a_rs = _get_row_span(ac);  b_rs = _get_row_span(bc)

        # colspan thay đổi
        if a_cs != b_cs:
            # Gom text của các a-cells bị cover bởi b-span
            a_covered = []
            seen_ac: Set[Any] = set()
            for kc in range(bc_ci, bc_ci + b_cs):
                cell_at_kc = a_map.get(kc)
                if cell_at_kc and id(cell_at_kc) not in seen_ac:
                    seen_ac.add(id(cell_at_kc))
                    a_covered.append(cell_at_kc)
            a_combined = " ".join(
                _cell_norm_text(c) for c in a_covered if _cell_norm_text(c)
            )
            b_text = _cell_norm_text(bc)
            wd = diff_words(a_combined, b_text) if a_combined != b_text else None

            row_changed = True
            row_cell_changes.append({
                "type":             "table_cell_span_changed",
                "change_kind":      "replace",
                "col_index":        col,
                "left_cell":        _ser_cell(ac),
                "right_cell":       _ser_cell(bc),
                "left_text":        a_combined,
                "right_text":       b_text,
                "left_col_span":    a_cs,
                "right_col_span":   b_cs,
                "left_row_span":    a_rs,
                "right_row_span":   b_rs,
                "left_cells":       [_ser_cell(c) for c in a_covered],
                "changes": [{
                    "type":          "paragraph_modified",
                    "old_full_text": a_combined,
                    "new_full_text": b_text,
                    "spans":         (wd or {}).get("spans", []),
                }] if wd else [],
            })
            # Mark a_covered cells processed
            for c in a_covered:
                for kc in range(_get_col_index(c),
                                _get_col_index(c) + _get_col_span(c)):
                    processed.add((id(c), id(bc)))
            continue

        # rowspan thay đổi (colspan giống nhau)
        span_meta: Dict[str, Any] = {}
        if a_rs != b_rs:
            span_meta = {
                "left_row_span":  a_rs,
                "right_row_span": b_rs,
                "row_span_changed": True,
            }

        # Cell type changed (text↔image↔table↔mixed↔empty)
        a_ct = (ac.content or {}).get("cell_type", "text")
        b_ct = (bc.content or {}).get("cell_type", "text")
        if a_ct != b_ct and not _is_compatible_types(a_ct, b_ct):
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_type_changed",
                "change_kind": "replace",
                "col_index":   col,
                "left_cell":   _ser_cell(ac),
                "right_cell":  _ser_cell(bc),
                "left_text":   _cell_norm_text(ac),
                "right_text":  _cell_norm_text(bc),
                "left_type":   a_ct,
                "right_type":  b_ct,
                "changes":     _diff_cell(ac, bc),
                **span_meta,
            })
            continue

        # Normal cell diff
        cell_changes = _diff_cell(ac, bc)
        if cell_changes or span_meta:
            row_changed = True
            entry: Dict[str, Any] = {
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   col,
                "left_cell":   _ser_cell(ac),
                "right_cell":  _ser_cell(bc),
                "left_text":   _cell_norm_text(ac),
                "right_text":  _cell_norm_text(bc),
                "changes":     cell_changes,
                **span_meta,
            }
            row_cell_changes.append(entry)

    if row_changed:
        a_cells = _get_cells(ar)
        b_cells = _get_cells(br)
        changes.append({
            "type":                "table_row_modified",
            "change_kind":         "replace",
            "row_index":           row_idx,
            "col_count":           col_count,
            "left_row":            _ser_row(ar),
            "right_row":           _ser_row(br),
            "left_cells":          [_ser_cell(c) for c in a_cells],
            "right_cells":         [_ser_cell(c) for c in b_cells],
            "left_display_cells":  _build_row_display_cells(a_tbl, ar),
            "right_display_cells": _build_row_display_cells(b_tbl, br),
            "left_text":           _row_text(ar),
            "right_text":          _row_text(br),
            "cell_changes":        row_cell_changes,
        })


def _is_compatible_types(a_ct: str, b_ct: str) -> bool:
    """
    True nếu 2 cell_type được coi là compatible (diff bình thường).
    Mixed với text/image/table vẫn diff được — chỉ pure-flip mới emit type_changed.
    """
    compatible_groups = [
        {"text", "empty"},
        {"text", "mixed"},
        {"image", "mixed"},
        {"table", "mixed"},
    ]
    for g in compatible_groups:
        if a_ct in g and b_ct in g:
            return True
    return a_ct == b_ct


# ══════════════════════════════════════════════════════════════════════════════
# Merge detection
# ══════════════════════════════════════════════════════════════════════════════

def _row_token_set(row: DocNode) -> Set[str]:
    """Build token set từ tất cả cells trong row."""
    tokens: Set[str] = set()
    full = _row_text(row).lower()
    for raw in re.split(r"[,;\n\s]+", full):
        tok = _norm(raw)
        if tok and len(tok) >= 2:
            tokens.add(tok)
    return tokens


def _detect_merge(
    a_rows: List[DocNode],
    b_row:  DocNode,
) -> Optional[List[int]]:
    """
    Detect N rows cũ → 1 row mới (merge).
    Điều kiện: ≥2 a_rows, tất cả text tokens của mỗi a_row đều xuất hiện trong b_row.
    Tokens phải >= 2 ký tự để tránh noise.
    """
    b_tokens = _row_token_set(b_row)
    if not b_tokens:
        return None

    merged: List[int] = []
    for idx, ar in enumerate(a_rows):
        a_texts = [
            _cell_norm_text(c) for c in _get_cells(ar)
            if _cell_norm_text(c)
        ]
        meaningful = [t for t in a_texts if len(t) >= 2]
        if not meaningful:
            continue
        if all(t.lower() in b_tokens for t in meaningful):
            merged.append(idx)

    return merged if len(merged) >= 2 else None


def _emit_merge(
    changes:  List[Dict[str, Any]],
    a_rows:   List[DocNode],
    merged_idxs: List[int],
    b_row:    DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> None:
    """Emit table_row_merged với đầy đủ thông tin tất cả rows đã merge."""
    merged_a = [a_rows[i] for i in merged_idxs]
    b_cells  = _get_cells(b_row)
    col_count = _table_col_count(b_tbl)

    a_combined_text = ", ".join(
        t for r in merged_a
        for c in _get_cells(r)
        for t in [_cell_norm_text(c)] if t
    )
    b_combined_text = " ".join(
        t for c in b_cells for t in [_cell_norm_text(c)] if t
    )

    # Cell-level changes: pair b-cell với a-cells từ cùng col
    cell_changes: List[Dict[str, Any]] = []
    for ci, bc in enumerate(b_cells):
        bc_text  = _cell_norm_text(bc)
        real_col = _get_col_index(bc) if (bc.content or {}).get("col_index") is not None else ci
        a_col_texts = [
            _cell_norm_text(ac)
            for ar in merged_a
            for ac in _get_cells(ar)
            if _get_col_index(ac) == real_col and _cell_norm_text(ac)
        ]
        if not a_col_texts:
            if bc_text:
                cell_changes.append({
                    "type":        "table_cell_added",
                    "change_kind": "insert",
                    "col_index":   real_col,
                    "left_cell":   None,
                    "right_cell":  _ser_cell(bc),
                    "left_text":   "",
                    "right_text":  bc_text,
                    "changes":     [],
                })
        else:
            a_joined = ", ".join(a_col_texts)
            if a_joined != bc_text:
                wd = diff_words(a_joined, bc_text)
                cell_changes.append({
                    "type":        "table_cell_merged",
                    "change_kind": "replace",
                    "col_index":   real_col,
                    "left_cell":   _ser_cell(next(
                        (ac for ar in merged_a for ac in _get_cells(ar)
                         if _get_col_index(ac) == real_col), None
                    )),
                    "right_cell":  _ser_cell(bc),
                    "left_text":   a_joined,
                    "right_text":  bc_text,
                    "word_diff":   wd,
                    "changes":     [],
                })

    changes.append({
        "type":                "table_row_merged",
        "change_kind":         "replace",
        "row_index":           row_idx,
        "col_count":           col_count,
        "merged_from_rows":    [_ser_row(r) for r in merged_a],
        "merged_from_count":   len(merged_a),
        # left_row = tất cả merged rows (frontend dùng merged_from_rows để render)
        "left_row":            _ser_row(merged_a[0]) if merged_a else None,
        "right_row":           _ser_row(b_row),
        "left_cells":          [_ser_cell(c) for r in merged_a for c in _get_cells(r)],
        "right_cells":         [_ser_cell(c) for c in b_cells],
        "left_display_cells":  _build_row_display_cells(a_tbl, merged_a[0]) if merged_a else [],
        "right_display_cells": _build_row_display_cells(b_tbl, b_row),
        "left_text":           a_combined_text,
        "right_text":          b_combined_text,
        "cell_changes":        cell_changes,
    })


# ══════════════════════════════════════════════════════════════════════════════
# Nested table promoted detection
# ══════════════════════════════════════════════════════════════════════════════

def _detect_promoted(
    a_cell:   DocNode,
    b_rows:   List[DocNode],
) -> Optional[Dict[str, Any]]:
    """
    Detect cell chứa nested table N×M bị promote thành sub-cells thật.

    Điều kiện:
    - a_cell chứa đúng 1 nested table, shape N×M
    - b_rows có đúng N rows
    - Coverage text >= 60%
    """
    nested_tbls = [c for c in (a_cell.children or []) if c.type == "table"]
    if len(nested_tbls) != 1:
        return None

    nested  = nested_tbls[0]
    n_rows  = int((nested.content or {}).get("row_count", 0) or 0)
    n_cols  = int((nested.content or {}).get("col_count", 0) or 0)
    if n_rows <= 0 or n_cols <= 0 or len(b_rows) != n_rows:
        return None

    # Text từ nested table
    nested_texts: List[str] = []
    for nr in _get_rows(nested):
        for nc in _get_cells(nr):
            t = _cell_norm_text(nc)
            if t:
                nested_texts.append(t)
    if not nested_texts:
        return None

    # Text từ b region
    a_ci = _get_col_index(a_cell)
    a_cs = _get_col_span(a_cell)
    b_region_texts: List[str] = []
    for br in b_rows:
        for bc in _get_cells(br):
            bci = _get_col_index(bc)
            if a_ci <= bci < a_ci + a_cs:
                t = _cell_norm_text(bc)
                if t:
                    b_region_texts.append(t)

    b_joined = " ".join(b_region_texts).lower()
    found    = sum(1 for t in nested_texts if t.lower() in b_joined)
    coverage = found / len(nested_texts)

    if coverage < 0.6:
        return None

    return {
        "type":           "nested_table_promoted",
        "change_kind":    "replace",
        "no_highlight":   True,
        "nested_shape":   f"{n_rows}x{n_cols}",
        "original_cell":  _ser_cell(a_cell),
        "original_table": _ser_node(nested),
        "promoted_rows":  [_ser_row(r) for r in b_rows],
        "original_text":  " ".join(nested_texts),
        "promoted_text":  " ".join(b_region_texts),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Replace region handler
# ══════════════════════════════════════════════════════════════════════════════

def _handle_replace_region(
    changes: List[Dict[str, Any]],
    a_slice: List[DocNode],
    b_slice: List[DocNode],
    a_tbl:   DocNode,
    b_tbl:   DocNode,
    i1: int, j1: int,
) -> None:
    """
    Xử lý một replace region từ SequenceMatcher.

    Thứ tự ưu tiên:
    1. Promoted detection (1 a-row → N b-rows do nested expand)
    2. N→1 merge detection
    3. Inner SequenceMatcher cho N↔M bình thường
    """
    n_a = len(a_slice)
    n_b = len(b_slice)

    # 1. Promoted: 1 a-row chứa nested table → N b-rows
    if n_a == 1:
        ar = a_slice[0]
        cells_with_nested = [
            c for c in _get_cells(ar)
            if any(ch.type == "table" for ch in (c.children or []))
        ]
        for a_cell in cells_with_nested:
            result = _detect_promoted(a_cell, b_slice)
            if result is not None:
                result["row_index"]   = j1
                result["a_row_index"] = i1
                changes.append(result)
                return

    # 2. Merge: N a-rows → 1 b-row
    if n_a > 1 and n_b == 1:
        merged_idxs = _detect_merge(a_slice, b_slice[0])
        if merged_idxs is not None:
            _emit_merge(changes, a_slice, merged_idxs, b_slice[0],
                        j1, a_tbl, b_tbl)
            # Emit delete cho a-rows không tham gia merge
            consumed = set(merged_idxs)
            for i, ar in enumerate(a_slice):
                if i not in consumed:
                    changes.append(_make_row_deleted(ar, i1 + i, a_tbl))
            return

    # 3. Inner SequenceMatcher
    inner_a_sigs = [_row_sig(r) for r in a_slice]
    inner_b_sigs = [_row_sig(r) for r in b_slice]
    inner_sm = difflib.SequenceMatcher(
        a=inner_a_sigs, b=inner_b_sigs, autojunk=False
    )

    for itag, ia1, ia2, ib1, ib2 in inner_sm.get_opcodes():
        if itag == "equal":
            continue

        if itag == "insert":
            for jj in range(ib1, ib2):
                changes.append(_make_row_added(b_slice[jj], j1 + jj, b_tbl))

        elif itag == "delete":
            for ii in range(ia1, ia2):
                changes.append(_make_row_deleted(a_slice[ii], i1 + ia1, a_tbl))

        elif itag == "replace":
            ia_sl = a_slice[ia1:ia2]
            ib_sl = b_slice[ib1:ib2]

            # N→1 merge trong inner slice
            if len(ia_sl) > 1 and len(ib_sl) == 1:
                midxs = _detect_merge(ia_sl, ib_sl[0])
                if midxs is not None:
                    _emit_merge(changes, ia_sl, midxs, ib_sl[0],
                                j1 + ib1, a_tbl, b_tbl)
                    consumed = set(midxs)
                    for i, ar in enumerate(ia_sl):
                        if i not in consumed:
                            changes.append(_make_row_deleted(ar, i1 + ia1 + i, a_tbl))
                    continue

            pairs = min(len(ia_sl), len(ib_sl))
            for k in range(pairs):
                _diff_one_row(changes, ia_sl[k], ib_sl[k],
                              i1 + ia1 + k, a_tbl, b_tbl)
            for ii in range(pairs, len(ia_sl)):
                changes.append(_make_row_deleted(ia_sl[ii], i1 + ia1 + ii, a_tbl))
            for jj in range(pairs, len(ib_sl)):
                changes.append(_make_row_added(ib_sl[jj], j1 + ib1 + jj, b_tbl))


def _make_row_added(br: DocNode, row_idx: int, b_tbl: DocNode) -> Dict[str, Any]:
    b_cells = _get_cells(br)
    return {
        "type":                "table_row_added",
        "change_kind":         "insert",
        "row_index":           row_idx,
        "col_count":           _table_col_count(b_tbl),
        "left_row":            None,
        "right_row":           _ser_row(br),
        "left_cells":          [],
        "right_cells":         [_ser_cell(c) for c in b_cells],
        "left_display_cells":  [],
        "right_display_cells": _build_row_display_cells(b_tbl, br),
        "left_text":           "",
        "right_text":          _row_text(br),
        "cell_changes":        [],
    }


def _make_row_deleted(ar: DocNode, row_idx: int, a_tbl: DocNode) -> Dict[str, Any]:
    a_cells = _get_cells(ar)
    return {
        "type":                "table_row_deleted",
        "change_kind":         "delete",
        "row_index":           row_idx,
        "col_count":           _table_col_count(a_tbl),
        "left_row":            _ser_row(ar),
        "right_row":           None,
        "left_cells":          [_ser_cell(c) for c in a_cells],
        "right_cells":         [],
        "left_display_cells":  _build_row_display_cells(a_tbl, ar),
        "right_display_cells": [],
        "left_text":           _row_text(ar),
        "right_text":          "",
        "cell_changes":        [],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Public: diff_table
# ══════════════════════════════════════════════════════════════════════════════

def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    """
    Align rows bằng SequenceMatcher → diff từng region.
    Trả list change objects cho frontend.
    Trả [] nếu không có thay đổi thực sự.
    """
    changes: List[Dict[str, Any]] = []
    a_rows  = _get_rows(a_tbl)
    b_rows  = _get_rows(b_tbl)

    if not a_rows and not b_rows:
        return changes

    a_sigs = [_row_sig(r) for r in a_rows]
    b_sigs = [_row_sig(r) for r in b_rows]
    sm     = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue

        if tag == "insert":
            for jj in range(j1, j2):
                changes.append(_make_row_added(b_rows[jj], jj, b_tbl))

        elif tag == "delete":
            for ii in range(i1, i2):
                changes.append(_make_row_deleted(a_rows[ii], ii, a_tbl))

        elif tag == "replace":
            _handle_replace_region(
                changes,
                a_rows[i1:i2], b_rows[j1:j2],
                a_tbl, b_tbl,
                i1, j1,
            )

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Structure change detection
# ══════════════════════════════════════════════════════════════════════════════

def _table_has_nested(tbl: DocNode) -> bool:
    for r in _get_rows(tbl):
        for c in _get_cells(r):
            if any(ch.type == "table" for ch in (c.children or [])):
                return True
    return False


def detect_structure_change(a_tbl: DocNode, b_tbl: DocNode) -> bool:
    a_cols = int((a_tbl.content or {}).get("col_count", 0) or 0)
    b_cols = int((b_tbl.content or {}).get("col_count", 0) or 0)
    if a_cols > 0 and b_cols > 0 and a_cols != b_cols:
        if _table_has_nested(a_tbl) or _table_has_nested(b_tbl):
            return False
        return True
    # Fallback
    a_rows = _get_rows(a_tbl); b_rows = _get_rows(b_tbl)
    if a_rows and b_rows:
        a_max = max((len(_get_cells(r)) for r in a_rows), default=0)
        b_max = max((len(_get_cells(r)) for r in b_rows), default=0)
        if a_max != b_max:
            return True
    return False


# ══════════════════════════════════════════════════════════════════════════════
# analyze_table_change — high-level, dùng bởi json_builder
# ══════════════════════════════════════════════════════════════════════════════

TABLE_RENDER_FULL         = "full_table"
TABLE_RENDER_DELETED      = "table_deleted"
TABLE_RENDER_ROW_MODIFIED = "row_modified"


def get_header_row(tbl: DocNode) -> Optional[Dict[str, Any]]:
    rows = _get_rows(tbl)
    return _ser_row(rows[0]) if rows else None


def _is_span_noise(change: Dict[str, Any]) -> bool:
    """True nếu row_modified chỉ khác colspan nhưng text y hệt."""
    if change.get("type") != "table_row_modified":
        return False
    cc = change.get("cell_changes", [])
    if not cc:
        return False
    for c in cc:
        if c.get("type") != "table_cell_span_changed":
            return False
        if _norm(c.get("left_text", "")) != _norm(c.get("right_text", "")):
            return False
    return True


def _is_layout_only(change: Dict[str, Any]) -> bool:
    """True nếu thay đổi chỉ layout, text content không đổi."""
    ct = change.get("type", "")

    if ct == "table_row_modified":
        # Giữ lại nếu có type flip
        for cc in (change.get("cell_changes") or []):
            if cc.get("type") in (
                "nested_table_to_text", "text_to_nested_table",
                "nested_table_promoted", "table_cell_type_changed",
            ):
                return False
        left  = _norm(change.get("left_text",  ""))
        right = _norm(change.get("right_text", ""))
        return left == right

    if ct == "table_row_merged":
        left_parts = {
            _norm(cell.get("text", "") or "")
            for row in (change.get("merged_from_rows") or [])
            for cell in (row.get("cells") or [])
            if cell
        } - {""}
        right_parts = {
            _norm(cell.get("text", "") or "")
            for cell in (change.get("right_cells") or [])
            if cell
        } - {""}
        return left_parts == right_parts

    return False


def analyze_table_change(
    a_tbl:         Optional[DocNode],
    b_tbl:         Optional[DocNode],
    table_changes: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """
    Quyết định render_mode và chuẩn bị payload cho frontend.

    render_mode:
      table_deleted   → bảng bị xóa
      full_table      → hiện cả 2 bảng side-by-side
      row_modified    → hiện từng row thay đổi với highlight

    Trả None nếu không có thay đổi thực sự.
    """
    # Bảng bị xóa
    if a_tbl is not None and b_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_DELETED,
            "structure_changed":   False,
            "full_table_original": _ser_full_table(a_tbl),
            "full_table_modified": None,
            "header_row":          get_header_row(a_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "merged_rows":         [],
            "promoted_regions":    [],
            "table_changes":       [],
        }

    # Bảng mới
    if b_tbl is not None and a_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   False,
            "full_table_original": None,
            "full_table_modified": _ser_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "merged_rows":         [],
            "promoted_regions":    [],
            "table_changes":       [],
        }

    assert a_tbl is not None and b_tbl is not None

    structure_changed = detect_structure_change(a_tbl, b_tbl)

    # Filter noise
    meaningful = [c for c in table_changes if not _is_span_noise(c)]
    meaningful  = [c for c in meaningful   if not _is_layout_only(c)]

    # Dedup (cùng type + row_index giữ cái đầu)
    seen:    Set[Any] = set()
    deduped: List[Dict[str, Any]] = []
    for c in meaningful:
        ri  = c.get("row_index")
        ct  = c.get("type", "")
        key = (ct, ri) if ri is not None else id(c)
        if key not in seen:
            seen.add(key)
            deduped.append(c)
    meaningful = deduped

    # Structure changed nhưng không có meaningful change → full table view
    if structure_changed and not meaningful:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   True,
            "full_table_original": _ser_full_table(a_tbl),
            "full_table_modified": _ser_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "merged_rows":         [],
            "promoted_regions":    [],
            "table_changes":       [],
        }

    if not meaningful:
        return None

    return {
        "render_mode":         TABLE_RENDER_ROW_MODIFIED,
        "structure_changed":   structure_changed,
        "full_table_original": _ser_full_table(a_tbl),
        "full_table_modified": _ser_full_table(b_tbl),
        "header_row":          get_header_row(b_tbl),
        "added_rows":          [c for c in meaningful if c.get("type") == "table_row_added"],
        "deleted_rows":        [c for c in meaningful if c.get("type") == "table_row_deleted"],
        "merged_rows":         [c for c in meaningful if c.get("type") == "table_row_merged"],
        "promoted_regions":    [c for c in meaningful if c.get("type") == "nested_table_promoted"],
        "table_changes":       meaningful,
    }