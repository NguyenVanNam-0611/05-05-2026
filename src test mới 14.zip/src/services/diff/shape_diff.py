# src/services/diff/shape_diff.py
"""
So sánh 2 shape (textbox) node.

Shape chứa: paragraph, nested shape, table-in-textbox.
Tất cả đều được walk đệ quy để lấy paragraph lá có text.

Matching:
  SequenceMatcher trên _para_sig (MD5 của norm text) — tránh zip sai khi N≠M.
  Nhánh replace: inner SequenceMatcher trên similarity score,
  không zip mù theo index.

Emit:
  paragraph_equal    — text giống (kể cả khác format)
  paragraph_modified — text thay đổi, kèm word_diff
  paragraph_inserted — paragraph mới
  paragraph_deleted  — paragraph bị xóa

Trả [] nếu không có thay đổi text nào (thay đổi format-only bị bỏ qua).
Emit đủ equal để frontend render toàn bộ shape, không chỉ những dòng đổi.

Image trong shape:
  Được collect riêng và diff theo index (giống cell image diff).
  Emit image_unchanged / image_added / image_deleted / image_modified.
"""

from __future__ import annotations

import difflib
import hashlib
from typing import Any, Dict, List, Optional, Tuple

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change, serialize_image
from src.services.extractor.utils import norm_text as _norm


# ══════════════════════════════════════════════════════════════════════════════
# Serialization
# ══════════════════════════════════════════════════════════════════════════════

def _serialize_node(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if node is None:
        return None
    return {
        "uid":          getattr(node, "uid",   None),
        "type":         node.type,
        "display_type": node.type,
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  "") or "",
        "content":      node.content or {},
        "children":     [_serialize_node(c) for c in (node.children or [])],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Content collectors — walk đệ quy vào shape lồng nhau và table-in-textbox
# ══════════════════════════════════════════════════════════════════════════════

def _collect_paragraphs(node: DocNode) -> List[DocNode]:
    """
    Thu thập tất cả paragraph có text từ shape, theo thứ tự DFS:
      - paragraph trực tiếp trong shape
      - shape lồng nhau (đệ quy)
      - table trong textbox → row → cell → paragraph (đệ quy cell)
    """
    result: List[DocNode] = []
    for c in (node.children or []):
        if c.type == "paragraph":
            if _norm(c.content.get("text", "")):
                result.append(c)
        elif c.type == "shape":
            result.extend(_collect_paragraphs(c))
        elif c.type == "table":
            result.extend(_collect_paragraphs_from_table(c))
    return result


def _collect_paragraphs_from_table(tbl: DocNode) -> List[DocNode]:
    result: List[DocNode] = []
    for row in (tbl.children or []):
        if row.type != "row":
            continue
        for cell in (row.children or []):
            if cell.type != "cell":
                continue
            result.extend(_collect_paragraphs_from_cell(cell))
    return result


def _collect_paragraphs_from_cell(cell: DocNode) -> List[DocNode]:
    result: List[DocNode] = []
    for c in (cell.children or []):
        if c.type == "paragraph":
            if _norm(c.content.get("text", "")):
                result.append(c)
        elif c.type == "table":
            result.extend(_collect_paragraphs_from_table(c))
    return result


def _collect_images(node: DocNode) -> List[DocNode]:
    """Thu thập tất cả image node trực tiếp trong shape (không đệ quy sâu vào table)."""
    result: List[DocNode] = []
    for c in (node.children or []):
        if c.type == "image":
            result.append(c)
        elif c.type == "shape":
            result.extend(_collect_images(c))
    return result


# ══════════════════════════════════════════════════════════════════════════════
# Signature
# ══════════════════════════════════════════════════════════════════════════════

def _para_sig(node: DocNode) -> str:
    """Signature chỉ theo norm text — bỏ qua format/style."""
    txt = _norm(node.content.get("text", ""))
    h   = hashlib.md5(txt.encode("utf-8")).hexdigest()[:16] if txt else "empty"
    return f"P:{h}"


def _para_similarity(a: DocNode, b: DocNode) -> float:
    """Tỉ lệ giống nhau của 2 paragraph theo text (0.0–1.0)."""
    at = _norm(a.content.get("text", ""))
    bt = _norm(b.content.get("text", ""))
    if not at and not bt:
        return 1.0
    if not at or not bt:
        return 0.0
    return difflib.SequenceMatcher(a=at, b=bt, autojunk=False).ratio()


# ══════════════════════════════════════════════════════════════════════════════
# Change builder
# ══════════════════════════════════════════════════════════════════════════════

def _make_change(
    cid:         int,
    change_type: str,
    change_kind: str,
    original:    Optional[Dict[str, Any]],
    modified:    Optional[Dict[str, Any]],
    word_diff:   Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "id":           cid,
        "type":         change_type,
        "display_type": "paragraph",
        "change_kind":  change_kind,
        "original":     original,
        "modified":     modified,
        "word_diff":    word_diff,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Replace slice matching — similarity-based, không zip mù
# ══════════════════════════════════════════════════════════════════════════════

def _match_replace_slice(
    a_slice: List[DocNode],
    b_slice: List[DocNode],
    threshold: float = 0.3,
) -> List[Tuple[Optional[int], Optional[int]]]:
    """
    Greedy similarity matching trong replace slice.
    Trả list (ai, bi) pairs — None nghĩa là unmatched (delete hoặc insert).

    Thuật toán:
    1. Tính ma trận similarity
    2. Greedy: lấy pair có similarity cao nhất trước, mark đã dùng
    3. Unmatched a → (ai, None); unmatched b → (None, bi)

    Đảm bảo output ordered theo ai (sau đó bi) để emit đúng thứ tự.
    """
    if not a_slice or not b_slice:
        result: List[Tuple[Optional[int], Optional[int]]] = []
        for i in range(len(a_slice)):
            result.append((i, None))
        for j in range(len(b_slice)):
            result.append((None, j))
        return result

    # Build candidates
    candidates = []
    for i, a in enumerate(a_slice):
        for j, b in enumerate(b_slice):
            sim = _para_similarity(a, b)
            if sim >= threshold:
                candidates.append((sim, i, j))

    candidates.sort(key=lambda x: -x[0])

    used_a = set()
    used_b = set()
    pairs: List[Tuple[int, int]] = []

    for sim, i, j in candidates:
        if i in used_a or j in used_b:
            continue
        used_a.add(i)
        used_b.add(j)
        pairs.append((i, j))

    # Sort pairs theo ai
    pairs.sort(key=lambda x: x[0])

    # Build final ordered result
    # Interleave deletions before their matched pair, insertions after
    result = []
    j_emitted = set()
    pair_map = dict(pairs)          # ai → bi
    pair_map_rev = {j: i for i, j in pairs}  # bi → ai

    # Walk a indices in order, emit unmatched-b before each matched pair
    last_bi = -1
    for i in range(len(a_slice)):
        bi = pair_map.get(i)
        if bi is not None:
            # Emit any unmatched b that comes before this bi
            for j in range(last_bi + 1, bi):
                if j not in pair_map_rev:
                    result.append((None, j))
                    j_emitted.add(j)
            last_bi = bi
            result.append((i, bi))
            j_emitted.add(bi)
        else:
            result.append((i, None))

    # Remaining unmatched b after last pair
    for j in range(len(b_slice)):
        if j not in j_emitted:
            result.append((None, j))

    return result


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def diff_shape(a_shape: DocNode, b_shape: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh 2 shape node.

    Trả [] nếu không có thay đổi thực sự (chỉ format-only).
    Emit cả equal paragraphs để frontend render đủ context.

    Paragraphs: SequenceMatcher → similarity-based replace matching.
    Images: pair theo index (index-based là đủ vì thường 1–2 ảnh/shape).
    """
    a_paras = _collect_paragraphs(a_shape)
    b_paras = _collect_paragraphs(b_shape)
    a_imgs  = _collect_images(a_shape)
    b_imgs  = _collect_images(b_shape)

    # Không có gì
    if not a_paras and not b_paras and not a_imgs and not b_imgs:
        return []

    # --- Paragraph diff ---
    a_sigs = [_para_sig(p) for p in a_paras]
    b_sigs = [_para_sig(p) for p in b_paras]
    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    opcodes = sm.get_opcodes()

    has_para_change = any(tag != "equal" for tag, *_ in opcodes)
    has_img_change  = False

    # Quick check image change
    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if not images_equal(ai, bi):
            has_img_change = True
            break

    if not has_para_change and not has_img_change:
        return []

    changes: List[Dict[str, Any]] = []
    cid = 1

    # --- Emit paragraph changes ---
    for tag, i1, i2, j1, j2 in opcodes:

        if tag == "equal":
            for k in range(i2 - i1):
                a_node = a_paras[i1 + k]
                b_node = b_paras[j1 + k]
                changes.append(_make_change(
                    cid, "paragraph_equal", "equal",
                    _serialize_node(a_node), _serialize_node(b_node),
                ))
                cid += 1

        elif tag == "insert":
            for node in b_paras[j1:j2]:
                changes.append(_make_change(
                    cid, "paragraph_inserted", "insert",
                    None, _serialize_node(node),
                ))
                cid += 1

        elif tag == "delete":
            for node in a_paras[i1:i2]:
                changes.append(_make_change(
                    cid, "paragraph_deleted", "delete",
                    _serialize_node(node), None,
                ))
                cid += 1

        elif tag == "replace":
            a_sl = a_paras[i1:i2]
            b_sl = b_paras[j1:j2]

            pairs = _match_replace_slice(a_sl, b_sl)
            for ai, bi in pairs:
                if ai is not None and bi is not None:
                    a_node = a_sl[ai]
                    b_node = b_sl[bi]
                    old_t  = _norm(a_node.content.get("text", ""))
                    new_t  = _norm(b_node.content.get("text", ""))
                    if old_t != new_t:
                        wd = diff_words(
                            old_t, new_t,
                            old_display=a_node.content.get("text_display") or old_t,
                            new_display=b_node.content.get("text_display") or new_t,
                        )
                        changes.append(_make_change(
                            cid, "paragraph_modified", "replace",
                            _serialize_node(a_node), _serialize_node(b_node), wd,
                        ))
                    else:
                        # Text giống, chỉ format khác
                        changes.append(_make_change(
                            cid, "paragraph_equal", "equal",
                            _serialize_node(a_node), _serialize_node(b_node),
                        ))
                    cid += 1
                elif ai is not None:
                    changes.append(_make_change(
                        cid, "paragraph_deleted", "delete",
                        _serialize_node(a_sl[ai]), None,
                    ))
                    cid += 1
                elif bi is not None:
                    changes.append(_make_change(
                        cid, "paragraph_inserted", "insert",
                        None, _serialize_node(b_sl[bi]),
                    ))
                    cid += 1

    # --- Emit image changes ---
    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        img_change = build_image_change(ai, bi)
        img_change["id"] = cid
        changes.append(img_change)
        cid += 1

    # Nếu tất cả đều là equal (không có para thay đổi, chỉ emit equal para)
    # nhưng has_img_change=False → trả []
    # Trường hợp này đã được guard ở trên. Nhưng nếu vào đây mà chỉ có equal:
    all_equal = all(
        c.get("change_kind") == "equal"
        for c in changes
        if c.get("type") not in ("image_unchanged",)
    )
    img_all_equal = all(
        c.get("change_kind") == "equal"
        for c in changes
        if c.get("type") in ("image_unchanged", "image_modified", "image_added", "image_deleted")
    )
    if all_equal and img_all_equal:
        return []

    return changes