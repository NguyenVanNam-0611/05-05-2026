# src/services/diff/image_diff.py
"""
So sánh và serialize image nodes.

So sánh 2 tầng:
  Tầng 1 — sha256 byte-exact (từ content)
  Tầng 2 — perceptual hash qua images_changed() nếu có raw_bytes
  Fallback conservative (False) khi không đủ dữ liệu.

Payload chuẩn hoá:
  - field "floating" luôn có (True = anchor, False = inline)
  - px được tính từ EMU một lần duy nhất ở đây
  - data_uri bubble lên top-level để JS không phải walk nested dict

Change kinds:
  delete  — ảnh bị xóa  (left có, right None)
  insert  — ảnh mới     (left None, right có)
  replace — ảnh thay đổi (cả hai đều có)
  equal   — không đổi   (gọi bởi caller khi cần emit equal)
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from src.services.models.docnode import DocNode
from src.services.utils.hash import images_changed

_EMU_TO_PX = 96 / 914400   # 1 inch = 914400 EMU, 96 dpi


# ══════════════════════════════════════════════════════════════════════════════
# Equality
# ══════════════════════════════════════════════════════════════════════════════

def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    """
    True nếu 2 image node có nội dung giống nhau.

    Tầng 1: sha256 byte-exact — nhanh, stable.
    Tầng 2: perceptual hash — bỏ qua resize nhỏ và JPEG compression nhỏ.
    Fallback conservative False — báo diff thay vì bỏ sót.
    """
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a.type != "image" or b.type != "image":
        return False

    # Tầng 1
    a_hash = a.content.get("sha256") or a.content.get("hash")
    b_hash = b.content.get("sha256") or b.content.get("hash")
    if a_hash and b_hash:
        if a_hash == b_hash:
            return True
        # sha256 khác nhau — thử perceptual nếu có raw bytes

    # Tầng 2
    a_bytes = a.content.get("raw_bytes")
    b_bytes = b.content.get("raw_bytes")
    if a_bytes and b_bytes:
        return not images_changed(a_bytes, b_bytes)

    # Không đủ dữ liệu
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Serialization
# ══════════════════════════════════════════════════════════════════════════════

def serialize_image(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    """
    Serialize image node thành payload đầy đủ cho frontend render.
    Trả None nếu node None hoặc không phải type image.
    """
    if node is None:
        return None
    if node.type != "image":
        return None

    c = node.content or {}
    w_emu = c.get("width_emu")  or 0
    h_emu = c.get("height_emu") or 0

    return {
        "uid":          getattr(node, "uid",   None),
        "type":         "image",
        "display_type": "image",
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  "") or "",
        # Nested image dict — frontend dùng để render
        "image": {
            "name":       c.get("name"),
            "ext":        c.get("ext"),
            "sha256":     c.get("sha256") or c.get("hash"),
            "mime":       c.get("mime"),
            "rid":        c.get("rid"),
            "alt_text":   c.get("alt_text", ""),
            "width_emu":  w_emu,
            "height_emu": h_emu,
            "width_px":   round(w_emu  * _EMU_TO_PX) if w_emu  else c.get("width_px"),
            "height_px":  round(h_emu * _EMU_TO_PX) if h_emu else c.get("height_px"),
            "data_uri":   c.get("data_uri"),
            # floating: True=anchor(floating), False=inline, None=unknown→inline
            "floating":   c.get("floating", False),
        },
        # data_uri bubble lên để JS dễ access
        "data_uri":   c.get("data_uri"),
        "text":       c.get("text",    ""),
        "caption":    c.get("caption", ""),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Change builder
# ══════════════════════════════════════════════════════════════════════════════

def build_image_change(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """
    Tạo change object cho image — 4 trường hợp:
      delete  : a có, b None
      insert  : a None, b có
      replace : cả hai đều có, nội dung khác
      equal   : cả hai đều có, nội dung giống (dùng khi caller cần emit equal)

    Naming:
      left  = original (a) — bên trái trong side-by-side
      right = modified (b) — bên phải
    """
    left  = serialize_image(a)
    right = serialize_image(b)

    if a is not None and b is None:
        return {
            "type":        "image_deleted",
            "display_type":"image",
            "change_kind": "delete",
            "left":        left,
            "right":       None,
        }

    if a is None and b is not None:
        return {
            "type":        "image_added",
            "display_type":"image",
            "change_kind": "insert",
            "left":        None,
            "right":       right,
        }

    if images_equal(a, b):
        return {
            "type":        "image_unchanged",
            "display_type":"image",
            "change_kind": "equal",
            "left":        left,
            "right":       right,
        }

    return {
        "type":        "image_modified",
        "display_type":"image",
        "change_kind": "replace",
        "left":        left,
        "right":       right,
    }