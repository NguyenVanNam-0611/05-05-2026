"""
api/routes/images.py
~~~~~~~~~~~~~~~~~~~~
Serve ảnh tĩnh từ /tmp/docx_images/ qua GET /images/{filename}.

Tại sao không dùng StaticFiles của FastAPI:
    StaticFiles mount cả thư mục → không kiểm soát được cache header,
    không filter được file theo sha256 format, và không log được access.
    Route riêng cho phép set Cache-Control: immutable đúng cách —
    sha256 filename đảm bảo same URL = same content mãi mãi.

Cache strategy:
    Cache-Control: public, max-age=43200, immutable
    → Browser cache 12h (khớp với cleanup interval)
    → immutable = browser không re-validate khi reload
    → Ảnh cùng sha256 chỉ fetch 1 lần dù xuất hiện nhiều lần trong diff
"""

from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from src.services.utils.image_store import get_image_path, TMP_DIR

router = APIRouter(prefix="/images", tags=["images"])

# Chỉ cho phép filename dạng {sha256}.{ext} — không cho path traversal
_SAFE_FILENAME_RE = re.compile(r"^[a-f0-9]{64}\.(png|jpg|jpeg|gif|webp|bmp)$", re.IGNORECASE)

# Map extension → MIME
_EXT_TO_MIME: dict[str, str] = {
    "png":  "image/png",
    "jpg":  "image/jpeg",
    "jpeg": "image/jpeg",
    "gif":  "image/gif",
    "webp": "image/webp",
    "bmp":  "image/bmp",
}

# Cache 12h — khớp với MAX_AGE_HOURS trong image_store.py
_CACHE_HEADER = "public, max-age=43200, immutable"


@router.get("/{filename}")
async def serve_image(filename: str) -> FileResponse:
    """
    Serve ảnh theo filename = {sha256}.{ext}.

    Validation:
        - Filename phải match regex sha256 + ext — block path traversal
        - File phải tồn tại trong TMP_DIR
        - Không follow symlink ra ngoài TMP_DIR

    Headers:
        Cache-Control: public, max-age=43200, immutable
        Content-Type:  image/{ext}
    """
    # ── Validate filename format ──────────────────────────────────────────────
    if not _SAFE_FILENAME_RE.match(filename):
        raise HTTPException(status_code=400, detail="Invalid image filename")

    file_path = TMP_DIR / filename

    # ── Guard path traversal (resolve + check prefix) ────────────────────────
    try:
        resolved = file_path.resolve()
        if not str(resolved).startswith(str(TMP_DIR.resolve())):
            raise HTTPException(status_code=400, detail="Invalid path")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid path")

    # ── Check file exists ─────────────────────────────────────────────────────
    if not resolved.exists() or not resolved.is_file():
        raise HTTPException(status_code=404, detail="Image not found")

    ext      = filename.rsplit(".", 1)[-1].lower()
    media_type = _EXT_TO_MIME.get(ext, "image/png")

    return FileResponse(
        path=resolved,
        media_type=media_type,
        headers={"Cache-Control": _CACHE_HEADER},
    )