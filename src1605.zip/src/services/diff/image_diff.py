"""
diff/image_diff.py
~~~~~~~~~~~~~~~~~~
So sánh và serialize image nodes.

Thay đổi so với cũ:
  - _image_payload: dùng image_url (URL tĩnh /images/{sha256}.ext) thay data_uri
  - _image_payload: thêm param include_data=True/False
      True  → payload đầy đủ cho changed/added/deleted (có image_url)
      False → chỉ metadata cho equal (không có image_url, tiết kiệm bandwidth)
  - images_equal tầng 2: perceptual hash giờ hoạt động vì raw_bytes có trong content
  - _serialize_node (helper nội bộ): loại raw_bytes + image_url khỏi content dump
    để không leak vào JSON của các node khác (paragraph, cell...)
  - build_image_change: luôn include_data=True vì đây là ảnh đã thay đổi
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from src.services.models.docnode import DocNode
from src.services.utils.hash import images_changed


def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    """
    Kiểm tra 2 image node có nội dung giống nhau không.

    Tầng 1: sha256 byte-exact — nhanh, không decode ảnh.
    Tầng 2: perceptual hash từ raw_bytes — bỏ qua resize nhỏ / JPEG compression.
            Giờ hoạt động vì image.py lưu raw_bytes vào content.
    """
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if a.type != "image" or b.type != "image":
        return False

    # ── Tầng 1: sha256 byte-exact ─────────────────────────────────────────────
    a_hash = a.content.get("sha256") or a.content.get("hash")
    b_hash = b.content.get("sha256") or b.content.get("hash")

    if a_hash and b_hash:
        if a_hash == b_hash:
            return True
        # sha256 khác → thử tầng 2 với raw_bytes

    # ── Tầng 2: perceptual hash ───────────────────────────────────────────────
    # raw_bytes được lưu trong content bởi image.py (thay vì data_uri cũ)
    # → tầng này giờ thực sự chạy được
    a_bytes = a.content.get("raw_bytes")
    b_bytes = b.content.get("raw_bytes")

    if a_bytes and b_bytes:
        return not images_changed(a_bytes, b_bytes)

    # Không đủ dữ liệu → conservative: coi là đã thay đổi
    return False


def _image_payload(
    node: Optional[DocNode],
    include_data: bool = True,
) -> Optional[Dict[str, Any]]:
    """
    Serialize image node thành payload cho frontend.

    Args:
        include_data: True  → include image_url (ảnh changed/added/deleted)
                      False → chỉ metadata (ảnh equal — không cần render)

    image_url là URL tĩnh /images/{sha256}.{ext} do image_store.py tạo ra.
    Frontend dùng <img src={image_url}> — browser tự cache theo URL.

    raw_bytes bị loại khỏi payload — không serialize bytes ra JSON.
    """
    if node is None:
        return None
    if node.type != "image":
        return None

    content = node.content or {}

    width_emu  = content.get("width_emu")  or 0
    height_emu = content.get("height_emu") or 0

    px_per_emu = 96 / 914400
    width_px   = round(width_emu  * px_per_emu) if width_emu  else content.get("width")
    height_px  = round(height_emu * px_per_emu) if height_emu else content.get("height")

    image_url = content.get("image_url") if include_data else None

    return {
        "uid":          getattr(node, "uid",   None),
        "type":         "image",
        "display_type": "image",
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  ""),
        "image": {
            "name":       content.get("name"),
            "ext":        content.get("ext"),
            "hash":       content.get("hash"),
            "sha256":     content.get("sha256"),
            "width_emu":  width_emu,
            "height_emu": height_emu,
            "width_px":   width_px,
            "height_px":  height_px,
            "image_url":  image_url,   # ← URL tĩnh, không phải base64
            "mime":       content.get("mime"),
            "rid":        content.get("rid"),
            "floating":   content.get("floating", False),
        },
        "text":      content.get("text",    ""),
        "caption":   content.get("caption", ""),
        "image_url": image_url,   # bubble lên top-level để frontend dễ access
    }


def build_image_change(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """
    Tạo change object cho image.

    Ảnh changed/added/deleted luôn include_data=True
    → frontend nhận image_url đầy đủ để render.
    """
    # Luôn include data vì đây là ảnh đã xác định là thay đổi
    left_payload  = _image_payload(a, include_data=True)
    right_payload = _image_payload(b, include_data=True)

    # ── IMAGE DELETED ─────────────────────────────────────────────────────────
    if a is not None and b is None:
        return {
            "type":         "image_deleted",
            "display_type": "image",
            "change_kind":  "delete",
            "left":         left_payload,
            "right":        None,
            "left_img":     left_payload,
            "right_img":    None,
        }

    # ── IMAGE ADDED ───────────────────────────────────────────────────────────
    if b is not None and a is None:
        return {
            "type":         "image_added",
            "display_type": "image",
            "change_kind":  "insert",
            "left":         None,
            "right":        right_payload,
            "left_img":     None,
            "right_img":    right_payload,
        }

    # ── IMAGE MODIFIED ────────────────────────────────────────────────────────
    return {
        "type":         "image_modified",
        "display_type": "image",
        "change_kind":  "replace",
        "left":         left_payload,
        "right":        right_payload,
        "left_img":     left_payload,
        "right_img":    right_payload,
    }


def build_image_equal(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    """
    Tạo change object cho ảnh equal (không thay đổi).

    include_data=False → chỉ trả sha256 + metadata, không có image_url.
    Frontend không cần render ảnh equal → tiết kiệm bandwidth.
    """
    left_payload  = _image_payload(a, include_data=False)
    right_payload = _image_payload(b, include_data=False)

    return {
        "type":         "image_equal",
        "display_type": "image",
        "change_kind":  "equal",
        "left":         left_payload,
        "right":        right_payload,
        "left_img":     left_payload,
        "right_img":    right_payload,
    }