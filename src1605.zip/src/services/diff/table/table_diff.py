# src/services/diff/table_diff.py
"""
So sánh 2 table node ở mức row → cell → paragraph/image/nested table.

Chỉ chứa logic diff thuần. Utility và serialize đã tách ra:
  - table_helpers.py   : tree traversal, text extraction, structure detection
  - table_serialize.py : serialize DocNode → dict
  - table_analyze.py   : filter noise + chọn render mode

Fixes đã có:
  - SequenceMatcher trên row signature để align row trước khi diff
  - _diff_cell: xử lý nested table → text và ngược lại
  - _try_emit_merge: detect N rows → 1 row merge
  - _diff_one_row: map cell theo col_index thực, xử lý colspan thay đổi

Fixes mới trong file này:
  - _diff_cell_paragraphs: dùng SequenceMatcher thay zip cho paragraph
    → tránh pair sai khi insert dòng ở giữa cell
  - _diff_one_row_with_header_map: diff theo header mapping thay col_index
    → fix bug thêm cột ở giữa (Nhóm 2)
  - diff_table: tự detect header map khi structure_changed
    → tự động chọn header-aware diff khi phù hợp
  - _diff_cell: emit build_image_equal cho ảnh unchanged trong cell
    → frontend nhận đủ thông tin để render ảnh không đổi (dùng image_url)
"""

from __future__ import annotations

import difflib
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change, build_image_equal
from src.services.block.signature import _sig_row as _row_sig

from src.services.diff.table.table_helpers import (
    get_rows,
    get_cells,
    get_col_count,
    real_col_index,
    cell_text,
    cell_full_text,
    row_text,
    row_cell_texts,
    group_children_by_type,
    resolve_header_map,
)
from src.services.diff.table.table_serialize import (
    serialize_node,
    serialize_cell,
    serialize_row,
    build_row_display_cells,
)


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph diff inside cell
# ══════════════════════════════════════════════════════════════════════════════

def _diff_paragraph(a: DocNode, b: DocNode) -> Optional[Dict[str, Any]]:
    """
    So sánh 2 paragraph node — text + image.
    Trả None nếu không có thay đổi.
    """
    from src.services.extractor.utils import norm_text as _norm

    old_text    = _norm(a.content.get("text", ""))
    new_text    = _norm(b.content.get("text", ""))
    old_display = a.content.get("text_display") or old_text
    new_display = b.content.get("text_display") or new_text

    text_changed = old_text != new_text
    a_imgs = [c for c in (a.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.children or []) if c.type == "image"]

    if not text_changed and not a_imgs and not b_imgs:
        return None

    changes: List[Dict[str, Any]] = []

    if text_changed:
        word_diff   = diff_words(old_text, new_text, old_display=old_display, new_display=new_display)
        diff_result = word_diff if word_diff else {}
        changes.append({
            "type":             "paragraph_modified",
            "old_full_text":    diff_result.get("old_full_text", old_text),
            "new_full_text":    diff_result.get("new_full_text", new_text),
            "spans":            diff_result.get("spans", []),
            "original_content": a.content,
            "modified_content": b.content,
        })

    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if images_equal(ai, bi):
            changes.append(build_image_equal(ai, bi))
        else:
            changes.append(build_image_change(ai, bi))

    if not changes:
        return None

    return {
        "type":     "paragraph_container_modified",
        "original": serialize_node(a),
        "modified": serialize_node(b),
        "changes":  changes,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph list diff — dùng SequenceMatcher thay zip
# ══════════════════════════════════════════════════════════════════════════════

def _diff_cell_paragraphs(
    a_paras: List[DocNode],
    b_paras: List[DocNode],
) -> List[Dict[str, Any]]:
    """
    Diff list paragraph trong cell dùng SequenceMatcher trên text.

    FIX so với cũ (zip theo index):
    - Zip pair sai khi insert dòng ở giữa:
        A: ["Dòng 1", "Dòng 2", "Dòng 3"]
        B: ["Dòng 1", "Dòng mới", "Dòng 2", "Dòng 3"]
        → zip: Dòng 2 ↔ Dòng mới (sai), Dòng 3 ↔ Dòng 2 (sai)
    - SequenceMatcher align đúng trước khi pair.
    """
    from src.services.extractor.utils import norm_text as _norm

    changes: List[Dict[str, Any]] = []

    if not a_paras and not b_paras:
        return changes

    a_texts = [_norm(p.content.get("text", "")) for p in a_paras]
    b_texts = [_norm(p.content.get("text", "")) for p in b_paras]

    sm = difflib.SequenceMatcher(a=a_texts, b=b_texts, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                ap = a_paras[i1 + k]
                bp = b_paras[j1 + k]
                changes.append({
                    "type":        "paragraph_unchanged",
                    "change_kind": "equal",
                    "original":    serialize_node(ap),
                    "modified":    serialize_node(bp),
                })

        elif tag == "insert":
            for j in range(j1, j2):
                changes.append({
                    "type":        "paragraph_inserted",
                    "change_kind": "insert",
                    "original":    None,
                    "modified":    serialize_node(b_paras[j]),
                })

        elif tag == "delete":
            for i in range(i1, i2):
                changes.append({
                    "type":        "paragraph_deleted",
                    "change_kind": "delete",
                    "original":    serialize_node(a_paras[i]),
                    "modified":    None,
                })

        elif tag == "replace":
            pairs = min(i2 - i1, j2 - j1)
            for k in range(pairs):
                ap = a_paras[i1 + k]
                bp = b_paras[j1 + k]
                para_change = _diff_paragraph(ap, bp)
                if para_change:
                    changes.append(para_change)
                else:
                    changes.append({
                        "type":        "paragraph_unchanged",
                        "change_kind": "equal",
                        "original":    serialize_node(ap),
                        "modified":    serialize_node(bp),
                    })
            for i in range(i1 + pairs, i2):
                changes.append({
                    "type":        "paragraph_deleted",
                    "change_kind": "delete",
                    "original":    serialize_node(a_paras[i]),
                    "modified":    None,
                })
            for j in range(j1 + pairs, j2):
                changes.append({
                    "type":        "paragraph_inserted",
                    "change_kind": "insert",
                    "original":    None,
                    "modified":    serialize_node(b_paras[j]),
                })

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Cell diff
# ══════════════════════════════════════════════════════════════════════════════

def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    from src.services.extractor.utils import norm_text as _norm

    changes: List[Dict[str, Any]] = []

    a_paras, a_imgs, a_tables = group_children_by_type(a)
    b_paras, b_imgs, b_tables = group_children_by_type(b)

    # ── Nested table → text ───────────────────────────────────────────────────
    if a_tables and not b_tables and b_paras:
        a_nested_text = " ".join(
            _norm(t.content.get("text_set", "") or t.content.get("text", ""))
            for t in a_tables
        )
        b_para_text = " ".join(
            _norm(p.content.get("text", "")) for p in b_paras
        )
        changes.append({
            "type":           "nested_table_to_text",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_nested_text,
            "new_text":       b_para_text,
            "original_table": serialize_node(a_tables[0]) if a_tables else None,
        })
        return changes

    # ── Text → nested table ───────────────────────────────────────────────────
    if b_tables and not a_tables and a_paras:
        a_para_text = " ".join(
            _norm(p.content.get("text", "")) for p in a_paras
        )
        b_nested_text = " ".join(
            _norm(t.content.get("text_set", "") or t.content.get("text", ""))
            for t in b_tables
        )
        changes.append({
            "type":           "text_to_nested_table",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_para_text,
            "new_text":       b_nested_text,
            "modified_table": serialize_node(b_tables[0]) if b_tables else None,
        })
        return changes

    # ── Paragraph diff — dùng SequenceMatcher ────────────────────────────────
    changes.extend(_diff_cell_paragraphs(a_paras, b_paras))

    # ── Image diff ────────────────────────────────────────────────────────────
    # FIX: emit build_image_equal cho ảnh unchanged
    # → frontend nhận image_url để render ảnh không đổi trong cell
    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None

        if ai is None and bi is not None:
            changes.append(build_image_change(None, bi))
        elif bi is None and ai is not None:
            changes.append(build_image_change(ai, None))
        elif ai is not None and bi is not None:
            if images_equal(ai, bi):
                changes.append(build_image_equal(ai, bi))   # ← thêm emit equal
            else:
                changes.append(build_image_change(ai, bi))

    # ── Nested table diff — đệ quy ────────────────────────────────────────────
    for i in range(max(len(a_tables), len(b_tables))):
        at = a_tables[i] if i < len(a_tables) else None
        bt = b_tables[i] if i < len(b_tables) else None

        if at is None and bt is not None:
            changes.append({
                "type":        "nested_table_inserted",
                "change_kind": "insert",
                "original":    None,
                "modified":    serialize_node(bt),
                "changes":     [],
            })
        elif bt is None and at is not None:
            changes.append({
                "type":        "nested_table_deleted",
                "change_kind": "delete",
                "original":    serialize_node(at),
                "modified":    None,
                "changes":     [],
            })
        elif at is not None and bt is not None:
            nested_changes = diff_table(at, bt)
            if nested_changes:
                changes.append({
                    "type":        "nested_table_modified",
                    "change_kind": "replace",
                    "original":    serialize_node(at),
                    "modified":    serialize_node(bt),
                    "changes":     nested_changes,
                })
            else:
                changes.append({
                    "type":        "nested_table_unchanged",
                    "change_kind": "equal",
                    "original":    serialize_node(at),
                    "modified":    serialize_node(bt),
                    "changes":     [],
                })

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Row diff — standard (col_index mapping)
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_row(
    changes:  List[Dict[str, Any]],
    ar:       DocNode,
    br:       DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> None:
    """
    Diff 2 row theo col_index — dùng khi structure giống nhau.
    Xử lý: colspan thay đổi, cell thêm/xóa, cell modified.
    """
    a_cells   = get_cells(ar)
    b_cells   = get_cells(br)
    col_count = get_col_count(b_tbl) or get_col_count(a_tbl)

    def build_col_map(cells: List[DocNode]) -> Dict[int, DocNode]:
        m: Dict[int, DocNode] = {}
        for cell in cells:
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            for k in range(cs):
                m[ci + k] = cell
        return m

    a_map = build_col_map(a_cells)
    b_map = build_col_map(b_cells)
    all_cols = sorted(set(a_map) | set(b_map))

    row_changed       = False
    row_cell_changes: List[Dict[str, Any]] = []

    for col in all_cols:
        ac = a_map.get(col)
        bc = b_map.get(col)

        ac_ci = int((ac.content or {}).get("col_index", 0) or 0) if ac is not None else col
        bc_ci = int((bc.content or {}).get("col_index", 0) or 0) if bc is not None else col

        ac_is_cont = (ac is not None and ac_ci != col)
        bc_is_cont = (bc is not None and bc_ci != col)

        if ac_is_cont and bc_is_cont:
            continue

        if bc_is_cont and not ac_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue

        if ac_is_cont and not bc_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue

        if ac is None and bc is not None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue

        if bc is None and ac is not None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue

        if ac is None or bc is None:
            continue

        a_cs = int((ac.content or {}).get("col_span", 1) or 1)
        b_cs = int((bc.content or {}).get("col_span", 1) or 1)

        if a_cs != b_cs:
            a_covered = sorted(
                {a_map[c] for c in range(col, col + b_cs) if c in a_map},
                key=lambda x: int((x.content or {}).get("col_index", 0) or 0),
            )
            a_combined = " ".join(cell_full_text(c) for c in a_covered if cell_full_text(c))
            b_text     = cell_full_text(bc)
            row_changed = True
            row_cell_changes.append({
                "type":           "table_cell_span_changed",
                "change_kind":    "replace",
                "col_index":      col,
                "left_cell":      serialize_cell(ac),
                "right_cell":     serialize_cell(bc),
                "left_text":      a_combined,
                "right_text":     b_text,
                "left_col_span":  a_cs,
                "right_col_span": b_cs,
                "left_cells":     [serialize_cell(c) for c in a_covered],
                "changes": [{
                    "type":          "paragraph_modified",
                    "old_full_text": a_combined,
                    "new_full_text": b_text,
                    "spans":         (diff_words(a_combined, b_text) or {}).get("spans", []),
                }],
            })
            continue

        cell_changes = _diff_cell(ac, bc)
        if cell_changes:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   col,
                "left_cell":   serialize_cell(ac),
                "right_cell":  serialize_cell(bc),
                "left_text":   cell_text(ac),
                "right_text":  cell_text(bc),
                "changes":     cell_changes,
            })

    if row_changed:
        changes.append({
            "type":        "table_row_modified",
            "change_kind": "replace",
            "row_index":   row_idx,
            "col_count":   col_count,
            "left_row":    serialize_row(ar),
            "right_row":   serialize_row(br),
            "left_cells":  [serialize_cell(c) for c in a_cells],
            "right_cells": [serialize_cell(c) for c in b_cells],
            "left_display_cells":  build_row_display_cells(a_tbl, ar),
            "right_display_cells": build_row_display_cells(b_tbl, br),
            "left_text":   row_text(ar),
            "right_text":  row_text(br),
            "cell_changes": row_cell_changes,
        })


# ══════════════════════════════════════════════════════════════════════════════
# Row diff — header-aware (fix thêm cột ở giữa — Nhóm 2)
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_row_with_header_map(
    changes:    List[Dict[str, Any]],
    ar:         DocNode,
    br:         DocNode,
    row_idx:    int,
    a_tbl:      DocNode,
    b_tbl:      DocNode,
    header_map: Dict[str, Any],
) -> None:
    """
    Diff 2 row theo header mapping thay vì col_index tuyệt đối.

    Dùng khi structure_changed=True nhưng header vẫn match được (Nhóm 2):
    - col_map:      {a_col_idx → b_col_idx} — pair đúng dù cột bị dịch chuyển
    - added_cols:   cột mới ở B → emit table_cell_added
    - deleted_cols: cột bị xóa ở A → emit table_cell_deleted
    """
    col_map      = header_map.get("col_map", {})
    added_cols   = set(header_map.get("added_cols", []))
    deleted_cols = set(header_map.get("deleted_cols", []))

    a_cells   = get_cells(ar)
    b_cells   = get_cells(br)
    col_count = get_col_count(b_tbl) or get_col_count(a_tbl)

    def build_col_map(cells: List[DocNode]) -> Dict[int, DocNode]:
        m: Dict[int, DocNode] = {}
        for cell in cells:
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            for k in range(cs):
                m[ci + k] = cell
        return m

    a_map = build_col_map(a_cells)
    b_map = build_col_map(b_cells)

    row_changed       = False
    row_cell_changes: List[Dict[str, Any]] = []

    for a_col, b_col in col_map.items():
        ac = a_map.get(a_col)
        bc = b_map.get(b_col)

        if ac is None and bc is None:
            continue

        if ac is None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": b_col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue

        if bc is None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": a_col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue

        cell_changes = _diff_cell(ac, bc)
        if cell_changes:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   b_col,
                "left_cell":   serialize_cell(ac),
                "right_cell":  serialize_cell(bc),
                "left_text":   cell_text(ac),
                "right_text":  cell_text(bc),
                "changes":     cell_changes,
            })

    for a_col in sorted(deleted_cols):
        ac = a_map.get(a_col)
        if ac is None:
            continue
        row_changed = True
        row_cell_changes.append({
            "type": "table_cell_deleted", "change_kind": "delete",
            "col_index": a_col, "left_cell": serialize_cell(ac),
            "right_cell": None, "left_text": cell_full_text(ac),
            "right_text": "", "changes": [],
        })

    for b_col in sorted(added_cols):
        bc = b_map.get(b_col)
        if bc is None:
            continue
        row_changed = True
        row_cell_changes.append({
            "type": "table_cell_added", "change_kind": "insert",
            "col_index": b_col, "left_cell": None,
            "right_cell": serialize_cell(bc),
            "left_text": "", "right_text": cell_full_text(bc), "changes": [],
        })

    if row_changed:
        changes.append({
            "type":        "table_row_modified",
            "change_kind": "replace",
            "row_index":   row_idx,
            "col_count":   col_count,
            "left_row":    serialize_row(ar),
            "right_row":   serialize_row(br),
            "left_cells":  [serialize_cell(c) for c in a_cells],
            "right_cells": [serialize_cell(c) for c in b_cells],
            "left_display_cells":  build_row_display_cells(a_tbl, ar),
            "right_display_cells": build_row_display_cells(b_tbl, br),
            "left_text":   row_text(ar),
            "right_text":  row_text(br),
            "cell_changes": row_cell_changes,
        })


# ══════════════════════════════════════════════════════════════════════════════
# Row merge detection
# ══════════════════════════════════════════════════════════════════════════════

def _rows_merged_into(
    a_rows:    List[DocNode],
    b_row:     DocNode,
    col_count: int,
) -> Optional[List[int]]:
    """
    Detect N rows cũ → 1 row mới (merge rows).

    Logic: text của a_rows phải xuất hiện trong b_row (via token matching).
    Cần ít nhất 2 rows để gọi là merge.
    """
    b_cell_texts = [cell_full_text(c) for c in get_cells(b_row)]
    b_full_text  = " ".join(t for t in b_cell_texts if t).lower()

    if not b_full_text:
        return None

    b_tokens: Set[str] = set()
    for raw in re.split(r"[,;\n]+", b_full_text):
        from src.services.extractor.utils import norm_text as _norm
        tok = _norm(raw)
        if tok:
            b_tokens.add(tok)

    merged_indices: List[int] = []

    for idx, a_row in enumerate(a_rows):
        a_texts = row_cell_texts(a_row)
        if not a_texts:
            continue

        from src.services.extractor.utils import norm_text as _norm
        all_found = all(
            t.lower() in b_tokens or t.lower() in b_full_text
            for t in a_texts
            if t
        )
        if all_found:
            merged_indices.append(idx)

    return merged_indices if len(merged_indices) >= 2 else None


def _try_emit_merge(
    changes:  List[Dict[str, Any]],
    a_slice:  List[DocNode],
    b_row:    DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> Optional[Set[int]]:
    """
    Thử detect và emit table_row_merged.

    Trả về set index (trong a_slice) đã consumed, hoặc None nếu không phải merge.
    """
    col_count   = get_col_count(b_tbl)
    merged_idxs = _rows_merged_into(a_slice, b_row, col_count)

    if merged_idxs is None:
        return None

    merged_a_rows = [a_slice[i] for i in merged_idxs]

    a_combined_text = ", ".join(
        t for r in merged_a_rows for t in row_cell_texts(r) if t
    )
    b_cells    = get_cells(b_row)
    b_combined = " ".join(cell_full_text(c) for c in b_cells if cell_full_text(c))

    cell_changes: List[Dict[str, Any]] = []

    for ci, bc in enumerate(b_cells):
        bc_text  = cell_full_text(bc)
        if not bc_text:
            continue

        r_col = real_col_index(bc, ci)
        a_col_texts = [
            cell_full_text(ac)
            for ar in merged_a_rows
            for ac in get_cells(ar)
            if real_col_index(ac, -1) == r_col and cell_full_text(ac)
        ]

        if not a_col_texts:
            cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": r_col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": bc_text, "changes": [],
            })
        else:
            a_joined = ", ".join(a_col_texts)
            if a_joined != bc_text:
                cell_changes.append({
                    "type":       "table_cell_merged",
                    "change_kind": "replace",
                    "col_index":  r_col,
                    "left_cell":  serialize_cell(next(
                        (ac for ar in merged_a_rows for ac in get_cells(ar)
                         if real_col_index(ac, -1) == r_col), None
                    )),
                    "right_cell": serialize_cell(bc),
                    "left_text":  a_joined,
                    "right_text": bc_text,
                    "word_diff":  diff_words(a_joined, bc_text),
                    "changes":    [],
                })

    changes.append({
        "type":               "table_row_merged",
        "change_kind":        "replace",
        "row_index":          row_idx,
        "col_count":          col_count,
        "merged_from_rows":   [serialize_row(r) for r in merged_a_rows],
        "merged_from_count":  len(merged_a_rows),
        "left_row":           serialize_row(merged_a_rows[0]) if merged_a_rows else None,
        "right_row":          serialize_row(b_row),
        "left_cells":         [serialize_cell(c) for r in merged_a_rows for c in get_cells(r)],
        "right_cells":        [serialize_cell(c) for c in b_cells],
        "left_display_cells": build_row_display_cells(a_tbl, merged_a_rows[0]),
        "right_display_cells": build_row_display_cells(b_tbl, b_row),
        "left_text":          a_combined_text,
        "right_text":         b_combined,
        "cell_changes":       cell_changes,
    })

    return set(merged_idxs)


# ══════════════════════════════════════════════════════════════════════════════
# Main diff_table
# ══════════════════════════════════════════════════════════════════════════════

def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh 2 table node, trả về list changes.

    Luồng:
    1. SequenceMatcher trên row signature → align row đúng
    2. Với mỗi replace opcode:
       - n_a > n_b → thử merge detection trước
       - n_a <= n_b → inner SequenceMatcher
    3. Nếu structure_changed và header match được → dùng header-aware diff
       cho từng row pair (fix bug thêm cột ở giữa)
    """
    from src.services.diff.table.table_helpers import detect_structure_change

    changes: List[Dict[str, Any]] = []

    a_rows = get_rows(a_tbl)
    b_rows = get_rows(b_tbl)

    if not a_rows and not b_rows:
        return changes

    structure_changed = detect_structure_change(a_tbl, b_tbl)
    header_map: Optional[Dict[str, Any]] = None
    use_header_diff = False

    if structure_changed:
        header_map = resolve_header_map(a_tbl, b_tbl)
        use_header_diff = (
            header_map.get("has_header", False)
            and len(header_map.get("col_map", {})) > 0
        )

    a_sigs = [_row_sig(r) for r in a_rows]
    b_sigs = [_row_sig(r) for r in b_rows]

    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():

        if tag == "equal":
            continue

        if tag == "insert":
            for jr in range(j1, j2):
                br      = b_rows[jr]
                b_cells = get_cells(br)
                changes.append({
                    "type":        "table_row_added",
                    "change_kind": "insert",
                    "row_index":   jr,
                    "col_count":   get_col_count(b_tbl),
                    "left_row":    None,
                    "right_row":   serialize_row(br),
                    "left_cells":  [],
                    "right_cells": [serialize_cell(c) for c in b_cells],
                    "right_display_cells": build_row_display_cells(b_tbl, br),
                    "left_text":   "",
                    "right_text":  row_text(br),
                    "cell_changes": [],
                })
            continue

        if tag == "delete":
            for ir in range(i1, i2):
                ar      = a_rows[ir]
                a_cells = get_cells(ar)
                changes.append({
                    "type":        "table_row_deleted",
                    "change_kind": "delete",
                    "row_index":   ir,
                    "col_count":   get_col_count(a_tbl),
                    "left_row":    serialize_row(ar),
                    "right_row":   None,
                    "left_cells":  [serialize_cell(c) for c in a_cells],
                    "right_cells": [],
                    "left_display_cells": build_row_display_cells(a_tbl, ar),
                    "left_text":   row_text(ar),
                    "right_text":  "",
                    "cell_changes": [],
                })
            continue

        if tag == "replace":
            a_slice = a_rows[i1:i2]
            b_slice = b_rows[j1:j2]
            n_a     = len(a_slice)
            n_b     = len(b_slice)

            def _do_diff_row(ar, br, ridx):
                if use_header_diff:
                    _diff_one_row_with_header_map(
                        changes, ar, br, ridx, a_tbl, b_tbl, header_map
                    )
                else:
                    _diff_one_row(changes, ar, br, ridx, a_tbl, b_tbl)

            if n_a > n_b:
                consumed_a: Set[int] = set()

                for k, br in enumerate(b_slice):
                    remaining_a = [a_slice[i] for i in range(n_a) if i not in consumed_a]
                    consumed = None

                    if len(remaining_a) >= 2:
                        consumed = _try_emit_merge(
                            changes=changes, a_slice=remaining_a,
                            b_row=br, row_idx=j1 + k, a_tbl=a_tbl, b_tbl=b_tbl,
                        )

                    if consumed is not None:
                        remaining_indices = [i for i in range(n_a) if i not in consumed_a]
                        for ci in consumed:
                            consumed_a.add(remaining_indices[ci])
                    else:
                        first_avail = next(
                            (i for i in range(n_a) if i not in consumed_a), None
                        )
                        if first_avail is not None:
                            _do_diff_row(a_slice[first_avail], br, i1 + first_avail)
                            consumed_a.add(first_avail)

                for i in range(n_a):
                    if i not in consumed_a:
                        ar      = a_slice[i]
                        a_cells = get_cells(ar)
                        changes.append({
                            "type":        "table_row_deleted",
                            "change_kind": "delete",
                            "row_index":   i1 + i,
                            "col_count":   get_col_count(a_tbl),
                            "left_row":    serialize_row(ar),
                            "right_row":   None,
                            "left_cells":  [serialize_cell(c) for c in a_cells],
                            "right_cells": [],
                            "left_display_cells": build_row_display_cells(a_tbl, ar),
                            "left_text":   row_text(ar),
                            "right_text":  "",
                            "cell_changes": [],
                        })

            else:
                inner_a_sigs = [_row_sig(r) for r in a_slice]
                inner_b_sigs = [_row_sig(r) for r in b_slice]

                inner_sm = difflib.SequenceMatcher(
                    a=inner_a_sigs, b=inner_b_sigs, autojunk=False
                )

                for inner_tag, ia1, ia2, ib1, ib2 in inner_sm.get_opcodes():
                    if inner_tag == "equal":
                        continue

                    if inner_tag == "insert":
                        for jj in range(ib1, ib2):
                            br      = b_slice[jj]
                            b_cells = get_cells(br)
                            changes.append({
                                "type":        "table_row_added",
                                "change_kind": "insert",
                                "row_index":   j1 + jj,
                                "col_count":   get_col_count(b_tbl),
                                "left_row":    None,
                                "right_row":   serialize_row(br),
                                "left_cells":  [],
                                "right_cells": [serialize_cell(c) for c in b_cells],
                                "right_display_cells": build_row_display_cells(b_tbl, br),
                                "left_text":   "",
                                "right_text":  row_text(br),
                                "cell_changes": [],
                            })

                    elif inner_tag == "delete":
                        for ii in range(ia1, ia2):
                            ar      = a_slice[ii]
                            a_cells = get_cells(ar)
                            changes.append({
                                "type":        "table_row_deleted",
                                "change_kind": "delete",
                                "row_index":   i1 + ii,
                                "col_count":   get_col_count(a_tbl),
                                "left_row":    serialize_row(ar),
                                "right_row":   None,
                                "left_cells":  [serialize_cell(c) for c in a_cells],
                                "right_cells": [],
                                "left_display_cells": build_row_display_cells(a_tbl, ar),
                                "left_text":   row_text(ar),
                                "right_text":  "",
                                "cell_changes": [],
                            })

                    elif inner_tag == "replace":
                        inner_pairs = min(ia2 - ia1, ib2 - ib1)
                        for k in range(inner_pairs):
                            _do_diff_row(
                                a_slice[ia1 + k], b_slice[ib1 + k], i1 + ia1 + k
                            )

                        for ii in range(ia1 + inner_pairs, ia2):
                            ar      = a_slice[ii]
                            a_cells = get_cells(ar)
                            changes.append({
                                "type":        "table_row_deleted",
                                "change_kind": "delete",
                                "row_index":   i1 + ii,
                                "col_count":   get_col_count(a_tbl),
                                "left_row":    serialize_row(ar),
                                "right_row":   None,
                                "left_cells":  [serialize_cell(c) for c in a_cells],
                                "right_cells": [],
                                "left_display_cells": build_row_display_cells(a_tbl, ar),
                                "left_text":   row_text(ar),
                                "right_text":  "",
                                "cell_changes": [],
                            })

                        for jj in range(ib1 + inner_pairs, ib2):
                            br      = b_slice[jj]
                            b_cells = get_cells(br)
                            changes.append({
                                "type":        "table_row_added",
                                "change_kind": "insert",
                                "row_index":   j1 + jj,
                                "col_count":   get_col_count(b_tbl),
                                "left_row":    None,
                                "right_row":   serialize_row(br),
                                "left_cells":  [],
                                "right_cells": [serialize_cell(c) for c in b_cells],
                                "right_display_cells": build_row_display_cells(b_tbl, br),
                                "left_text":   "",
                                "right_text":  row_text(br),
                                "cell_changes": [],
                            })

    return changes