# src/services/diff/table_helpers.py
"""
Utility thuần cho table diff — tree helpers, text extraction, structure detection.

Không chứa logic diff hay serialize.
Import bởi: table_serialize.py, table_diff.py, table_analyze.py
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
import hashlib
from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm, norm_for_diff


# ══════════════════════════════════════════════════════════════════════════════
# Tree traversal
# ══════════════════════════════════════════════════════════════════════════════

def get_rows(tbl: DocNode) -> List[DocNode]:
    return [c for c in (tbl.children or []) if c.type == "row"]


def get_cells(row: DocNode) -> List[DocNode]:
    return [c for c in (row.children or []) if c.type == "cell"]


def get_col_count(tbl: DocNode) -> int:
    """
    Lấy số cột logic của table.
    Ưu tiên col_count từ content, fallback tính từ cell col_index + col_span.
    """
    cc = int((tbl.content or {}).get("col_count", 0) or 0)
    if cc > 0:
        return cc

    mx = 0
    for r in get_rows(tbl):
        for c in get_cells(r):
            ci = int((c.content or {}).get("col_index", 0) or 0)
            cs = int((c.content or {}).get("col_span", 1) or 1)
            mx = max(mx, ci + cs)
    if mx > 0:
        return mx

    rows = get_rows(tbl)
    return len(get_cells(rows[0])) if rows else 0


def real_col_index(cell: Optional[DocNode], fallback: int) -> int:
    """
    Lấy col_index thật từ content.
    Tránh lệch khi có merged/spanning cells.
    """
    if cell is None:
        return fallback
    return int((cell.content or {}).get("col_index") or fallback)


def has_nested_table(tbl: DocNode) -> bool:
    """Kiểm tra bảng có chứa nested table không."""
    for row in get_rows(tbl):
        for cell in get_cells(row):
            for child in (cell.children or []):
                if child.type == "table":
                    return True
    return False


def group_children_by_type(
    node: DocNode,
) -> Tuple[List[DocNode], List[DocNode], List[DocNode]]:
    """
    Tách children của node thành 3 nhóm: paragraphs, images, tables.
    Dùng trong _diff_cell để xử lý từng loại riêng.
    """
    paragraphs: List[DocNode] = []
    images:     List[DocNode] = []
    tables:     List[DocNode] = []
    for c in (node.children or []):
        if c.type == "paragraph":
            paragraphs.append(c)
        elif c.type == "image":
            images.append(c)
        elif c.type == "table":
            tables.append(c)
    return paragraphs, images, tables


# ══════════════════════════════════════════════════════════════════════════════
# Text extraction
# ══════════════════════════════════════════════════════════════════════════════

def cell_text(cell: Optional[DocNode]) -> str:
    """Text normalize của cell — dùng để hiển thị."""
    if not cell:
        return ""
    return norm_for_diff(cell.content.get("text", ""))


def cell_full_text(cell: Optional[DocNode]) -> str:
    """
    Text đầy đủ của cell — ưu tiên content.text, fallback về paragraph children.
    Dùng khi cell chỉ có paragraph children, không có direct text.
    """
    if not cell:
        return ""
    direct = norm_for_diff(cell.content.get("text", ""))
    if direct:
        return direct
    parts = []
    for child in (cell.children or []):
        if child.type == "paragraph":
            t = norm_for_diff(child.content.get("text", ""))
            if t:
                parts.append(t)
    return " ".join(parts)


def row_text(row: Optional[DocNode]) -> str:
    if not row:
        return ""
    return _norm(row.content.get("text", ""))


def row_cell_texts(row: DocNode) -> List[str]:
    """
    List text non-empty của các cell trong row.
    Dùng trong merge detection.
    """
    return [t for t in (cell_full_text(c) for c in get_cells(row)) if t]


# table_helpers.py
def row_content_hash(row: DocNode) -> str:
    texts = [cell_full_text(c) for c in get_cells(row)]
    combined = " | ".join(texts)
    meaningful = [t for t in texts if len(t) > 3]
    # Row đơn giản: thêm row_index để tránh collision
    if len(meaningful) < 2:
        ri = (row.content or {}).get("row_index", 0)
        combined = f"__pos{ri}__" + combined
    return hashlib.md5(combined.encode("utf-8")).hexdigest()

# ══════════════════════════════════════════════════════════════════════════════
# Structure detection
# ══════════════════════════════════════════════════════════════════════════════

def detect_structure_change(a_tbl: DocNode, b_tbl: DocNode) -> bool:
    """
    Kiểm tra 2 bảng có khác structure không.

    Trả False nếu:
    - text_set giống nhau (cùng data, khác layout — block ngang)
    - 1 trong 2 có nested table (col_count bị expand do nested, không phải thay đổi thật)

    Trả True nếu col_count khác nhau thật sự.
    """
    a_cols = int((a_tbl.content or {}).get("col_count", 0) or 0)
    b_cols = int((b_tbl.content or {}).get("col_count", 0) or 0)

    if a_cols > 0 and b_cols > 0 and a_cols != b_cols:
        # Cùng text_set → khác layout nhưng không khác data
        a_set = _norm(a_tbl.content.get("text_set", "") or "")
        b_set = _norm(b_tbl.content.get("text_set", "") or "")
        if a_set and b_set and a_set == b_set:
            return False

        # Có nested table → col_count không đáng tin
        if has_nested_table(a_tbl) or has_nested_table(b_tbl):
            return False

        return True

    # Fallback: so sánh số cell thực tế trong row
    a_rows = get_rows(a_tbl)
    b_rows = get_rows(b_tbl)
    if a_rows and b_rows:
        a_max = max((len(get_cells(r)) for r in a_rows), default=0)
        b_max = max((len(get_cells(r)) for r in b_rows), default=0)
        if a_max != b_max:
            return True

    return False


def detect_repeating_block_layout(tbl: DocNode) -> Optional[int]:
    """
    Detect bảng dạng block ngang lặp lại (No | Chủng loại | Mã SP | No | Chủng loại | Mã SP...).

    Trả về số cột của 1 block nếu detect được, None nếu không phải dạng này.

    Logic:
    - Lấy header row (row đầu tiên)
    - Kiểm tra header text có lặp lại theo chu kỳ không
    - col_count phải là bội số của block_size
    """
    rows = get_rows(tbl)
    if not rows:
        return None

    header_cells = get_cells(rows[0])
    if len(header_cells) < 2:
        return None

    header_texts = [_norm(cell_full_text(c)) for c in header_cells]
    n = len(header_texts)

    # Thử từng block_size từ 1 đến n//2
    for block_size in range(1, n // 2 + 1):
        if n % block_size != 0:
            continue
        pattern = header_texts[:block_size]
        # Kiểm tra pattern lặp lại
        matches = all(
            header_texts[i] == pattern[i % block_size]
            for i in range(n)
        )
        if matches:
            return block_size

    return None


def flatten_block_layout(tbl: DocNode, block_size: int) -> List[List[str]]:
    """
    Flatten bảng block ngang thành list rows 1 chiều.

    Ví dụ bảng 6 cột (block_size=3):
    | 1 | OT4J | RHE4AL1000 | 31 | OT4P | RHEBB24110 |
    → [["1", "OT4J", "RHE4AL1000"], ["31", "OT4P", "RHEBB24110"]]

    Trả về list of [cell_text per block_size cols].
    """
    rows = get_rows(tbl)
    result: List[List[str]] = []

    for row in rows[1:]:  # bỏ header row
        cells = get_cells(row)
        texts = [cell_full_text(c) for c in cells]
        # Chia thành từng block
        for start in range(0, len(texts), block_size):
            block = texts[start:start + block_size]
            # Bỏ block toàn rỗng (padding cuối bảng)
            if any(t for t in block):
                result.append(block)

    return result


# ══════════════════════════════════════════════════════════════════════════════
# Header resolution — dùng cho header-aware diff (Nhóm 2)
# ══════════════════════════════════════════════════════════════════════════════

def resolve_header_map(
    a_tbl: DocNode,
    b_tbl: DocNode,
    fuzzy_threshold: float = 0.6,
) -> Dict[str, Any]:
    """
    Align header của 2 bảng để map col_index_A → col_index_B.

    Trả về dict:
    {
        "col_map":      {a_col_idx: b_col_idx},   # matched cols
        "added_cols":   [b_col_idx, ...],          # cột mới ở B
        "deleted_cols": [a_col_idx, ...],          # cột bị xóa ở A
        "has_header":   bool,                      # có detect được header không
    }

    Dùng khi structure_changed=True nhưng vẫn muốn diff từng cell.
    """
    import difflib

    a_rows = get_rows(a_tbl)
    b_rows = get_rows(b_tbl)

    if not a_rows or not b_rows:
        return {"col_map": {}, "added_cols": [], "deleted_cols": [], "has_header": False}

    # Lấy header text theo col_index
    def _header_texts(rows: List[DocNode]) -> Dict[int, str]:
        result = {}
        for cell in get_cells(rows[0]):
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            text = _norm(cell_full_text(cell))
            for k in range(cs):
                result[ci + k] = text
        return result

    a_headers = _header_texts(a_rows)
    b_headers = _header_texts(b_rows)

    if not a_headers or not b_headers:
        return {"col_map": {}, "added_cols": [], "deleted_cols": [], "has_header": False}

    # Fuzzy match từng header A → header B
    # Nếu header ngắn < 4 ký tự → dùng threshold cao hơn để tránh match nhầm
    matched_a: set = set()
    matched_b: set = set()
    col_map: Dict[int, int] = {}

    # Sắp xếp: match exact trước, fuzzy sau
    candidates = []
    for a_col, a_text in a_headers.items():
        for b_col, b_text in b_headers.items():
            if not a_text and not b_text:
                ratio = 1.0
            elif not a_text or not b_text:
                ratio = 0.0
            else:
                ratio = difflib.SequenceMatcher(
                    a=a_text, b=b_text, autojunk=False
                ).ratio()
                # Tăng threshold cho header ngắn
                min_len = min(len(a_text), len(b_text))
                effective_threshold = 0.85 if min_len < 4 else fuzzy_threshold
                if ratio < effective_threshold:
                    continue
            candidates.append((-ratio, a_col, b_col))

    candidates.sort()
    for _, a_col, b_col in candidates:
        if a_col in matched_a or b_col in matched_b:
            continue
        col_map[a_col] = b_col
        matched_a.add(a_col)
        matched_b.add(b_col)

    added_cols   = [b_col for b_col in b_headers if b_col not in matched_b]
    deleted_cols = [a_col for a_col in a_headers if a_col not in matched_a]

    return {
        "col_map":      col_map,
        "added_cols":   sorted(added_cols),
        "deleted_cols": sorted(deleted_cols),
        "has_header":   True,
    }


def match_rows_by_content(
    a_rows: List[DocNode],
    b_rows: List[DocNode],
) -> Dict[str, Any]:
    """
    Match rows giữa 2 bảng theo content hash — dùng cho Nhóm 3 (layout thay đổi hoàn toàn).

    Trả về:
    {
        "a_states": {row_idx: "unchanged"|"deleted"},
        "b_states": {row_idx: "unchanged"|"added"},
    }

    Thuật toán:
    1. Hash text tổng hợp của từng row
    2. SequenceMatcher trên list hash
    3. equal → unchanged, delete → deleted, insert → added

    Lưu ý: row có nhiều cell trùng text (dòng "-") có thể match sai.
    Weight: row có content phong phú hơn được ưu tiên match trước.
    """
    import difflib

    a_hashes = [row_content_hash(r) for r in a_rows]
    b_hashes = [row_content_hash(r) for r in b_rows]

    sm = difflib.SequenceMatcher(a=a_hashes, b=b_hashes, autojunk=False)

    a_states: Dict[int, str] = {}
    b_states: Dict[int, str] = {}

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                a_states[i1 + k] = "unchanged"
                b_states[j1 + k] = "unchanged"
        elif tag == "delete":
            for i in range(i1, i2):
                a_states[i] = "deleted"
        elif tag == "insert":
            for j in range(j1, j2):
                b_states[j] = "added"
        elif tag == "replace":
            for i in range(i1, i2):
                a_states[i] = "deleted"
            for j in range(j1, j2):
                b_states[j] = "added"

    return {"a_states": a_states, "b_states": b_states}