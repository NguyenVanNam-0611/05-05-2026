# src/services/diff/table_analyze.py
"""
Phân tích kết quả diff_table → chọn render mode và filter noise.

Chịu trách nhiệm:
- analyze_table_change   — entry point cho json_builder
- _is_span_only_change   — filter false positive do title row gridSpan
- _is_text_only_layout_change — filter thay đổi layout thuần, text không đổi
- _collect_row_all_text  — gom text từ 1 side của row change

Không chứa logic diff. Import từ table_helpers và table_serialize.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm
from src.services.diff.table.table_helpers import (
    detect_structure_change,
    match_rows_by_content,
    get_rows,
    get_cells,
)
from src.services.diff.table.table_serialize import (
    serialize_full_table,
    serialize_row,
    serialize_cell,
    get_header_row,
)
from collections import Counter



# ══════════════════════════════════════════════════════════════════════════════
# Render mode constants
# ══════════════════════════════════════════════════════════════════════════════

TABLE_RENDER_FULL         = "full_table"
TABLE_RENDER_ROW_ADDED    = "row_added"
TABLE_RENDER_ROW_DELETED  = "row_deleted"
TABLE_RENDER_DELETED      = "table_deleted"
TABLE_RENDER_ROW_MODIFIED = "row_modified"
TABLE_RENDER_ROW_MERGED   = "row_merged"


# ══════════════════════════════════════════════════════════════════════════════
# Noise filters
# ══════════════════════════════════════════════════════════════════════════════

def _is_span_only_change(change: Dict[str, Any]) -> bool:
    """
    Trả True nếu row_modified chỉ khác col_span nhưng text giống nhau.
    False positive do title row làm lệch gridSpan XML.
    """
    if change.get("type") != "table_row_modified":
        return False
    cell_changes = change.get("cell_changes", [])
    if not cell_changes:
        return False
    for cc in cell_changes:
        if cc.get("type") != "table_cell_span_changed":
            return False
        if _norm(cc.get("left_text", "")) != _norm(cc.get("right_text", "")):
            return False
    return True


def _collect_row_all_text(change: Dict[str, Any], side: str) -> str:
    """
    Gom toàn bộ text của 1 side (left/right) trong 1 row change.
    Ưu tiên {side}_cells, fallback về {side}_text.
    """
    cells = change.get(f"{side}_cells") or []
    if cells:
        parts = [_norm(c.get("text", "") or "") for c in cells if c]
        return " ".join(p for p in parts if p)
    return _norm(change.get(f"{side}_text", "") or "")


def _is_text_only_layout_change(change: Dict[str, Any]) -> bool:
    """
    Trả True nếu change chỉ là layout/span thay đổi nhưng tổng text không đổi.

    Áp dụng cho table_row_modified và table_row_merged.
    Không áp dụng cho added/deleted vì không có cả 2 side để so sánh.

    Không filter nếu có nested_table_to_text / text_to_nested_table
    vì đây là structural change có ý nghĩa dù text có thể giống nhau.
    """
    change_type = change.get("type", "")

    if change_type == "table_row_modified":
        for cc in (change.get("cell_changes") or []):
            if cc.get("type") in ("nested_table_to_text", "text_to_nested_table"):
                return False
        left_text  = _collect_row_all_text(change, "left")
        right_text = _collect_row_all_text(change, "right")
        return left_text == right_text

    if change_type == "table_row_merged":
        # Cũ: dùng set → bỏ sót duplicate
        left_list = []
        for row in (change.get("merged_from_rows") or []):
            for cell in (row.get("cells") or []):
                t = _norm(cell.get("text", "") or "")
                if t:
                    left_list.append(t)

        right_list = []
        for cell in (change.get("right_cells") or []):
            t = _norm(cell.get("text", "") or "")
            if t:
                right_list.append(t)

        return Counter(left_list) == Counter(right_list)

    return False


# ══════════════════════════════════════════════════════════════════════════════
# Main analyzer
# ══════════════════════════════════════════════════════════════════════════════

def analyze_table_change(
    a_tbl:         Optional[DocNode],
    b_tbl:         Optional[DocNode],
    table_changes: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """
    Entry point cho json_builder — phân tích kết quả diff_table và chọn render mode.

    Render modes:
    - table_deleted   : bảng A bị xóa hoàn toàn
    - full_table      : bảng mới hoàn toàn, hoặc structure changed + no meaningful changes
    - row_modified    : có thay đổi cụ thể ở row/cell level

    Với structure changed + có meaningful changes:
    → vẫn trả row_modified, kèm full_table_original/modified để frontend có thể render cả 2 mode.
    → thêm row_states từ match_rows_by_content để frontend highlight row added/deleted
      trên full table view (Nhóm 3 fallback).
    """

    # ── Bảng bị xóa hoàn toàn ─────────────────────────────────────────────────
    if a_tbl is not None and b_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_DELETED,
            "structure_changed":   False,
            "full_table_original": serialize_full_table(a_tbl),
            "full_table_modified": None,
            "header_row":          get_header_row(a_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    # ── Bảng mới hoàn toàn ────────────────────────────────────────────────────
    if b_tbl is not None and a_tbl is None:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   False,
            "full_table_original": None,
            "full_table_modified": serialize_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    assert a_tbl is not None and b_tbl is not None

    structure_changed = detect_structure_change(a_tbl, b_tbl)

    # ── Filter noise ───────────────────────────────────────────────────────────
    meaningful_changes = [c for c in table_changes if not _is_span_only_change(c)]
    meaningful_changes = [c for c in meaningful_changes if not _is_text_only_layout_change(c)]

    # Dedup theo (type, row_index)
    seen: set = set()
    deduped: List[Dict[str, Any]] = []
    for c in meaningful_changes:
        ri  = c.get("row_index")
        ct  = c.get("type", "")
        key = (ct, ri) if ri is not None else id(c)
        if key not in seen:
            seen.add(key)
            deduped.append(c)
    meaningful_changes = deduped

    # ── Structure changed nhưng không có meaningful changes ────────────────────
    if structure_changed and not meaningful_changes:
        return {
            "render_mode":         TABLE_RENDER_FULL,
            "structure_changed":   True,
            "full_table_original": serialize_full_table(a_tbl),
            "full_table_modified": serialize_full_table(b_tbl),
            "header_row":          get_header_row(b_tbl),
            "added_rows":          [],
            "deleted_rows":        [],
            "table_changes":       [],
        }

    # ── Không có thay đổi thật sự ─────────────────────────────────────────────
    if not meaningful_changes:
        return None

    # ── Có meaningful changes ──────────────────────────────────────────────────
    added_rows   = [c for c in meaningful_changes if c.get("type") == "table_row_added"]
    deleted_rows = [c for c in meaningful_changes if c.get("type") == "table_row_deleted"]
    merged_rows  = [c for c in meaningful_changes if c.get("type") == "table_row_merged"]

    result = {
        "render_mode":         TABLE_RENDER_ROW_MODIFIED,
        "structure_changed":   structure_changed,
        "full_table_original": serialize_full_table(a_tbl),
        "full_table_modified": serialize_full_table(b_tbl),
        "header_row":          get_header_row(b_tbl),
        "added_rows":          added_rows,
        "deleted_rows":        deleted_rows,
        "merged_rows":         merged_rows,
        "table_changes":       meaningful_changes,
    }

    # ── Nhóm 3: kèm row_states để frontend highlight trên full table view ──────
    # Chỉ compute khi structure_changed — tốn CPU nên không làm mặc định
    if structure_changed:
        a_rows = get_rows(a_tbl)
        b_rows = get_rows(b_tbl)
        row_states = match_rows_by_content(a_rows, b_rows)
        result["row_states"] = row_states

    return result