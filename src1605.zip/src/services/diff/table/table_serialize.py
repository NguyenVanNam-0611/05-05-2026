# src/services/diff/table_serialize.py
"""
Serialize DocNode table/row/cell/node → dict để trả về frontend.

Chịu trách nhiệm:
- _serialize_node     — generic node → dict
- _serialize_cell     — cell với bubble images, children
- _serialize_row      — row với danh sách cell đã serialize
- _serialize_full_table — full table với all_cells grid
- build_row_display_cells — flatten row có rowspan/colspan về grid hiển thị
- get_header_row      — lấy row đầu tiên đã serialize

Import bởi: table_diff.py, table_analyze.py

Thay đổi:
- serialize_node: dùng image_url thay data_uri, không expose raw_bytes
- serialize_cell: bubble image_url thay data_uri vào images[]
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm
from src.services.diff.table.table_helpers import get_rows, get_cells, get_col_count


# ══════════════════════════════════════════════════════════════════════════════
# Node serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None

    content = node.content or {}

    # Loại raw_bytes và image_url khỏi content dump để không leak vào JSON
    # raw_bytes là bytes object — không serialize được và rất nặng
    # image_url được bubble lên top-level riêng bên dưới
    safe_content = {
        k: v for k, v in content.items()
        if k not in ("raw_bytes", "data_uri")
    }

    out = {
        "uid":      getattr(node, "uid", None),
        "type":     node.type,
        "content":  safe_content,
        "children": [serialize_node(c) for c in (node.children or [])],
    }

    if out["type"] == "image":
        # Bubble image_url và metadata lên top-level để JS truy cập trực tiếp
        # Frontend dùng <img src={image_url}> — browser tự cache theo URL
        # KHÔNG expose raw_bytes hay data_uri
        out["image_url"] = content.get("image_url")
        out["image"] = {
            "image_url":  content.get("image_url"),
            "width_px":   round(content.get("width_emu", 0) * 96 / 914400) or None,
            "height_px":  round(content.get("height_emu", 0) * 96 / 914400) or None,
            "mime":       content.get("mime"),
            "sha256":     content.get("sha256"),
            "floating":   content.get("floating", False),
        }

    return out


# ══════════════════════════════════════════════════════════════════════════════
# Cell serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_cell(cell: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if cell is None:
        return None
    content = cell.content or {}

    serialized_children = [serialize_node(c) for c in (cell.children or [])]

    # Collect image_url của tất cả ảnh trong cell:
    # - image direct child của cell
    # - image trong paragraph con của cell
    # → bubble lên "images" để JS đọc mà không cần đệ quy
    image_urls: List[str] = []
    for ch in (cell.children or []):
        if ch.type == "image":
            url = (ch.content or {}).get("image_url")
            if url:
                image_urls.append(url)
        elif ch.type == "paragraph":
            for gch in (ch.children or []):
                if gch.type == "image":
                    url = (gch.content or {}).get("image_url")
                    if url:
                        image_urls.append(url)

    return {
        "uid":          getattr(cell, "uid", None),
        "type":         "cell",
        "text":         _norm(content.get("text", "")),
        "text_display": content.get("text_display", "") or _norm(content.get("text", "")),
        "row_index":    content.get("row_index"),
        "col_index":    content.get("col_index"),
        "row_span":     content.get("row_span", 1),
        "col_span":     content.get("col_span", 1),
        "is_merged":    content.get("is_merged", False),
        "image_count":  content.get("image_count", 0),
        "images":       image_urls,
        "children":     serialized_children,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Row serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_row(row: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    cells = [c for c in (row.children or []) if c.type == "cell"]
    return {
        "uid":       getattr(row, "uid", None),
        "type":      "row",
        "row_index": (row.content or {}).get("row_index"),
        "text":      (row.content or {}).get("text", ""),
        "cells":     [serialize_cell(c) for c in cells],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Table serializer
# ══════════════════════════════════════════════════════════════════════════════

def serialize_full_table(tbl: DocNode) -> Dict[str, Any]:
    rows = get_rows(tbl)
    return {
        "uid":      getattr(tbl, "uid", None),
        "type":     "table",
        "content":  tbl.content or {},
        "rows":     [serialize_row(r) for r in rows],
        "all_cells": [
            [serialize_cell(c) for c in get_cells(r)]
            for r in rows
        ],
    }


def get_header_row(tbl: DocNode) -> Optional[Dict[str, Any]]:
    rows = get_rows(tbl)
    return serialize_row(rows[0]) if rows else None


# ══════════════════════════════════════════════════════════════════════════════
# Display cells builder — flatten rowspan/colspan về grid hiển thị
# ══════════════════════════════════════════════════════════════════════════════

def build_row_display_cells(
    tbl: DocNode,
    target_row: DocNode,
) -> List[Optional[Dict[str, Any]]]:
    """
    Trả về grid display cells của target_row trong context của toàn bảng.

    Xử lý rowspan: cell từ row trên span xuống row này → render virtual cell.
    Xử lý colspan: các col bị span → render cell_span_continuation.

    Dùng id(target_row) thay vì row_index vì nhiều row có thể cùng row_index
    (edge case với bảng bị parse lại), id() đảm bảo đúng object.
    """
    rows      = get_rows(tbl)
    col_count = get_col_count(tbl)
    if col_count == 0:
        return [serialize_cell(c) for c in get_cells(target_row)]

    target_id = id(target_row)
    active: List[Optional[Dict[str, Any]]] = [None] * col_count

    def _virtual_from_master(master_ser: Dict, current_row_index: int) -> Dict:
        v = dict(master_ser)
        v["virtual_from_merge"] = True
        v["row_span"]  = 1
        v["row_index"] = current_row_index
        return v

    for r in rows:
        ri        = int((r.content or {}).get("row_index", -1) or -1)
        is_target = (id(r) == target_id)

        # Build grid cho row này — bắt đầu từ active (rowspan từ row trên)
        grid: List[Optional[Dict[str, Any]]] = [None] * col_count

        for col in range(col_count):
            info = active[col]
            if not info or info["start_col"] != col:
                continue
            master = info["master_ser"]
            cs     = int(info.get("col_span", 1) or 1)
            grid[col] = _virtual_from_master(master, ri)
            for k in range(1, cs):
                if col + k < col_count:
                    grid[col + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": master.get("uid"),
                    }

        # Override với cells thực của row này
        for cell in get_cells(r):
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            if ci < 0 or ci >= col_count:
                continue
            ser = serialize_cell(cell) or {}
            ser["virtual_from_merge"] = False
            grid[ci] = ser

            cs = int((cell.content or {}).get("col_span", 1) or 1)
            rs = int((cell.content or {}).get("row_span", 1) or 1)

            for k in range(1, cs):
                if ci + k < col_count:
                    grid[ci + k] = {
                        "type": "cell_span_continuation",
                        "continued_from_uid": ser.get("uid"),
                    }

            if rs > 1:
                info_obj = {
                    "master_ser": ser,
                    "remain":     rs - 1,
                    "start_col":  ci,
                    "col_span":   cs,
                }
                for k in range(cs):
                    if ci + k < col_count:
                        active[ci + k] = info_obj

        if is_target:
            return grid

        # Giảm remain của active rowspan, clear nếu hết
        to_clear = []
        for col in range(col_count):
            info = active[col]
            if not info or info["start_col"] != col:
                continue
            info["remain"] -= 1
            if info["remain"] <= 0:
                cs = int(info.get("col_span", 1) or 1)
                for k in range(cs):
                    if col + k < col_count:
                        to_clear.append(col + k)
        for col in to_clear:
            active[col] = None

    # Fallback nếu không tìm thấy target_row trong rows
    return [serialize_cell(c) for c in get_cells(target_row)]