# src/services/diff/paragraph_diff.py
"""
So sánh 2 đoạn text ở mức word.

Thiết kế normalize:
  - norm_for_diff  : tách dấu phẩy/chấm phẩy thành token riêng
                     → SequenceMatcher detect insert/delete dấu câu độc lập
  - norm_for_align : xóa dấu phẩy → coi \n và "," là tương đương
                     → dùng để align lines trong multiline diff
  - _detokenize    : join token list về string tự nhiên (không có space trước phẩy)
                     → dùng để build text hiển thị trong span

space_before:
  - Mỗi span mang field "space_before" (bool) do Python tính tại nguồn
  - JS chỉ đọc field này để quyết định có thêm space khi ghép span
  - Logic: không có space trước dấu câu ,;.!?:) và sau dấu mở ngoặc (

Không dùng char-level diff — so sánh ở mức word là đủ.
"""

from __future__ import annotations

import difflib
from typing import Any, Dict, List, Optional

from src.services.extractor.utils import (
    norm_text as _norm,
    norm_for_diff,
    norm_for_align,
    _detokenize,
)

# ── Punct token sets cho space_before ────────────────────────────────────────
_PUNCT_NO_SPACE_BEFORE = {",", ";", ".", "!", "?", ":", ")"}
_OPEN_NO_SPACE_AFTER   = {"("}


def _needs_space_before(prev_tokens: List[str], cur_token: str) -> bool:
    """
    True nếu cần 1 space trước cur_token khi ghép vào chuỗi hiển thị.
      - False nếu là span đầu tiên (prev_tokens rỗng)
      - False nếu cur_token là dấu câu đóng: , ; . ! ? : )
      - False nếu token trước là dấu mở ngoặc: (
    """
    if not prev_tokens:
        return False
    if cur_token in _PUNCT_NO_SPACE_BEFORE:
        return False
    if prev_tokens[-1] in _OPEN_NO_SPACE_AFTER:
        return False
    return True


def diff_words(
    old_text: str,
    new_text: str,
    old_display: Optional[str] = None,
    new_display: Optional[str] = None,
) -> Dict[str, Any]:
    # norm_for_diff để tokenize — phẩy/chấm phẩy là token riêng
    old_norm = norm_for_diff(old_text or "")
    new_norm = norm_for_diff(new_text or "")

    # raw display giữ nguyên để hiển thị UI
    old_raw = (old_display or "").strip() or (old_text or "").strip()
    new_raw = (new_display or "").strip() or (new_text or "").strip()

    # ── Nhiều dòng → diff từng dòng riêng ────────────────────────────────
    if "\n" in old_raw or "\n" in new_raw:
        return _diff_words_multiline(old_text, new_text, old_raw, new_raw)

    if not old_norm and not new_norm:
        return {"old_full_text": old_raw, "new_full_text": new_raw, "spans": []}

    if old_norm == new_norm:
        return {
            "old_full_text": old_raw,
            "new_full_text": new_raw,
            "spans": [{
                "type":         "equal",
                "action":       "equal",
                "side":         "both",
                "old_text":     old_raw,
                "new_text":     new_raw,
                "text":         old_raw,
                "space_before": False,
            }],
        }

    a = old_norm.split()
    b = new_norm.split()

    sm    = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    spans: List[Dict[str, Any]] = []

    # Track token ngay trước mỗi side để tính space_before
    prev_old_tokens: List[str] = []
    prev_new_tokens: List[str] = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        old_words   = a[i1:i2]
        new_words   = b[j1:j2]
        old_segment = _detokenize(old_words)
        new_segment = _detokenize(new_words)

        old_first = old_words[0] if old_words else ""
        new_first = new_words[0] if new_words else ""

        if tag == "equal":
            if old_segment:
                spans.append({
                    "type":         "equal",
                    "action":       "equal",
                    "side":         "both",
                    "old_text":     old_segment,
                    "new_text":     old_segment,
                    "text":         old_segment,
                    "space_before": _needs_space_before(prev_old_tokens, old_first),
                })
                prev_old_tokens = old_words
                prev_new_tokens = new_words
            continue

        if tag == "delete":
            if old_segment:
                spans.append({
                    "type":         "delete",
                    "action":       "delete",
                    "side":         "left",
                    "old_text":     old_segment,
                    "new_text":     "",
                    "text":         old_segment,
                    "space_before": _needs_space_before(prev_old_tokens, old_first),
                })
                prev_old_tokens = old_words
            continue

        if tag == "insert":
            if new_segment:
                spans.append({
                    "type":         "insert",
                    "action":       "insert",
                    "side":         "right",
                    "old_text":     "",
                    "new_text":     new_segment,
                    "text":         new_segment,
                    "space_before": _needs_space_before(prev_new_tokens, new_first),
                })
                prev_new_tokens = new_words
            continue

        if tag == "replace":
            space_before = _needs_space_before(
                prev_old_tokens if old_first else prev_new_tokens,
                old_first or new_first,
            )
            spans.append({
                "type":         "replace",
                "action":       "replace",
                "side":         "both",
                "old_text":     old_segment,
                "new_text":     new_segment,
                "text":         old_segment,
                "space_before": space_before,
            })
            if old_words:
                prev_old_tokens = old_words
            if new_words:
                prev_new_tokens = new_words

    return {
        "old_full_text": old_raw,
        "new_full_text": new_raw,
        "spans":         spans,
    }


def _diff_one_line_pair(
    ol: str,
    nl: str,
    on: str,
    nn: str,
    all_spans: List[Dict[str, Any]],
) -> None:
    """
    Diff 1 cặp dòng (ol raw, nl raw) và append spans vào all_spans.
    on/nn là normalized để so sánh nhanh trước khi gọi diff_words.
    """
    if on == nn:
        all_spans.append({
            "type":         "equal",
            "action":       "equal",
            "side":         "both",
            "old_text":     ol,
            "new_text":     nl,
            "text":         ol,
            "space_before": False,
        })
    else:
        line_wd = diff_words(ol, nl, old_display=ol, new_display=nl)
        line_spans = line_wd.get("spans", [])
        if line_spans:
            all_spans.extend(line_spans)
        else:
            all_spans.append({
                "type":         "replace",
                "action":       "replace",
                "side":         "both",
                "old_text":     ol,
                "new_text":     nl,
                "text":         ol,
                "space_before": False,
            })


def _diff_words_multiline(
    old_text: str,
    new_text: str,
    old_raw:  str,
    new_raw:  str,
) -> Dict[str, Any]:
    """
    Diff từng dòng riêng, chèn span type="newline" giữa các dòng.
    Frontend dùng newline span để render <br>.
    Spans bên trong mỗi dòng mang space_before từ diff_words.
    Span đầu tiên mỗi dòng luôn có space_before=False.
    """
    old_lines = old_raw.split("\n")
    new_lines = new_raw.split("\n")

    old_norms = [norm_for_align(l) for l in old_lines]
    new_norms = [norm_for_align(l) for l in new_lines]

    sm = difflib.SequenceMatcher(a=old_norms, b=new_norms, autojunk=False)
    all_spans: List[Dict[str, Any]] = []

    def _add_newline() -> None:
        if all_spans:
            all_spans.append({"type": "newline"})

    for tag, i1, i2, j1, j2 in sm.get_opcodes():

        if tag == "equal":
            for i in range(i1, i2):
                _add_newline()
                all_spans.append({
                    "type":         "equal",
                    "action":       "equal",
                    "side":         "both",
                    "old_text":     old_lines[i],
                    "new_text":     old_lines[i],
                    "text":         old_lines[i],
                    "space_before": False,
                })

        elif tag == "replace":
            old_block       = old_lines[i1:i2]
            new_block       = new_lines[j1:j2]
            old_norms_block = old_norms[i1:i2]
            new_norms_block = new_norms[j1:j2]

            inner_sm = difflib.SequenceMatcher(
                a=old_norms_block,
                b=new_norms_block,
                autojunk=False,
            )

            for itag, ii1, ii2, ij1, ij2 in inner_sm.get_opcodes():

                if itag == "equal":
                    for k in range(ii1, ii2):
                        _add_newline()
                        ol = old_block[k]
                        all_spans.append({
                            "type":         "equal",
                            "action":       "equal",
                            "side":         "both",
                            "old_text":     ol,
                            "new_text":     ol,
                            "text":         ol,
                            "space_before": False,
                        })

                elif itag == "replace":
                    ipairs = min(ii2 - ii1, ij2 - ij1)
                    for k in range(ipairs):
                        _add_newline()
                        _diff_one_line_pair(
                            ol=old_block[ii1 + k],
                            nl=new_block[ij1 + k],
                            on=old_norms_block[ii1 + k],
                            nn=new_norms_block[ij1 + k],
                            all_spans=all_spans,
                        )
                    for k in range(ii1 + ipairs, ii2):
                        _add_newline()
                        all_spans.append({
                            "type":         "delete",
                            "action":       "delete",
                            "side":         "left",
                            "old_text":     old_block[k],
                            "new_text":     "",
                            "text":         old_block[k],
                            "space_before": False,
                        })
                    for k in range(ij1 + ipairs, ij2):
                        _add_newline()
                        all_spans.append({
                            "type":         "insert",
                            "action":       "insert",
                            "side":         "right",
                            "old_text":     "",
                            "new_text":     new_block[k],
                            "text":         new_block[k],
                            "space_before": False,
                        })

                elif itag == "delete":
                    for k in range(ii1, ii2):
                        _add_newline()
                        all_spans.append({
                            "type":         "delete",
                            "action":       "delete",
                            "side":         "left",
                            "old_text":     old_block[k],
                            "new_text":     "",
                            "text":         old_block[k],
                            "space_before": False,
                        })

                elif itag == "insert":
                    for k in range(ij1, ij2):
                        _add_newline()
                        all_spans.append({
                            "type":         "insert",
                            "action":       "insert",
                            "side":         "right",
                            "old_text":     "",
                            "new_text":     new_block[k],
                            "text":         new_block[k],
                            "space_before": False,
                        })

        elif tag == "delete":
            for i in range(i1, i2):
                _add_newline()
                all_spans.append({
                    "type":         "delete",
                    "action":       "delete",
                    "side":         "left",
                    "old_text":     old_lines[i],
                    "new_text":     "",
                    "text":         old_lines[i],
                    "space_before": False,
                })

        elif tag == "insert":
            for j in range(j1, j2):
                _add_newline()
                all_spans.append({
                    "type":         "insert",
                    "action":       "insert",
                    "side":         "right",
                    "old_text":     "",
                    "new_text":     new_lines[j],
                    "text":         new_lines[j],
                    "space_before": False,
                })

    return {
        "old_full_text": old_raw,
        "new_full_text": new_raw,
        "spans":         all_spans,
    }