# src/services/diff/shape_diff.py
"""
So sánh nội dung trong 2 shape node — text và ảnh.

Fix so với cũ:
  - _text_paragraphs → collect_diffable_nodes từ shape_content.py:
      collect cả paragraph có text lẫn image node theo đúng thứ tự xuất hiện.
      Trước đây bỏ qua image hoàn toàn → ảnh thay đổi không được emit.

  - _para_sig → _node_sig: cover cả image node.
      Image dùng sha256 để so sánh — stable, không phụ thuộc tên file.

  - replace: thêm case image vs image, image vs paragraph, paragraph vs image.
      Trước đây chỉ xử lý paragraph — image trong replace bị bỏ qua.

  - has_real_change: kiểm tra cả image thay đổi, không chỉ text.

  - Emit equal cho cả image không thay đổi để frontend có đủ context.
"""

from __future__ import annotations

import difflib
import hashlib
from typing import Any, Dict, List, Optional

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change, _image_payload
from src.services.extractor.utils import norm_text as _norm_text
from src.services.extractor.shape.shape_content import collect_diffable_nodes


# ══════════════════════════════════════════════════════════════════════════════
# Serialize helpers
# ══════════════════════════════════════════════════════════════════════════════

def _serialize_node(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if node is None:
        return None
    return {
        "uid":          getattr(node, "uid",   None),
        "type":         node.type,
        "display_type": node.type,
        "order":        getattr(node, "order", 0),
        "path":         getattr(node, "path",  ""),
        "content":      node.content or {},
        "children":     [_serialize_node(c) for c in (node.children or [])],
    }


# ══════════════════════════════════════════════════════════════════════════════
# Node signature — dùng cho SequenceMatcher
# ══════════════════════════════════════════════════════════════════════════════

def _node_sig(node: DocNode) -> str:
    """
    Signature cho paragraph hoặc image — dùng để align bằng SequenceMatcher.

    Paragraph: hash text — bỏ qua format/style (shape_diff không diff format).
    Image: hash sha256 — stable, không phụ thuộc tên file hay vị trí.

    Hai node cùng sig → equal (không diff).
    """
    if node.type == "image":
        sha = (node.content.get("sha256", "") or "").strip()
        return f"I:{sha[:16]}" if sha else "I:nodata"

    # paragraph
    txt = _norm_text(node.content.get("text", ""))
    h   = hashlib.md5(txt.encode("utf-8")).hexdigest()[:16] if txt else "empty"
    return f"P:{h}"


# ══════════════════════════════════════════════════════════════════════════════
# Change builder
# ══════════════════════════════════════════════════════════════════════════════

def _build_change(
    cid:         int,
    change_type: str,
    change_kind: str,
    original:    Optional[Dict[str, Any]],
    modified:    Optional[Dict[str, Any]],
    word_diff:   Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    display = (
        change_type
        .replace("_modified", "")
        .replace("_inserted", "")
        .replace("_deleted",  "")
        .replace("_equal",    "")
    )
    return {
        "id":            cid,
        "type":          change_type,
        "display_type":  display,
        "change_kind":   change_kind,
        "original":      original,
        "modified":      modified,
        "left_context":  original,
        "right_context": modified,
        "word_diff":     word_diff,
    }


def _build_image_equal(cid: int, a_node: DocNode, b_node: DocNode) -> Dict[str, Any]:
    """Emit equal cho cặp image không thay đổi — để frontend render đủ context."""
    return {
        "id":            cid,
        "type":          "image_equal",
        "display_type":  "image",
        "change_kind":   "equal",
        "original":      _image_payload(a_node),
        "modified":      _image_payload(b_node),
        "left_context":  _image_payload(a_node),
        "right_context": _image_payload(b_node),
        "word_diff":     None,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Replace handler — xử lý từng cặp node trong replace slice
# ══════════════════════════════════════════════════════════════════════════════

def _handle_replace_pair(
    cid:    int,
    a_node: DocNode,
    b_node: DocNode,
    changes: List[Dict[str, Any]],
) -> int:
    # ── image ↔ image ────────────────────────────────────────────────────────
    if a_node.type == "image" and b_node.type == "image":
        if images_equal(a_node, b_node):
            changes.append(_build_image_equal(cid, a_node, b_node))
        else:
            change = build_image_change(a_node, b_node)
            change["id"] = cid
            changes.append(change)
        return cid + 1

    # ── paragraph ↔ paragraph ────────────────────────────────────────────────
    if a_node.type == "paragraph" and b_node.type == "paragraph":
        old = _norm_text(a_node.content.get("text", ""))
        new = _norm_text(b_node.content.get("text", ""))
        if old != new:
            changes.append(_build_change(
                cid=cid,
                change_type="paragraph_modified",
                change_kind="replace",
                original=_serialize_node(a_node),
                modified=_serialize_node(b_node),
                word_diff=diff_words(
                    old, new,
                    old_display=a_node.content.get("text_display") or old,
                    new_display=b_node.content.get("text_display") or new,
                ),
            ))
        else:
            changes.append(_build_change(
                cid=cid,
                change_type="paragraph_equal",
                change_kind="equal",
                original=_serialize_node(a_node),
                modified=_serialize_node(b_node),
            ))
        return cid + 1

    # ── image ↔ paragraph → delete image + insert paragraph ─────────────────
    if a_node.type == "image":
        change = build_image_change(a_node, None)
        change["id"] = cid
        changes.append(change)
        cid += 1
        changes.append(_build_change(
            cid=cid,
            change_type="paragraph_inserted",
            change_kind="insert",
            original=None,
            modified=_serialize_node(b_node),
        ))
        return cid + 1

    # ── paragraph ↔ image → delete paragraph + insert image ─────────────────
    changes.append(_build_change(
        cid=cid,
        change_type="paragraph_deleted",
        change_kind="delete",
        original=_serialize_node(a_node),
        modified=None,
    ))
    cid += 1
    change = build_image_change(None, b_node)
    change["id"] = cid
    changes.append(change)
    return cid + 1

# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def diff_shape(a_shape: DocNode, b_shape: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh nội dung 2 shape node — text và ảnh.

    Dùng collect_diffable_nodes từ shape_content.py để collect
    paragraph có text và image theo đúng thứ tự xuất hiện trong shape.

    SequenceMatcher align dựa trên _node_sig (text hash hoặc image sha256).

    Emit:
      paragraph_equal    — paragraph giống nhau (context cho frontend)
      paragraph_modified — paragraph khác nhau, kèm word_diff
      paragraph_inserted — paragraph mới
      paragraph_deleted  — paragraph bị xóa
      image_equal        — ảnh giống nhau (context)
      image_modified     — ảnh thay đổi (từ build_image_change)
      image_added        — ảnh mới
      image_deleted      — ảnh bị xóa

    Trả về [] nếu không có thay đổi nào.
    """
    # FIX: dùng collect_diffable_nodes thay vì _text_paragraphs cũ
    # → bao gồm cả image node theo đúng thứ tự
    a_nodes = collect_diffable_nodes(a_shape)
    b_nodes = collect_diffable_nodes(b_shape)

    if not a_nodes and not b_nodes:
        return []

    a_sigs = [_node_sig(n) for n in a_nodes]
    b_sigs = [_node_sig(n) for n in b_nodes]

    sm      = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    opcodes = sm.get_opcodes()

    # Kiểm tra có thay đổi thực sự không
    has_real_change = any(tag != "equal" for tag, *_ in opcodes)
    if not has_real_change:
        return []

    changes: List[Dict[str, Any]] = []
    cid = 1

    for tag, i1, i2, j1, j2 in opcodes:

        # ── EQUAL ─────────────────────────────────────────────────────────────
        if tag == "equal":
            for k in range(i2 - i1):
                a_node = a_nodes[i1 + k]
                b_node = b_nodes[j1 + k]
                if a_node.type == "image":
                    changes.append(_build_image_equal(cid, a_node, b_node))
                else:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_equal",
                        change_kind="equal",
                        original=_serialize_node(a_node),
                        modified=_serialize_node(b_node),
                    ))
                cid += 1
            continue

        # ── INSERT ────────────────────────────────────────────────────────────
        if tag == "insert":
            for node in b_nodes[j1:j2]:
                if node.type == "image":
                    change = build_image_change(None, node)
                    change["id"] = cid
                    changes.append(change)
                else:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_inserted",
                        change_kind="insert",
                        original=None,
                        modified=_serialize_node(node),
                    ))
                cid += 1
            continue

        # ── DELETE ────────────────────────────────────────────────────────────
        if tag == "delete":
            for node in a_nodes[i1:i2]:
                if node.type == "image":
                    change = build_image_change(node, None)
                    change["id"] = cid
                    changes.append(change)
                else:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_deleted",
                        change_kind="delete",
                        original=_serialize_node(node),
                        modified=None,
                    ))
                cid += 1
            continue

        # ── REPLACE ───────────────────────────────────────────────────────────
        if tag == "replace":
            a_slice = a_nodes[i1:i2]
            b_slice = b_nodes[j1:j2]
            pairs   = min(len(a_slice), len(b_slice))

            # Pair 1-1 theo thứ tự SequenceMatcher đã align
            for k in range(pairs):
                cid = _handle_replace_pair(cid, a_slice[k], b_slice[k], changes)

            # Phần dư bên a → delete
            for node in a_slice[pairs:]:
                if node.type == "image":
                    change = build_image_change(node, None)
                    change["id"] = cid
                    changes.append(change)
                else:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_deleted",
                        change_kind="delete",
                        original=_serialize_node(node),
                        modified=None,
                    ))
                cid += 1

            # Phần dư bên b → insert
            for node in b_slice[pairs:]:
                if node.type == "image":
                    change = build_image_change(None, node)
                    change["id"] = cid
                    changes.append(change)
                else:
                    changes.append(_build_change(
                        cid=cid,
                        change_type="paragraph_inserted",
                        change_kind="insert",
                        original=None,
                        modified=_serialize_node(node),
                    ))
                cid += 1

    return changes