"""
block/table_merge.py
~~~~~~~~~~~~~~~~~~~~
Merge các bảng bị cắt trang thành 1 bảng liên tục.

Tách từ block_builder.py.
Import bởi: block_builder.py
"""

from __future__ import annotations

from typing import List, Optional

from src.services.models.docnode import DocNode
from src.services.models.block import Block
from src.services.block.signature import signature
from src.services.block.filters import _norm, _is_skip_pattern


# ══════════════════════════════════════════════════════════════════════════════
# Row / cell helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_rows(table_node: DocNode) -> List[DocNode]:
    return [c for c in (table_node.children or []) if c.type == "row"]


def _get_cells(row_node: DocNode) -> List[DocNode]:
    return [c for c in (row_node.children or []) if c.type == "cell"]


def _col_count(table_node: DocNode) -> int:
    rows = _get_rows(table_node)
    return len(_get_cells(rows[0])) if rows else 0


# table_merge.py
def _get_header_key(table_node: DocNode) -> Optional[str]:
    rows = _get_rows(table_node)
    if not rows:
        return None
    key = "|".join(_norm(c.content.get("text", "")) for c in _get_cells(rows[0]))
    # Header toàn rỗng (chỉ có ảnh) → không đủ tin cậy để match
    if not key.replace("|", "").strip():
        return None
    return key


def _get_cell_texts(row_node: DocNode) -> List[str]:
    texts = []
    for cell in _get_cells(row_node):
        cell_text = _norm(cell.content.get("text", ""))
        if cell_text:
            texts.append(cell_text)
            continue
        for child in (cell.children or []):
            if child.type == "paragraph":
                t = _norm(child.content.get("text", ""))
                if t:
                    texts.append(t)
    return texts


def _last_row_is_continue(table_node: DocNode) -> bool:
    rows = _get_rows(table_node)
    if not rows:
        return False
    non_empty = _get_cell_texts(rows[-1])
    return bool(non_empty) and all(_is_skip_pattern(t) for t in non_empty)


def _remove_last_row(table_node: DocNode) -> None:
    rows = _get_rows(table_node)
    if not rows:
        return
    last = rows[-1]
    table_node.children = [c for c in (table_node.children or []) if c is not last]
    table_node.content["row_count"] = len(_get_rows(table_node))


def _merge_two_tables(base: DocNode, extra: DocNode) -> None:
    extra_rows = _get_rows(extra)
    for row in (extra_rows[1:] if len(extra_rows) > 1 else []):
        base.children.append(row)
    base.content["row_count"] = len(_get_rows(base))


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def _can_merge(prev: Block, curr: Block) -> bool:
    if prev.type != "table" or curr.type != "table":
        return False
    if prev.heading_ctx != curr.heading_ctx:
        return False
    prev_header = _get_header_key(prev.node)
    curr_header = _get_header_key(curr.node)
    if prev_header is None or curr_header is None:
        return False
    if prev_header != curr_header:
        return False
    if _col_count(prev.node) != _col_count(curr.node):
        return False
    if not _last_row_is_continue(prev.node):
        return False
    return True


def merge_consecutive_tables(blocks: List[Block]) -> List[Block]:
    if not blocks:
        return blocks
    result: List[Block] = []
    for block in blocks:
        if result and _can_merge(result[-1], block):
            prev = result[-1]
            _remove_last_row(prev.node)
            _merge_two_tables(prev.node, block.node)
            prev.signature = signature(prev.node, heading_ctx=prev.heading_ctx or "")
            continue
        result.append(block)
    return result
