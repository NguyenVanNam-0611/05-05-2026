"""
extractor/image.py
~~~~~~~~~~~~~~~~~~
Extract ảnh từ một Paragraph.

Xử lý:
    ✅ Ảnh inline  (<wp:inline>) — nằm trong dòng chữ
    ✅ Ảnh anchor  (<wp:anchor>) có a:blip — floating image (Win32com convert từ .doc)
    ✅ Ảnh inline trong cell (table.py gọi hàm này cho mỗi paragraph trong cell)

Không xử lý:
    ❌ Ảnh anchor không có a:blip — đây là shape/textbox, không phải ảnh
    ❌ Ảnh trong header / footer

Thay đổi so với cũ:
    - Bỏ data_uri khỏi content — không encode base64 tại extract time
    - Lưu raw_bytes vào content để pipeline sau dùng (lazy encode)
    - image_store.save_image() lưu file ra /tmp — serve qua URL tĩnh
    - Fix EMF convert bị gọi 2 lần (lần 2 là dead code)
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from docx.text.paragraph import Paragraph
from lxml import etree

from src.services.models.docnode import DocNode
from src.services.extractor.utils import OrderRef, next_order
from src.services.utils.hash import safe_sha256
from src.services.utils.image_store import save_image

# ── Namespaces ────────────────────────────────────────────────────────────────

_NS: Dict[str, str] = {
    "a":  "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r":  "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "w":  "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "v":  "urn:schemas-microsoft-com:vml",
    "o":  "urn:schemas-microsoft-com:office:office",
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _pure(elm):
    """
    Chuyển BaseOxmlElement về lxml element thuần.
    python-docx 1.2.0 override .xpath() và không nhận tham số 'namespaces'
    nên phải serialize → parse lại để bypass.
    """
    return etree.fromstring(etree.tostring(elm))


def _get_image_size(drawing_elm) -> tuple[int, int]:
    extents = drawing_elm.xpath(".//wp:inline/wp:extent", namespaces=_NS)
    if not extents:
        extents = drawing_elm.xpath(".//wp:anchor/wp:extent", namespaces=_NS)
    if not extents:
        return 0, 0
    ext = extents[0]
    return _emu_to_int(ext.get("cx")), _emu_to_int(ext.get("cy"))


def _get_alt_text(drawing_elm) -> str:
    doc_prs = drawing_elm.xpath(".//wp:inline/wp:docPr", namespaces=_NS)
    if not doc_prs:
        doc_prs = drawing_elm.xpath(".//wp:anchor/wp:docPr", namespaces=_NS)
    if not doc_prs:
        return ""
    doc_pr = doc_prs[0]
    return doc_pr.get("descr") or doc_pr.get("title") or ""


def _is_anchor(drawing_elm) -> bool:
    return bool(drawing_elm.xpath("wp:anchor", namespaces=_NS))


def _parse_vml_size(style: str) -> tuple[int, int]:
    PT_TO_EMU = 12700
    width_emu = height_emu = 0
    for part in style.split(";"):
        part = part.strip()
        if part.startswith("width:"):
            val = part[6:].replace("pt", "").strip()
            try:
                width_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
        elif part.startswith("height:"):
            val = part[7:].replace("pt", "").strip()
            try:
                height_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
    return width_emu, height_emu


def _convert_emf_to_png(blob: bytes) -> Optional[bytes]:
    try:
        import tempfile, os, io, time, ctypes
        from ctypes import wintypes
        from PIL import Image

        gdi32  = ctypes.windll.gdi32
        user32 = ctypes.windll.user32

        with tempfile.NamedTemporaryFile(suffix=".emf", delete=False) as f:
            f.write(blob)
            emf_path = f.name

        hemf = None
        try:
            hemf = gdi32.GetEnhMetaFileW(emf_path)
            if not hemf:
                raise RuntimeError("GetEnhMetaFileW failed")

            class ENHMETAHEADER(ctypes.Structure):
                _fields_ = [
                    ("iType",          ctypes.c_uint),
                    ("nSize",          ctypes.c_uint),
                    ("rclBounds",      ctypes.c_long * 4),
                    ("rclFrame",       ctypes.c_long * 4),
                    ("dSignature",     ctypes.c_uint),
                    ("nVersion",       ctypes.c_uint),
                    ("nBytes",         ctypes.c_uint),
                    ("nRecords",       ctypes.c_uint),
                    ("nHandles",       ctypes.c_ushort),
                    ("sReserved",      ctypes.c_ushort),
                    ("nDescription",   ctypes.c_uint),
                    ("offDescription", ctypes.c_uint),
                    ("nPalEntries",    ctypes.c_uint),
                    ("szlDevice",      ctypes.c_long * 2),
                    ("szlMillimeters", ctypes.c_long * 2),
                ]

            header = ENHMETAHEADER()
            gdi32.GetEnhMetaFileHeader(hemf, ctypes.sizeof(header), ctypes.byref(header))

            w = max(header.rclBounds[2] - header.rclBounds[0], 1)
            h = max(header.rclBounds[3] - header.rclBounds[1], 1)
            if w <= 1 or h <= 1:
                w = max(int((header.rclFrame[2] - header.rclFrame[0]) * 96 / 2540), 100)
                h = max(int((header.rclFrame[3] - header.rclFrame[1]) * 96 / 2540), 100)

            hdc  = user32.GetDC(0)
            hmdc = gdi32.CreateCompatibleDC(hdc)
            hbmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
            gdi32.SelectObject(hmdc, hbmp)

            WHITE_BRUSH = 0
            hbrush = gdi32.GetStockObject(WHITE_BRUSH)
            rect   = (ctypes.c_long * 4)(0, 0, w, h)
            user32.FillRect(hmdc, rect, hbrush)

            rect2 = (ctypes.c_long * 4)(0, 0, w, h)
            gdi32.PlayEnhMetaFile(hmdc, hemf, rect2)

            class BITMAP(ctypes.Structure):
                _fields_ = [
                    ("bmType",       ctypes.c_long),
                    ("bmWidth",      ctypes.c_long),
                    ("bmHeight",     ctypes.c_long),
                    ("bmWidthBytes", ctypes.c_long),
                    ("bmPlanes",     ctypes.c_ushort),
                    ("bmBitsPixel",  ctypes.c_ushort),
                    ("bmBits",       ctypes.c_void_p),
                ]

            bmp = BITMAP()
            gdi32.GetObjectW(hbmp, ctypes.sizeof(bmp), ctypes.byref(bmp))
            bmpstr_size = bmp.bmWidthBytes * bmp.bmHeight
            bmpstr = (ctypes.c_char * bmpstr_size)()
            gdi32.GetBitmapBits(hbmp, bmpstr_size, bmpstr)

            img = Image.frombuffer(
                "RGB", (bmp.bmWidth, bmp.bmHeight),
                bytes(bmpstr), "raw", "BGRX", 0, 1
            )

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()

        finally:
            if hemf:
                gdi32.DeleteEnhMetaFile(hemf)
            try:
                gdi32.DeleteObject(hbmp)
            except Exception:
                pass
            try:
                gdi32.DeleteDC(hmdc)
            except Exception:
                pass
            try:
                user32.ReleaseDC(0, hdc)
            except Exception:
                pass

            for attempt in range(5):
                try:
                    os.unlink(emf_path)
                    break
                except PermissionError:
                    if attempt < 4:
                        time.sleep(0.1)

    except Exception as e:
        print(f"[EMF_CONVERT] fail: {e}")
        return None


def _normalize_blob(blob: bytes, mime: str) -> tuple[bytes, str]:
    """
    Nếu mime là EMF/WMF thì convert sang PNG một lần duy nhất.
    Trả (blob, mime) đã chuẩn hoá.

    FIX: tách logic convert ra helper riêng để tránh gọi 2 lần
    như trong code cũ (_extract_vml_images có 2 if-block EMF liên tiếp).
    """
    if mime in ("image/x-emf", "image/emf", "image/wmf", "image/x-wmf"):
        converted = _convert_emf_to_png(blob)
        if converted:
            return converted, "image/png"
    return blob, mime


def _build_image_content(
    blob:       bytes,
    mime:       str,
    rid:        str,
    width_emu:  int,
    height_emu: int,
    alt_text:   str,
    floating:   bool,
    run_index:  int,
    draw_index: int,
    blip_index: int,
    extra:      Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Tạo content dict cho DocNode(type="image").

    Lưu raw_bytes để pipeline sau (image_diff, perceptual hash) dùng.
    Gọi save_image() để lưu file ra /tmp — trả về image_url.
    KHÔNG lưu data_uri — frontend dùng image_url để fetch.

    sha256 được tính từ blob đã normalize (sau EMF convert nếu có).
    """
    sha256    = safe_sha256(blob)
    image_url = save_image(sha256, blob, mime)

    content: Dict[str, Any] = {
        "rid":        rid,
        "hash":       sha256,
        "sha256":     sha256,
        "mime":       mime,
        "width_emu":  width_emu,
        "height_emu": height_emu,
        "alt_text":   alt_text,
        "image_url":  image_url,   # ← URL tĩnh thay cho data_uri
        "raw_bytes":  blob,        # ← giữ để perceptual hash dùng nếu cần
        "floating":   floating,
        "run_index":  run_index,
        "draw_index": draw_index,
        "blip_index": blip_index,
    }
    if extra:
        content.update(extra)
    return content


# ══════════════════════════════════════════════════════════════════════════════
# VML extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_vml_images(
    r_pure,
    par: Paragraph,
    uid_prefix: str,
    run_idx: int,
    parent_uid: Optional[str],
    order_ref: Optional[OrderRef],
) -> List[DocNode]:
    nodes: List[DocNode] = []

    picts = r_pure.xpath(".//w:pict", namespaces=_NS)
    if not picts:
        return nodes

    for pict_idx, pict in enumerate(picts, start=1):
        imagedatas = pict.xpath(".//v:imagedata", namespaces=_NS)
        for img_idx, imgdata in enumerate(imagedatas, start=1):
            rid = imgdata.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            if not rid:
                continue

            part = par.part.related_parts.get(rid)
            if part is None:
                continue

            blob = part.blob
            if not blob:
                continue

            mime = getattr(part, "content_type", None) or "image/png"

            # FIX: EMF convert một lần duy nhất qua helper
            blob, mime = _normalize_blob(blob, mime)

            shape      = pict.xpath(".//v:shape", namespaces=_NS)
            width_emu  = height_emu = 0
            if shape:
                width_emu, height_emu = _parse_vml_size(shape[0].get("style", ""))

            alt_text = imgdata.get("{urn:schemas-microsoft-com:office:office}title", "")
            img_uid  = f"{uid_prefix}.r{run_idx}.p{pict_idx}.{img_idx}"

            nodes.append(
                DocNode(
                    type="image",
                    uid=img_uid,
                    parent_uid=parent_uid,
                    order=next_order(order_ref),
                    path=img_uid.replace(".", "/"),
                    content=_build_image_content(
                        blob=blob,
                        mime=mime,
                        rid=rid,
                        width_emu=width_emu,
                        height_emu=height_emu,
                        alt_text=alt_text,
                        floating=True,
                        run_index=run_idx,
                        draw_index=pict_idx,
                        blip_index=img_idx,
                        extra={"vml": True},
                    ),
                )
            )

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_inline_images(
    par: Paragraph,
    uid_prefix: str = "img",
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> List[DocNode]:
    """
    Trích xuất tất cả ảnh từ một paragraph.

    Lấy cả wp:inline lẫn wp:anchor miễn là có a:blip với r:embed.
    Fallback sang VML (w:pict > v:imagedata) cho file convert từ .doc bằng Win32com.

    Returns:
        List DocNode(type="image"), rỗng nếu không có ảnh.
    """
    nodes: List[DocNode] = []

    for run_idx, run in enumerate(par.runs, start=1):
        r_elm = run._r
        if r_elm is None:
            continue

        r_pure   = _pure(r_elm)
        drawings = r_pure.xpath(".//w:drawing", namespaces=_NS)

        if drawings:
            for draw_idx, drawing in enumerate(drawings, start=1):
                blip_rids = drawing.xpath(".//a:blip/@r:embed", namespaces=_NS)
                if not blip_rids:
                    continue

                width_emu, height_emu = _get_image_size(drawing)
                alt_text              = _get_alt_text(drawing)
                floating              = _is_anchor(drawing)

                for blip_idx, rid in enumerate(blip_rids, start=1):
                    part = par.part.related_parts.get(rid)
                    if part is None:
                        continue

                    blob = part.blob
                    if not blob:
                        continue

                    mime = getattr(part, "content_type", None) or "image/png"

                    # DrawingML thường không có EMF nhưng normalize để nhất quán
                    blob, mime = _normalize_blob(blob, mime)

                    img_uid = f"{uid_prefix}.r{run_idx}.d{draw_idx}.{blip_idx}"

                    nodes.append(
                        DocNode(
                            type="image",
                            uid=img_uid,
                            parent_uid=parent_uid,
                            order=next_order(order_ref),
                            path=img_uid.replace(".", "/"),
                            content=_build_image_content(
                                blob=blob,
                                mime=mime,
                                rid=rid,
                                width_emu=width_emu,
                                height_emu=height_emu,
                                alt_text=alt_text,
                                floating=floating,
                                run_index=run_idx,
                                draw_index=draw_idx,
                                blip_index=blip_idx,
                            ),
                        )
                    )

        else:
            nodes.extend(
                _extract_vml_images(r_pure, par, uid_prefix, run_idx, parent_uid, order_ref)
            )

    return nodes