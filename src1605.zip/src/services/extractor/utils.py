"""
extractor/utils.py
~~~~~~~~~~~~~~~~~~
Các helper thuần tuý dùng chung cho toàn bộ extractor.

Chỉ chứa những thứ KHÔNG phụ thuộc vào docx object:
    - norm_text     : chuẩn hoá chuỗi để so sánh / diff
    - norm_for_diff : normalize để tokenize trong word-level diff
    - norm_for_align: normalize để align lines trong multiline diff
    - _detokenize   : join token list về string tự nhiên để hiển thị
    - raw_text      : giữ layout gốc để hiển thị UI
    - next_order    : tăng counter thứ tự (None-safe)
    - safe_pt       : lấy giá trị pt an toàn
    - OrderRef      : type alias cho mutable counter

Iterator nằm trong file dùng chúng:
    - document.py → _iter_block_items
    - table.py    → _iter_cell_items

IMPORTANT:
    - Word dùng ký tự \x0b (vertical tab) để biểu diễn Shift+Enter (w:br),
      đặc biệt hay gặp trong table cell.
    - Trước đây \x0b bị đưa vào _DROP_CHARS nên bị XÓA HẲN ở cả norm_text/raw_text
      → text bị dính, mất xuống dòng.
    - Fix: xử lý \x0b RIÊNG:
        * norm_text: \x0b → " "
        * raw_text : \x0b → "\n"
"""

from __future__ import annotations

import re
import unicodedata
from typing import Dict, List, Optional

# ── Types ─────────────────────────────────────────────────────────────────────

OrderRef = Dict[str, int]   # {"value": int} — mutable int counter

# ══════════════════════════════════════════════════════════════════════════════
# Internal: translation tables (build once at import time)
# ══════════════════════════════════════════════════════════════════════════════

# Space variants → space thường
# (non-breaking space, en/em space, thin space, CJK space, …)
_SPACE_VARIANTS = (
    "\u00a0"  # non-breaking space
    "\u2002"  # en space
    "\u2003"  # em space
    "\u2004"  # three-per-em space
    "\u2005"  # four-per-em space
    "\u2006"  # six-per-em space
    "\u2007"  # figure space
    "\u2008"  # punctuation space
    "\u2009"  # thin space
    "\u200a"  # hair space
    "\u202f"  # narrow no-break space
    "\u3000"  # ideographic space (CJK)
)

# Ký tự zero-width và Word internal break → xóa hẳn
# Rất phổ biến trong văn bản tiếng Việt copy-paste vào Word
#
# NOTE:
#   ❌ KHÔNG đưa "\x0b" vào đây nữa (Shift+Enter) — xử lý riêng.
_DROP_CHARS = (
    "\u200b"  # zero-width space
    "\u200c"  # zero-width non-joiner
    "\u200d"  # zero-width joiner
    "\u2060"  # word joiner
    "\ufeff"  # BOM / zero-width no-break space
    "\u00ad"  # soft hyphen
    "\u2028"  # line separator — xuất hiện khi copy từ PDF/web vào Word
    "\u2029"  # paragraph separator
    # "\x0b"  # vertical tab — Shift+Enter (w:br) → xử lý riêng!
    "\x0c"    # form feed — page break
    "\x1c"    # file separator
    "\x1d"    # group separator
    "\x1e"    # record separator
)

_TO_SPACE_TABLE = str.maketrans(_SPACE_VARIANTS, " " * len(_SPACE_VARIANTS))
_DROP_TABLE     = str.maketrans("", "", _DROP_CHARS)

_SHIFT_ENTER = "\x0b"

# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def norm_text(s: str) -> str:
    """
    Chuẩn hoá text để so sánh / diff — KHÔNG dùng để hiển thị UI.

    Pipeline:
      1. NFC normalize  → đảm bảo dấu tiếng Việt nhất quán
      2. Shift+Enter (\x0b) → space (tránh dính chữ khi merge cell)
      3. Xóa zero-width + Word internal break characters (trừ \x0b)
      4. Map space variants → space thường; \\n \\r \\t → space
      5. Normalize dấu phẩy/chấm phẩy: luôn có đúng 1 space sau, không có space trước
         "OT4,OT5"  → "OT4, OT5"
         "OT4 ,OT5" → "OT4, OT5"
         Giữ nguyên dấu chấm (.) — phân biệt "v1.0" vs "v10", "ST.001" vs "ST001"
      6. Xóa space thừa bên trong ngoặc
         "ST( Ashitaka )" → "ST(Ashitaka)"
      7. Collapse whitespace và strip
    """
    if not s:
        return ""

    # 1. NFC
    s = unicodedata.normalize("NFC", s)

    # 2. Shift+Enter → space (để diff không dính chữ)
    s = s.replace(_SHIFT_ENTER, " ")

    # 3. Xóa zero-width + internal breaks (trừ \x0b)
    s = s.translate(_DROP_TABLE)

    # 4. Space variants và control chars → space thường
    s = s.translate(_TO_SPACE_TABLE)
    s = s.replace("\n", " ").replace("\r", " ").replace("\t", " ")

    # 5. Normalize dấu phẩy và chấm phẩy (KHÔNG normalize dấu chấm)
    # Lookahead (?=\S): chỉ thêm space nếu còn ký tự phía sau
    s = re.sub(r"\s*([,;])\s*(?=\S)", r"\1 ", s)
    # Xóa space trước dấu câu ở cuối chuỗi: "OT4 ," → "OT4,"
    s = re.sub(r"\s+([,;])$", r"\1", s)

    # 6. Xóa space thừa bên trong ngoặc
    s = re.sub(r"\(\s+", "(", s)
    s = re.sub(r"\s+\)", ")", s)

    # 7. Collapse và strip
    return " ".join(s.split())


def norm_for_diff(s: str) -> str:
    """
    Normalize để TOKENIZE trong word-level diff.

    Dấu phẩy/chấm phẩy được tách thành token riêng (space 2 bên)
    để SequenceMatcher detect insert/delete dấu câu độc lập.

    Giữ nguyên: dấu chấm, gạch ngang, gạch chéo (phân biệt mã kỹ thuật)
    """
    s = norm_text(s)
    # Tách phẩy/chấm phẩy thành token riêng — space 2 bên
    s = re.sub(r"\s*([,;])\s*", r" \1 ", s)
    return " ".join(s.split())


def norm_for_align(s: str) -> str:
    """
    Normalize để ALIGN LINES trong multiline diff.

    Coi \\n và dấu phẩy là tương đương → tránh align sai khi merge row.
    "ST(Ashitaka), ST(Single Mesh)" và "ST(Ashitaka)\\nST(Single Mesh)"
    → đều thành "ST(Ashitaka) ST(Single Mesh)" → SequenceMatcher align đúng.
    """
    s = norm_text(s)
    s = re.sub(r"[,;]\s*", " ", s)   # xóa phẩy → coi tương đương \n
    return " ".join(s.split())


def _detokenize(tokens: List[str]) -> str:
    """
    Join token list về string tự nhiên để hiển thị trong span.

    Dấu phẩy/chấm phẩy: không có space trước, có 1 space sau.
    ["ST(Ashitaka)", ",", "ST(Single Mesh)"] → "ST(Ashitaka), ST(Single Mesh)"
    """
    result = ""
    for i, tok in enumerate(tokens):
        if tok in (",", ";"):
            result += tok + " "
        elif i == 0:
            result += tok
        else:
            result += " " + tok
    return result.strip()


def raw_text(s: str) -> str:
    """
    Giữ nguyên layout gốc để hiển thị UI.

    Chỉ:
      - NFC normalize (dấu tiếng Việt nhất quán)
      - Shift+Enter (\x0b) → newline (\\n)
      - Chuẩn hoá line ending \\r\\n/\\r → \\n
      - Thay space variants → space thường (VẪN giữ newline)
      - Xóa zero-width silently (trừ \x0b)
      - Strip đầu/cuối
    """
    if not s:
        return ""

    s = unicodedata.normalize("NFC", s)

    # ✅ Shift+Enter trong Word cell → newline để UI render đúng
    s = s.replace(_SHIFT_ENTER, "\n")

    # Chuẩn hoá line ending
    s = s.replace("\r\n", "\n").replace("\r", "\n")

    # Xóa zero-width + internal breaks (không còn \x0b trong _DROP_TABLE)
    s = s.translate(_DROP_TABLE)

    # Space variants → space thường (giữ newline)
    s = s.translate(_TO_SPACE_TABLE)

    return s.strip()


def next_order(order_ref: Optional[OrderRef]) -> int:
    """
    Tăng counter và trả về giá trị mới.
    Trả 0 nếu order_ref là None (dùng trong shape.py khi không có context).
    """
    if order_ref is None:
        return 0
    order_ref["value"] += 1
    return order_ref["value"]


def safe_pt(value) -> Optional[float]:
    """Lấy giá trị pt từ Length object, trả None nếu không có."""
    try:
        return value.pt if value is not None else None
    except Exception:
        return None
