"""
align/sequence_align.py
~~~~~~~~~~~~~~~~~~~~~~~
Align block list A (original) với block list B (modified) thành list opcodes.

Fixes so với cũ:
1. HEADING SHIFT BUG — khi thêm heading mới đẩy các block xuống (5.1 Nam, 5.2 Nga
   → 5.1 Nam, 5.2 Son, 5.3 Nga), heading_ctx của "Nga" thay đổi từ "5.2" → "5.3"
   khiến signature đổi hoàn toàn → SequenceMatcher không match được.
   FIX: dùng CONTENT-ONLY signature (không có heading_ctx) cho SequenceMatcher.
   Với shape: dùng ctx_body (tên heading bỏ số chương) thay vì heading_ctx đầy đủ
   → stable khi số chương đổi nhưng vẫn phân biệt heading tên khác nhau.

2. CROSS-MATCH BUG — 2 shape cùng text ở 2 heading tên khác nhau bị match nhầm
   vì content_sig giống nhau hoàn toàn.
   FIX: đưa ctx_body vào content_sig của shape.
   "shape|abc|quy trình a" ≠ "shape|abc|quy trình b" → không match nhầm.

3. _match_mixed_slice INDEX BUG — phần emit delete/insert không được sort
   → opcodes có thể không tăng dần theo index.
   FIX: sort matched_a và unmatched_b trước khi emit.

4. N-N table pairing — giữ lại nhưng guard thêm.

5. SIMILAR BLOCK DEDUP — nhiều block có content thay đổi y hệt nhau
   → SequenceMatcher có thể match nhầm. _block_similarity với heading bonus
   được dùng ở bước quyết định replace vs delete+insert để tránh false match.

6. EMPTY SHAPE CONTENT SIG — trước dùng absolute order → không stable khi
   thêm/xóa block phía trước. FIX: dùng uid_suffix + ctx_body thay cho order.

7. SHAPE WITH TEXT CONTENT SIG — trước bị paste nhầm trả "shape|empty|..."
   dù có text, và dùng biến uid_suffix không tồn tại trong nhánh đó.
   FIX: nhánh có text trả đúng f"shape|{h}|p{para_count}|{ctx_body}".

8. MIXED SLICE OPCODE ORDER BUG — _match_mixed_slice emit replace theo ki
   nhưng delete được emit sau toàn bộ replace, với i1 có thể nhỏ hơn i1 của
   replace cuối → opcodes không tăng dần theo i1 → json_builder tính
   seq_index sai → thứ tự hiển thị bị đảo.
   FIX: sau khi _match_mixed_slice emit xong, sort toàn bộ refined theo
   (i1, j1) để đảm bảo tăng dần tuyệt đối trước khi trả về.

9. SHAPE IMAGE BUG — _shape_text và _content_sig bỏ qua ảnh trong shape
   → 2 shape chỉ khác nhau về ảnh có sig giống nhau → match nhầm hoặc equal nhầm.
   FIX: dùng collect_shape_parts từ shape_content.py — nguồn sự thật duy nhất
   về nội dung shape (text + image hash). Đồng bộ với signature.py và shape_diff.py.

10. SHAPE SIMILARITY IMAGE BUG — _block_similarity cho shape chỉ so sánh text,
    bỏ qua ảnh → 2 shape chỉ khác ảnh có similarity cao → không detect được diff.
    FIX: dùng collect_shape_parts (bao gồm img hash) để tính similarity.
"""

from __future__ import annotations

import difflib
import hashlib
from typing import List, Set, Tuple

from src.services.block.block_builder import _norm
from src.services.block.signature import _split_heading, _norm_text
from src.services.models.block import Block
from src.services.extractor.shape.shape_content import collect_shape_parts

Opcode = Tuple[str, int, int, int, int]


# ══════════════════════════════════════════════════════════════════════════════
# Shape content helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_combined(block: Block) -> str:
    """
    Trả chuỗi join của tất cả parts (text + img hash) trong shape.

    Dùng collect_shape_parts từ shape_content.py — đồng bộ với
    signature.py và shape_diff.py. Bao gồm cả ảnh.

    Thay thế _shape_text cũ (chỉ có text, bỏ qua ảnh).
    """
    parts = collect_shape_parts(block.node)
    return " ".join(parts)


def _count_content_parts(block: Block) -> int:
    """
    Đếm số parts có nghĩa trong shape (paragraph có text + image).

    Thay thế _count_text_paragraphs cũ (chỉ đếm paragraph, bỏ qua ảnh).
    """
    return len(collect_shape_parts(block.node))


# ══════════════════════════════════════════════════════════════════════════════
# Heading context normalizer
# ══════════════════════════════════════════════════════════════════════════════

def _heading_ctx_body(heading_ctx: str) -> str:
    """
    Chuẩn hoá heading_ctx thành chuỗi chỉ gồm tên heading, bỏ số chương.

    "5.1 Quy trình A > 5.1.2 Bước kiểm tra"
    → "quy trình a > bước kiểm tra"

    Giải quyết đồng thời 2 yêu cầu xung đột:

    HEADING SHIFT: "5.1 Quy trình A" và "5.3 Quy trình A" (sau khi thêm heading)
    → cùng ctx_body "quy trình a" → shape bên dưới vẫn match được.

    CROSS-MATCH: "Quy trình A" và "Quy trình B" → ctx_body khác nhau
    → shape cùng text/ảnh ở 2 heading tên khác nhau không bị match nhầm.
    """
    if not heading_ctx:
        return ""
    parts = heading_ctx.split(" > ")
    bodies = []
    for part in parts:
        _, body = _split_heading(part)
        bodies.append(body)
    return " > ".join(bodies)


# ══════════════════════════════════════════════════════════════════════════════
# Similarity
# ══════════════════════════════════════════════════════════════════════════════

def _order_bonus(a: Block, b: Block) -> float:
    """
    Bonus nếu 2 block gần nhau theo order.

    Chỉ dùng trong _block_similarity để tiebreak — không dùng trong
    _content_sig vì order tuyệt đối không stable cross-document.
    """
    ao = a.order or 0
    bo = b.order or 0
    d = abs(ao - bo)
    if d <= 1:
        return 0.25
    if d <= 3:
        return 0.15
    if d <= 8:
        return 0.05
    return 0.0


def _block_similarity(a: Block, b: Block) -> float:
    if a.type != b.type:
        return 0.0

    same_heading = a.heading_ctx == b.heading_ctx

    if a.type == "shape":
        # FIX: dùng collect_shape_parts thay vì _shape_text cũ
        # → bao gồm cả ảnh trong so sánh similarity
        a_parts = collect_shape_parts(a.node)
        b_parts = collect_shape_parts(b.node)
        a_combined = " ".join(a_parts)
        b_combined = " ".join(b_parts)

        if not a_parts and not b_parts:
            # Cả 2 rỗng — cùng heading thì coi là cùng shape
            return 0.45 if same_heading else 0.05

        if not a_parts or not b_parts:
            # 1 bên rỗng, 1 bên có nội dung — khác nhau
            return 0.45 if same_heading else 0.0

        ratio = difflib.SequenceMatcher(
            a=a_combined, b=b_combined, autojunk=False
        ).ratio()
        heading_bonus = 0.2 if same_heading else 0.0
        return min(1.0, ratio + heading_bonus)

    if a.type == "table":
        a_text = (a.signature or "").strip()
        b_text = (b.signature or "").strip()
        ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
        if same_heading:
            return max(0.5, ratio)
        return min(1.0, ratio + 0.15)

    heading_bonus = 0.35 if same_heading else 0.15
    a_text = (a.signature or "").strip()
    b_text = (b.signature or "").strip()
    ratio = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
    return min(1.0, ratio + heading_bonus)


# ══════════════════════════════════════════════════════════════════════════════
# Content-only signature (không dùng heading_ctx đầy đủ)
# ══════════════════════════════════════════════════════════════════════════════

def _content_sig(block: Block) -> str:
    t = block.type

    if t == "shape":
        # FIX: dùng collect_shape_parts thay vì _shape_text cũ
        # → bao gồm cả img hash → shape chỉ có ảnh không còn bị sig = "empty"
        parts    = collect_shape_parts(block.node)
        combined = " ".join(parts)
        ctx_body = _heading_ctx_body(block.heading_ctx or "")

        if not parts:
            # Shape thực sự rỗng (không có text lẫn ảnh)
            uid      = getattr(block.node, "uid", "") or ""
            uid_hash = hashlib.md5(uid.encode("utf-8")).hexdigest()[:8]
            return f"shape|empty|{uid_hash}|{ctx_body}"

        h           = hashlib.md5(combined.encode("utf-8")).hexdigest()[:16]
        part_count  = len(parts)  # text parts + img parts
        return f"shape|{h}|n{part_count}|{ctx_body}"

    if t == "heading":
        level = int(block.node.content.get("level", 1) or 1)
        txt   = _norm_text(block.node.content.get("text", ""))
        chapter, body = _split_heading(txt)
        chapter_depth = len(chapter.split(".")) if chapter else 0
        h = hashlib.md5(body.encode("utf-8")).hexdigest()[:12]
        return f"H{level}|d{chapter_depth}|{h}"

    return f"{t}|{block.signature or ''}"


# ══════════════════════════════════════════════════════════════════════════════
# Opcode sort key
# ══════════════════════════════════════════════════════════════════════════════

def _opcode_sort_key(op: Opcode) -> tuple:
    tag, i1, i2, j1, j2 = op
    return (i1, j1)


# ══════════════════════════════════════════════════════════════════════════════
# Main aligner
# ══════════════════════════════════════════════════════════════════════════════

def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    """
    Align 2 block list, trả về list opcode (tag, i1, i2, j1, j2).

    Luồng:
    1. SequenceMatcher trên content-only signature → raw opcodes
    2. Với mỗi replace opcode: refine thành pair replace hoặc delete+insert
       dựa trên _block_similarity (có heading bonus)
    3. Mixed slice (N-M replace) → greedy matching
    4. Sort toàn bộ refined theo (i1, j1) — đảm bảo tăng dần tuyệt đối.
       _match_mixed_slice có thể emit replace(i1=163) trước delete(i1=156)
       vì pairs được emit trước, unmatched được emit sau → lộn xộn.
       Sort này fix hoàn toàn vấn đề đó mà không ảnh hưởng logic matching.
    """
    a_sigs = [_content_sig(b) for b in a_blocks]
    b_sigs = [_content_sig(b) for b in b_blocks]

    sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    raw_opcodes = sm.get_opcodes()
    refined: List[Opcode] = []

    for tag, i1, i2, j1, j2 in raw_opcodes:
        if tag != "replace":
            refined.append((tag, i1, i2, j1, j2))
            continue

        a_slice = a_blocks[i1:i2]
        b_slice = b_blocks[j1:j2]

        # ── 1-1 replace ───────────────────────────────────────────────────────
        if len(a_slice) == 1 and len(b_slice) == 1:
            similarity = _block_similarity(a_slice[0], b_slice[0])
            if similarity >= 0.45:
                refined.append(("replace", i1, i2, j1, j2))
            else:
                refined.append(("delete", i1, i2, j1, j1))
                refined.append(("insert", i2, i2, j1, j2))
            continue

        # ── N-N table pairing theo thứ tự ─────────────────────────────────────
        if (
            len(a_slice) == len(b_slice)
            and len(a_slice) > 0
            and all(b.type == "table" for b in a_slice)
            and all(b.type == "table" for b in b_slice)
        ):
            for k in range(len(a_slice)):
                sim = _block_similarity(a_slice[k], b_slice[k])
                if sim >= 0.45:
                    refined.append(("replace", i1 + k, i1 + k + 1, j1 + k, j1 + k + 1))
                else:
                    refined.append(("delete", i1 + k, i1 + k + 1, j1 + k, j1 + k))
                    refined.append(("insert", i1 + k + 1, i1 + k + 1, j1 + k, j1 + k + 1))
            continue

        # ── Mixed N-M replace → greedy ────────────────────────────────────────
        if len(a_slice) > 0 and len(b_slice) > 0:
            _match_mixed_slice(refined, a_blocks, b_blocks, i1, i2, j1, j2)
            continue

        refined.append((tag, i1, i2, j1, j2))

    # ── FIX OPCODE ORDER BUG ──────────────────────────────────────────────────
    refined.sort(key=_opcode_sort_key)

    return refined


# ══════════════════════════════════════════════════════════════════════════════
# Mixed slice matching
# ══════════════════════════════════════════════════════════════════════════════

def _match_mixed_slice(
    refined: List[Opcode],
    a_blocks: List[Block],
    b_blocks: List[Block],
    i1: int, i2: int,
    j1: int, j2: int,
) -> None:
    """
    Greedy matching cho N-M replace slice.

    FIX EXACT MATCH: exact match trước (dùng _content_sig),
    greedy threshold 0.85 cho phần còn lại.

    Tại sao cần exact match trước:
    - Shape text ngắn → similarity ratio cao dù nội dung khác
      vd: "Bước 1: Kiểm tra" vs "Bước 2: Kiểm tra" → ratio ~0.89
    - Nếu chỉ dùng greedy, shape bị xóa dễ bị pair nhầm với shape còn lại
    - Exact match đảm bảo shape giống hệt nhau luôn được pair đúng trước
      → phần còn lại mới greedy → ít nhầm hơn nhiều

    Giới hạn: shape duplicate hoàn toàn (2 shape cùng text) →
    first-match-wins, không thể biết cái nào bị xóa — mọi thuật toán đều vậy.
    """
    a_slice = a_blocks[i1:i2]
    b_slice = b_blocks[j1:j2]

    matched_a: Set[int] = set()
    matched_b: Set[int] = set()
    pairs: List[Tuple[int, int]] = []

    # ── Bước 1: exact match trước ─────────────────────────────────────────
    # Dùng _content_sig (không có heading_ctx đầy đủ) để stable cross-doc
    a_sigs = [_content_sig(a) for a in a_slice]
    b_sigs = [_content_sig(b) for b in b_slice]

    for ki, a_sig in enumerate(a_sigs):
        for kj, b_sig in enumerate(b_sigs):
            if ki in matched_a or kj in matched_b:
                continue
            if a_sig == b_sig:
                matched_a.add(ki)
                matched_b.add(kj)
                pairs.append((ki, kj))

    # ── Bước 2: greedy cho phần còn lại ───────────────────────────────────
    # Threshold cao hơn vì exact match đã lọc các cặp giống hệt nhau rồi
    # → phần còn lại là các block thực sự khác nhau → cần threshold chặt hơn
    THRESHOLD = 0.85

    candidates: List[Tuple[float, int, int]] = []
    for ki, a in enumerate(a_slice):
        if ki in matched_a:
            continue
        for kj, b in enumerate(b_slice):
            if kj in matched_b:
                continue
            sim = _block_similarity(a, b)
            if sim >= THRESHOLD:
                candidates.append((sim, ki, kj))

    def _tie_key(item):
        sim, ki, kj = item
        ao = a_slice[ki].order or 0
        bo = b_slice[kj].order or 0
        return (-sim, abs(ao - bo), ki, kj)

    candidates.sort(key=_tie_key)

    for sim, ki, kj in candidates:
        if ki in matched_a or kj in matched_b:
            continue
        matched_a.add(ki)
        matched_b.add(kj)
        pairs.append((ki, kj))

    # ── Emit opcodes ───────────────────────────────────────────────────────
    pairs.sort(key=lambda x: x[0])

    for ki, kj in pairs:
        refined.append(("replace", i1 + ki, i1 + ki + 1, j1 + kj, j1 + kj + 1))

    for ki in sorted(ki for ki in range(len(a_slice)) if ki not in matched_a):
        refined.append(("delete", i1 + ki, i1 + ki + 1, j1, j1))

    for kj in sorted(kj for kj in range(len(b_slice)) if kj not in matched_b):
        refined.append(("insert", i2, i2, j1 + kj, j1 + kj + 1))