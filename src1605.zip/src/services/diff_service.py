from __future__ import annotations

from typing import Dict, Any, List

from src.services.extractor.document import extract_doc_tree
from src.services.block.block_builder import build_blocks
from src.services.align.sequence_align import align_blocks
from src.services.serializer.json_builder import build_ui_json


_DISPLAY_TYPE_MAP = {
    "paragraph_modified": "paragraph",
    "paragraph_inserted": "paragraph",
    "paragraph_deleted":  "paragraph",
    "heading_modified":   "heading",
    "heading_inserted":   "heading",
    "heading_deleted":    "heading",
    "table_modified":     "table",
    "table_inserted":     "table",
    "table_deleted":      "table",
    "image_modified":     "image",
    "image_inserted":     "image",
    "image_deleted":      "image",
    "image_added":        "image",
    "shape_modified":     "shape",
    "shape_inserted":     "shape",
    "shape_deleted":      "shape",
}


class DiffService:
    """
    DiffService
    ===========
    Quy ước cực kỳ quan trọng:
    - Thứ tự hiển thị MUST theo seq_index do json_builder sinh ra
    - TUYỆT ĐỐI không sort lại theo order / id trong service layer
    """

    # ── Normalize helpers ──────────────────────────────────────────────────

    def _normalize_change(self, ch: Dict[str, Any], section_heading: str) -> Dict[str, Any]:
        ch_type = ch.get("type", "")
        display_type = (
            _DISPLAY_TYPE_MAP.get(ch_type)
            or ch.get("display_type")
            or ch_type
                .replace("_modified", "")
                .replace("_inserted", "")
                .replace("_deleted", "")
        )

        # order: chỉ là metadata (KHÔNG dùng để sort)
        order = ch.get("order")
        if order is None:
            left  = ch.get("left")  or {}
            right = ch.get("right") or {}
            candidates = []
            if isinstance(left, dict):
                candidates.append(left.get("order"))
            if isinstance(right, dict):
                candidates.append(right.get("order"))
            order = min((o for o in candidates if o is not None), default=0)

        return {
            **ch,
            "heading":      section_heading,
            "order":        order,
            "display_type": display_type,
        }

    def _normalize_section(self, section: Dict[str, Any]) -> Dict[str, Any]:
        heading = section.get("heading") or "(No heading)"
        changes = section.get("changes", []) or []

        # ❗ KHÔNG sort ở đây — giữ nguyên thứ tự seq_index
        normalized_changes = [
            self._normalize_change(ch, heading)
            for ch in changes
        ]

        return {
            "heading": heading,
            "changes": normalized_changes,
        }

    # ── Public API ──────────────────────────────────────────────────────────

    def compare(self, original_path: str, modified_path: str) -> Dict[str, Any]:
        """
        Main entry point:
        - Extract
        - Build blocks
        - Align
        - Build UI JSON (json_builder chịu trách nhiệm thứ tự)
        - Normalize metadata (KHÔNG reorder)
        """

        # 1. Extract DocNode trees
        original_root = extract_doc_tree(original_path)
        modified_root = extract_doc_tree(modified_path)

        # 2. Build blocks
        original_blocks = build_blocks(original_root)
        modified_blocks = build_blocks(modified_root)

        # 3. Align → opcodes
        opcodes = align_blocks(original_blocks, modified_blocks)

        # 4. Build UI JSON (đã sort đúng bằng seq_index)
        result = build_ui_json(original_blocks, modified_blocks, opcodes)

        sections = result.get("sections", []) or []

        # 5. Normalize sections (NO SORT)
        normalized_sections = [
            self._normalize_section(section)
            for section in sections
        ]

        total_changes = sum(
            len(section["changes"]) for section in normalized_sections
        )

        return {
            "original_file":  original_path,
            "modified_file":  modified_path,
            "total_sections": len(normalized_sections),
            "total_changes":  total_changes,
            "sections":       normalized_sections,
        }
