"""
models/docnode.py
~~~~~~~~~~~~~~~~~
Node cơ bản trong cây tài liệu.

Cây có dạng:
    document
    ├── heading
    ├── paragraph (content: text)
               ─ image
    ├── table
    │   └── row
    │       └── cell
    │           ├── paragraph (content: text)
    │           ├          ─ image
    │           └── table          ← nested table
    └── shape
            ├── table
            └── paragraph (content: text)

Quy tắc con hợp lệ (VALID_CHILDREN):
    document  → heading, paragraph, image, table, shape
    table     → row
    row       → cell
    cell      → paragraph, image, table
    shape     → image, paragraph
    paragraph → 
    heading   → 
    image     → 
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

# Các node con hợp lệ cho từng loại node cha
VALID_CHILDREN: Dict[str, set] = {
    "document":  {"heading", "paragraph", "image", "table", "shape"},
    "table":     {"row"},
    "row":       {"cell"},
    "cell":      {"paragraph", "image", "table", "shape"},  # thêm "shape"
    "shape":     {"image", "paragraph", "table"},
    "paragraph": {"image"},
    "heading":   {"image"},
    "image":     set(),
}

@dataclass
class DocNode:
    type: str
    content: Dict[str, Any] = field(default_factory=dict)
    children: List["DocNode"] = field(default_factory=list)

    uid: Optional[str] = None
    parent_uid: Optional[str] = None
    order: int = 0
    path: Optional[str] = None

    parent: Optional["DocNode"] = field(default=None, repr=False, compare=False)

    # ── Validation ────────────────────────────────────────────────────────────

    def __post_init__(self) -> None:
        if not self.type:
            raise ValueError("DocNode.type must not be empty")

    def _assert_valid_child(self, child: "DocNode") -> None:
        """
        Kiểm tra child.type có được phép nằm dưới self.type không.
        Bỏ qua nếu self.type chưa có trong VALID_CHILDREN (extensible).
        """
        allowed = VALID_CHILDREN.get(self.type)
        if allowed is not None and child.type not in allowed:
            raise ValueError(
                f"'{child.type}' không được phép là con của '{self.type}'. "
                f"Hợp lệ: {allowed or 'không có (leaf node)'}"
            )

    # ── Tree manipulation ─────────────────────────────────────────────────────

    def add_child(self, child: "DocNode") -> None:
        """Thêm node con, tự set parent và parent_uid."""
        if not isinstance(child, DocNode):
            raise TypeError(f"Expected DocNode, got {type(child)}")
        self._assert_valid_child(child)
        child.parent = self
        child.parent_uid = self.uid
        self.children.append(child)

    def is_leaf(self) -> bool:
        return len(self.children) == 0

    # ── Helpers theo cấu trúc thực tế ────────────────────────────────────────

    @property
    def text(self) -> str:
        """Shortcut lấy text từ paragraph / heading / shape>paragraph."""
        return self.content.get("text", "")

    def iter_tables(self) -> Iterator["DocNode"]:
        """Trả về tất cả table (kể cả nested) trong cây."""
        return self.find("table")

    def iter_images(self) -> Iterator["DocNode"]:
        """Trả về tất cả image trong cây."""
        return self.find("image")

    def iter_cells(self) -> Iterator["DocNode"]:
        """Trả về tất cả cell trong cây."""
        return self.find("cell")

    # ── Traversal ─────────────────────────────────────────────────────────────

    def walk(self) -> Iterator["DocNode"]:
        """DFS generator — không build toàn bộ list trong memory."""
        yield self
        for child in self.children:
            yield from child.walk()

    def find(self, type: str) -> Iterator["DocNode"]:
        """Lọc node theo type trong toàn bộ cây."""
        for node in self.walk():
            if node.type == type:
                yield node

    # ── Equality ──────────────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DocNode):
            return NotImplemented
        if self.uid and other.uid:
            return self.uid == other.uid
        return self is other

    def __hash__(self) -> int:
        return hash(self.uid) if self.uid else id(self)

    # ── Serialization ─────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uid":        self.uid,
            "parent_uid": self.parent_uid,
            "order":      self.order,
            "path":       self.path,
            "type":       self.type,
            "content":    self.content,
            "children":   [c.to_dict() for c in self.children],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DocNode":
        node = cls(
            type=data["type"],
            content=data.get("content", {}),
            uid=data.get("uid"),
            parent_uid=data.get("parent_uid"),
            order=data.get("order", 0),
            path=data.get("path"),
        )
        for child_data in data.get("children", []):
            node.add_child(cls.from_dict(child_data))
        return node

    # ── Debug ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"DocNode("
            f"type={self.type!r}, "
            f"uid={self.uid!r}, "
            f"order={self.order}, "
            f"children={len(self.children)}"
            f")"
        )