"""
serializer/json_builder.py

Build UI JSON từ aligned block opcodes.

Schema nhất quán cho mọi change object:
──────────────────────────────────────────────────────────────────────────────
{
  id, heading, type, change_kind, order, seq_index,

  left:  _serialize_block_side(a)   ← luôn dùng hàm này cho MỌI type
  right: _serialize_block_side(b)   ← kể cả image, shape

  # Per-type extra fields (không thay thế left/right):
  word_diff        : paragraph_modified / heading_modified
  old_level        : heading_modified
  new_level        : heading_modified
  level_changed    : heading_modified
  table_analysis   : table_modified / table_inserted / table_deleted
  shape_changes    : shape_modified (list từ diff_shape)
  shape_cleared    : shape_modified
  shape_text_preview: shape_modified / shape_inserted / shape_deleted
  image_change     : image_modified / image_inserted / image_deleted
  left_img         : image_modified / image_deleted   (= _image_payload(a))
  right_img        : image_modified / image_inserted  (= _image_payload(b))
  left_context     : { previous, next }
  right_context    : { previous, next }
}

Fixes so với v4:
1. image_inserted.right dùng _serialize_block_side — nhất quán với mọi type khác.
   image_url vẫn được bubble qua right_img trong extra.
2. _process_paragraph kiểm tra ảnh inline: text + ảnh đều giống → skip.
3. seq cho pure insert dùng i1 * _SEQ_MULT + j thay vì + (j - j1)
   → tránh collision khi nhiều insert liên tiếp cùng i1.
4. Sort toàn bộ refined opcode theo (i1, j1) trước khi process
   → đảm bảo seq tăng dần tuyệt đối, khớp với fix trong sequence_align.py.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from src.services.models.block import Block
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.table.table_diff import diff_table
from src.services.diff.table.table_analyze import analyze_table_change
from src.services.diff.table.table_serialize import serialize_full_table, get_header_row
from src.services.diff.shape_diff import diff_shape
from src.services.diff.image_diff import images_equal, build_image_change, _image_payload
from src.services.extractor.utils import norm_text as _norm

_SEQ_MULT = 100_000


# ══════════════════════════════════════════════════════════════════════════════
# Text helpers
# ══════════════════════════════════════════════════════════════════════════════

def _display_text(content: dict) -> str:
    return (content.get("text_display") or content.get("text") or "").strip()


# ══════════════════════════════════════════════════════════════════════════════
# Node serializer
# Khớp với table_serialize.serialize_node và image_diff._image_payload:
#   - Loại raw_bytes, data_uri khỏi content
#   - Bubble image_url + image{} lên top-level cho node type="image"
# ══════════════════════════════════════════════════════════════════════════════

def _serialize_node(node) -> Optional[Dict[str, Any]]:
    if not node:
        return None

    content = getattr(node, "content", {}) or {}

    safe_content = {
        k: v for k, v in content.items()
        if k not in ("raw_bytes", "data_uri")
    }

    out: Dict[str, Any] = {
        "uid":      getattr(node, "uid", None),
        "type":     getattr(node, "type", None),
        "content":  safe_content,
        "children": [_serialize_node(c) for c in (getattr(node, "children", []) or [])],
    }

    if out["type"] == "image":
        out["image_url"] = content.get("image_url")
        out["image"] = {
            "image_url":  content.get("image_url"),
            "width_px":   round((content.get("width_emu", 0) or 0) * 96 / 914400) or None,
            "height_px":  round((content.get("height_emu", 0) or 0) * 96 / 914400) or None,
            "mime":       content.get("mime"),
            "sha256":     content.get("sha256"),
            "floating":   content.get("floating", False),
        }

    return out


# ══════════════════════════════════════════════════════════════════════════════
# Block serializers
# ══════════════════════════════════════════════════════════════════════════════

def _serialize_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    """
    Serialize 1 block thành side object.

    Dùng cho MỌI change type — kể cả image và shape.
    Frontend đọc left/right qua schema này, đọc image_url từ extra.left_img/right_img.
    """
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
        "node":         _serialize_node(block.node),
    }


def _ctx_item(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None
    return {
        "uid":          block.uid,
        "type":         block.type,
        "order":        block.order,
        "heading":      block.heading_ctx,
        "preview_text": block.preview_text,
    }


def _build_context(blocks: List[Block], index: int) -> Dict[str, Any]:
    return {
        "previous": _ctx_item(blocks[index - 1] if index > 0               else None),
        "next":     _ctx_item(blocks[index + 1] if index + 1 < len(blocks) else None),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Shape serializer
# ══════════════════════════════════════════════════════════════════════════════

def _collect_shape_text_lines(node) -> List[str]:
    lines: List[str] = []
    for child in (getattr(node, "children", []) or []):
        t = getattr(child, "type", None)
        if t == "paragraph":
            content = getattr(child, "content", {}) or {}
            txt = _display_text(content)
            if txt:
                lines.append(txt)
        elif t == "shape":
            lines.extend(_collect_shape_text_lines(child))
        elif t == "table":
            for row in (getattr(child, "children", []) or []):
                if getattr(row, "type", None) != "row":
                    continue
                cell_texts = []
                for cell in (getattr(row, "children", []) or []):
                    if getattr(cell, "type", None) != "cell":
                        continue
                    content = getattr(cell, "content", {}) or {}
                    ct = _display_text(content)
                    if ct:
                        cell_texts.append(ct)
                if cell_texts:
                    lines.append(" | ".join(cell_texts))
        elif t == "image":
            lines.append("[Image]")
    return lines


def _collect_shape_images(node) -> List[Dict[str, Any]]:
    imgs = []
    px = 96 / 914400
    for ch in (getattr(node, "children", []) or []):
        t = getattr(ch, "type", None)

        if t == "image":
            content = getattr(ch, "content", {}) or {}
            imgs.append({
                "image_url": content.get("image_url"),
                "width_px":  round((content.get("width_emu", 0) or 0) * px) or None,
                "height_px": round((content.get("height_emu", 0) or 0) * px) or None,
                "mime":      content.get("mime"),
                "sha256":    content.get("sha256"),
            })

        elif t == "paragraph":
            # ảnh nằm trong paragraph.children
            for gc in (getattr(ch, "children", []) or []):
                if getattr(gc, "type", None) == "image":
                    content = getattr(gc, "content", {}) or {}
                    imgs.append({
                        "image_url": content.get("image_url"),
                        "width_px":  round((content.get("width_emu", 0) or 0) * px) or None,
                        "height_px": round((content.get("height_emu", 0) or 0) * px) or None,
                        "mime":      content.get("mime"),
                        "sha256":    content.get("sha256"),
                    })

        else:
            # shape lồng nhau, table → đệ quy
            imgs.extend(_collect_shape_images(ch))

    return imgs

def _serialize_shape_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    """
    Serialize shape block — extends _serialize_block_side với shape_text_lines
    và shape_images để frontend render preview mà không cần walk tree.
    """
    if not block:
        return None
    base = _serialize_block_side(block)
    if base is None:
        return None

    lines = _collect_shape_text_lines(block.node)

    if not lines:
        content   = block.node.content or {}
        img_count = content.get("image_count", 0) or 0
        tbl_count = content.get("table_count", 0) or 0
        preview   = []
        if img_count:
            preview.append(f"Image × {img_count}")
        if tbl_count:
            preview.append(f"Table × {tbl_count}")
        lines = [f"[{' , '.join(preview)}]"] if preview else ["[Empty shape]"]

    base["shape_text_lines"] = lines
    base["shape_images"]     = _collect_shape_images(block.node)
    return base


# ══════════════════════════════════════════════════════════════════════════════
# Shape content helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_has_text(block: Block) -> bool:
    def _check(node) -> bool:
        for child in (getattr(node, "children", []) or []):
            if getattr(child, "type", None) == "paragraph":
                if _norm((getattr(child, "content", {}) or {}).get("text", "")):
                    return True
            elif getattr(child, "type", None) == "shape":
                if _check(child):
                    return True
        return False
    return _check(block.node)


def _shape_has_content(block: Block) -> bool:
    return bool(getattr(block.node, "children", None))


# ══════════════════════════════════════════════════════════════════════════════
# Section key
# ══════════════════════════════════════════════════════════════════════════════

def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


# ══════════════════════════════════════════════════════════════════════════════
# Change builder
# ══════════════════════════════════════════════════════════════════════════════

def _change_kind(left: Any, right: Any) -> str:
    if left is not None and right is None:
        return "delete"
    if left is None and right is not None:
        return "insert"
    return "replace"


def _make_change(
    cid:         int,
    change_type: str,
    heading:     Optional[str],
    order:       int,
    left:        Optional[Dict[str, Any]],
    right:       Optional[Dict[str, Any]],
    extra:       Optional[Dict[str, Any]] = None,
    seq_index:   int = 0,
) -> Dict[str, Any]:
    return {
        "id":          cid,
        "heading":     heading,
        "type":        change_type,
        "change_kind": _change_kind(left, right),
        "order":       order,
        "seq_index":   seq_index,
        "left":        left,
        "right":       right,
        **(extra or {}),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Per-type processors
# ══════════════════════════════════════════════════════════════════════════════

def _process_paragraph(cid, a, b, ai, bj, a_blocks, b_blocks):
    """
    Emit khi text HOẶC ảnh inline thay đổi.

    FIX: trước chỉ check text — bỏ sót paragraph chỉ thay đổi ảnh inline.
    """
    old_raw     = a.node.content.get("text", "")
    new_raw     = b.node.content.get("text", "")
    old_display = a.node.content.get("text_display") or old_raw
    new_display = b.node.content.get("text_display") or new_raw

    text_same = _norm(old_raw) == _norm(new_raw)

    # Kiểm tra ảnh inline trong paragraph (children type=image)
    a_imgs = [c for c in (a.node.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.node.children or []) if c.type == "image"]
    imgs_same = (
        len(a_imgs) == len(b_imgs)
        and all(images_equal(ai_img, bi_img) for ai_img, bi_img in zip(a_imgs, b_imgs))
    )

    if text_same and imgs_same:
        return None

    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)
    return _make_change(
        cid=cid, change_type="paragraph_modified", heading=heading, order=order,
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw, old_display=old_display, new_display=new_display),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_heading(cid, a, b, ai, bj, a_blocks, b_blocks):
    old_raw   = a.node.content.get("text", "")
    new_raw   = b.node.content.get("text", "")
    old_norm  = _norm(old_raw)
    new_norm  = _norm(new_raw)
    old_level = int(a.node.content.get("level", 1) or 1)
    new_level = int(b.node.content.get("level", 1) or 1)
    if old_norm == new_norm and old_level == new_level:
        return None
    heading = a.heading_ctx or b.heading_ctx
    order   = min(a.order, b.order)
    return _make_change(
        cid=cid, change_type="heading_modified", heading=heading, order=order,
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "word_diff":     diff_words(old_raw, new_raw) if old_norm != new_norm else None,
            "old_level":     old_level,
            "new_level":     new_level,
            "level_changed": old_level != new_level,
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_table(cid, a, b, ai, bj, a_blocks, b_blocks):
    """
    Gọi diff_table() + analyze_table_change().
    analyze_table_change chịu trách nhiệm toàn bộ:
      render_mode, structure_changed, full_table_original/modified,
      added_rows, deleted_rows, table_changes, row_states.
    Trả None nếu không có thay đổi thật sự.
    """
    table_changes = diff_table(a.node, b.node)
    analysis      = analyze_table_change(a_tbl=a.node, b_tbl=b.node, table_changes=table_changes)
    if analysis is None:
        return None

    heading = a.heading_ctx or b.heading_ctx
    return _make_change(
        cid=cid, change_type="table_modified", heading=heading,
        order=min(a.order, b.order),
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "table_analysis": analysis,
            "left_context":   _build_context(a_blocks, ai),
            "right_context":  _build_context(b_blocks, bj),
        },
    )


def _process_shape(cid, a, b, ai, bj, a_blocks, b_blocks):
    a_has_text    = _shape_has_text(a)
    b_has_text    = _shape_has_text(b)
    a_has_content = _shape_has_content(a)
    b_has_content = _shape_has_content(b)

    # Cả 2 rỗng hoàn toàn (không text, không children) → không emit
    if not a_has_text and not b_has_text and not a_has_content and not b_has_content:
        return None

    left_side  = _serialize_shape_side(a)
    right_side = _serialize_shape_side(b)
    heading    = a.heading_ctx or b.heading_ctx
    order      = min(a.order, b.order)

    shape_changes = diff_shape(a.node, b.node)

    # Shape có content (text hoặc ảnh) ở cả 2 phía nhưng diff rỗng → unchanged
    if a_has_content and b_has_content and not shape_changes:
        return None

    return _make_change(
        cid=cid, change_type="shape_modified", heading=heading, order=order,
        left=left_side, right=right_side,
        extra={
            # shape_cleared=True khi A có text nhưng B không còn text
            "shape_cleared":      a_has_text and not b_has_text,
            "shape_changes":      shape_changes,
            "shape_text_preview": (left_side or {}).get("shape_text_lines", []),
            "left_context":       _build_context(a_blocks, ai),
            "right_context":      _build_context(b_blocks, bj),
        },
    )


def _process_image(cid, a, b, ai, bj, a_blocks, b_blocks):
    if images_equal(a.node, b.node):
        return None
    heading    = a.heading_ctx or b.heading_ctx
    img_change = build_image_change(a.node, b.node)
    return _make_change(
        cid=cid, change_type="image_modified", heading=heading,
        order=min(a.order, b.order),
        left=_serialize_block_side(a), right=_serialize_block_side(b),
        extra={
            "image_change": img_change,
            "left_img":     _image_payload(a.node, include_data=True),
            "right_img":    _image_payload(b.node, include_data=True),
            "left_context":  _build_context(a_blocks, ai),
            "right_context": _build_context(b_blocks, bj),
        },
    )


def _process_insert(cid, b, bj, b_blocks):
    """
    Emit change cho block mới (chỉ có ở B).

    FIX: right luôn dùng _serialize_block_side/_serialize_shape_side
    → schema nhất quán với mọi change type khác.
    image_url của ảnh được đưa vào extra.right_img riêng.
    """
    # Shape rỗng hoàn toàn → không emit
    if b.type == "shape" and not _shape_has_text(b) and not _shape_has_content(b):
        return None

    if b.type == "shape":
        right_side = _serialize_shape_side(b)
    else:
        right_side = _serialize_block_side(b)

    extra: Dict[str, Any] = {
        "left_context":  None,
        "right_context": _build_context(b_blocks, bj),
    }

    if b.type == "table":
        extra["table_analysis"] = analyze_table_change(
            a_tbl=None, b_tbl=b.node, table_changes=[]
        )

    elif b.type == "shape":
        extra["shape_text_preview"] = (right_side or {}).get("shape_text_lines", [])

    elif b.type == "image":
        img_change = build_image_change(None, b.node)
        extra["image_change"] = img_change
        extra["right_img"]    = _image_payload(b.node, include_data=True)

    return _make_change(
        cid=cid, change_type=f"{b.type}_inserted",
        heading=b.heading_ctx, order=b.order,
        left=None, right=right_side, extra=extra,
    )


def _process_delete(cid, a, ai, a_blocks):
    """
    Emit change cho block bị xóa (chỉ có ở A).
    """
    # Shape rỗng hoàn toàn → không emit
    if a.type == "shape" and not _shape_has_text(a) and not _shape_has_content(a):
        return None

    if a.type == "shape":
        left_side = _serialize_shape_side(a)
    else:
        left_side = _serialize_block_side(a)

    extra: Dict[str, Any] = {
        "left_context":  _build_context(a_blocks, ai),
        "right_context": None,
    }

    if a.type == "table":
        extra["table_analysis"] = analyze_table_change(
            a_tbl=a.node, b_tbl=None, table_changes=[]
        )

    elif a.type == "shape":
        extra["shape_text_preview"] = (left_side or {}).get("shape_text_lines", [])

    elif a.type == "image":
        img_change = build_image_change(a.node, None)
        extra["image_change"] = img_change
        extra["left_img"]     = _image_payload(a.node, include_data=True)

    return _make_change(
        cid=cid, change_type=f"{a.type}_deleted",
        heading=a.heading_ctx, order=a.order,
        left=left_side, right=None, extra=extra,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Main builder
# ══════════════════════════════════════════════════════════════════════════════

def build_ui_json(
    a_blocks: List[Block],
    b_blocks: List[Block],
    opcodes,
) -> Dict[str, Any]:
    """
    Build UI JSON từ aligned block opcodes.

    Pipeline:
    1. Sort opcodes theo (i1, j1) trước khi process — đảm bảo seq tăng dần
       tuyệt đối, bổ sung cho sort trong sequence_align.align_blocks.
    2. Gom tất cả (seq, change) vào global_pending.
    3. Sort global_pending theo seq một lần duy nhất.
    4. Gán id sau sort → id luôn tương quan đúng với thứ tự hiển thị.

    seq formula:
      replace / delete : i1 * _SEQ_MULT + k          (k = offset trong slice)
      pure insert      : i1 * _SEQ_MULT + j           (j = index trong b_blocks)
      leftover insert  : (i2-1)*_SEQ_MULT + _SEQ_MULT//2 + (j - (j1+pairs))

    FIX vs v4:
    - pure insert: dùng + j (không phải + (j-j1)) → tránh collision seq khi
      nhiều insert ở vị trí khác nhau có cùng i1.
    - opcodes được sort trước khi process → seq tăng dần đảm bảo.
    """
    # Sort opcodes theo (i1, j1) để seq tăng dần tuyệt đối
    opcodes = sorted(opcodes, key=lambda op: (op[1], op[3]))

    global_pending: List[Tuple[int, Dict[str, Any]]] = []

    def _collect(change: Optional[Dict[str, Any]], seq: int) -> None:
        if change is not None:
            global_pending.append((seq, change))

    for tag, i1, i2, j1, j2 in opcodes:

        if tag == "equal":
            continue

        # ── INSERT ────────────────────────────────────────────────────────────
        # FIX: dùng + j thay vì + (j - j1) để seq unique khi nhiều insert
        if tag == "insert":
            for j in range(j1, j2):
                seq    = i1 * _SEQ_MULT + j
                change = _process_insert(0, b_blocks[j], j, b_blocks)
                _collect(change, seq)

        # ── DELETE ────────────────────────────────────────────────────────────
        elif tag == "delete":
            for i in range(i1, i2):
                seq    = i * _SEQ_MULT
                change = _process_delete(0, a_blocks[i], i, a_blocks)
                _collect(change, seq)

        # ── REPLACE ───────────────────────────────────────────────────────────
        elif tag == "replace":
            a_slice = a_blocks[i1:i2]
            b_slice = b_blocks[j1:j2]
            pairs   = min(len(a_slice), len(b_slice))

            # Paired 1-1
            for k in range(pairs):
                ai  = i1 + k
                bj  = j1 + k
                a   = a_blocks[ai]
                b   = b_blocks[bj]
                seq = ai * _SEQ_MULT

                change: Optional[Dict[str, Any]] = None

                if a.type == "paragraph" and b.type == "paragraph":
                    change = _process_paragraph(0, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "heading" and b.type == "heading":
                    change = _process_heading(0, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "table" and b.type == "table":
                    change = _process_table(0, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "shape" and b.type == "shape":
                    change = _process_shape(0, a, b, ai, bj, a_blocks, b_blocks)
                elif a.type == "image" and b.type == "image":
                    change = _process_image(0, a, b, ai, bj, a_blocks, b_blocks)
                else:
                    # Type mismatch (vd: paragraph → table, image → paragraph)
                    # Xử lý như delete + insert riêng để frontend biết đây là 2 block khác loại
                    del_change = _process_delete(0, a, ai, a_blocks)
                    ins_change = _process_insert(0, b, bj, b_blocks)
                    _collect(del_change, seq)
                    _collect(ins_change, seq + 1)
                    continue

                _collect(change, seq)

            # Leftover delete (a dư)
            for i in range(i1 + pairs, i2):
                seq    = i * _SEQ_MULT
                change = _process_delete(0, a_blocks[i], i, a_blocks)
                _collect(change, seq)

            # Leftover insert (b dư) — anchor sau a_slice cuối
            anchor = (i2 - 1) * _SEQ_MULT + _SEQ_MULT // 2
            for j in range(j1 + pairs, j2):
                seq    = anchor + (j - (j1 + pairs))
                change = _process_insert(0, b_blocks[j], j, b_blocks)
                _collect(change, seq)

    # ── Sort theo seq, gán id sau ─────────────────────────────────────────────
    global_pending.sort(key=lambda x: x[0])

    flat_changes:    List[Dict[str, Any]] = []
    ordered_sections: List[Dict[str, Any]] = []
    last_heading:    Optional[str]        = None
    current_section: Optional[Dict[str, Any]] = None

    for cid, (seq, change) in enumerate(global_pending, start=1):
        change["id"]        = cid
        change["seq_index"] = seq

        heading = _section_key(change.get("heading"))

        if current_section is None or heading != last_heading:
            current_section = {"heading": heading, "changes": []}
            ordered_sections.append(current_section)
            last_heading = heading

        current_section["changes"].append(change)
        flat_changes.append(change)

    sort_key = lambda x: (x.get("seq_index", 0), x.get("id", 0))
    for section in ordered_sections:
        section["changes"].sort(key=sort_key)

    return {
        "sections": ordered_sections,
        "changes":  sorted(flat_changes, key=sort_key),
    }