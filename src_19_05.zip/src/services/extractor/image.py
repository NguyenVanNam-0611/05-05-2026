"""
extractor/image.py
~~~~~~~~~~~~~~~~~~
Extract ảnh từ một Paragraph.

Xử lý:
    ✅ Ảnh inline  (<wp:inline>) — nằm trong dòng chữ
    ✅ Ảnh anchor  (<wp:anchor>) có a:blip — floating image (Win32com convert từ .doc)
    ✅ Ảnh inline trong cell (table.py gọi hàm này cho mỗi paragraph trong cell)
    ✅ Ảnh trong textbox/shape (shape.py gọi extract_images_from_p_xml)
    ✅ OLE Object (w:object) — thumbnail PNG/EMF nhúng từ CorelDRAW, Visio, v.v.
       Treat như ảnh bình thường để hiển thị và diff được.

Không xử lý:
    ❌ Ảnh anchor không có a:blip — đây là shape/textbox, không phải ảnh
    ❌ Ảnh trong header / footer
    ❌ File OLE gốc (CorelDRAW .cdr, Visio .vsd...) — chỉ lấy thumbnail preview

Thay đổi so với cũ:
    - Thêm _extract_ole_images_from_run: extract thumbnail từ w:object/v:imagedata
    - extract_images_from_p_xml gọi OLE extractor ở cả 2 nhánh (có run / không có run)
    - OLE được nhận dạng qua w:object tag, không nhầm với w:pict (VML thuần)
    - extra={"ole": True} trong content để caller biết đây là OLE thumbnail nếu cần
    - Bỏ data_uri khỏi content — không encode base64 tại extract time
    - Lưu raw_bytes vào content để pipeline sau dùng (lazy encode)
    - image_store.save_image() lưu file ra /tmp — serve qua URL tĩnh
    - Fix EMF convert bị gọi 2 lần (lần 2 là dead code)
    - Tách core logic thành extract_images_from_p_xml(p_xml, part, ...)
      để shape.py dùng chung — tránh duplicate và đảm bảo VML/EMF/image_url
      được xử lý đúng cho ảnh trong textbox.
"""

from __future__ import annotations

import threading
from typing import Any, Dict, List, Optional

from docx.text.paragraph import Paragraph
from lxml import etree

from src.services.models.docnode import DocNode
from src.services.extractor.utils import OrderRef, next_order
from src.services.utils.hash import safe_sha256
from src.services.utils.image_store import save_image

# ── Namespaces ────────────────────────────────────────────────────────────────

_NS: Dict[str, str] = {
    "a":  "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r":  "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "w":  "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "v":  "urn:schemas-microsoft-com:vml",
    "o":  "urn:schemas-microsoft-com:office:office",
}

_R_EMBED = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
_O_TITLE = "{urn:schemas-microsoft-com:office:office}title"
_W_DXA   = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}dxaOrig"
_W_DYA   = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}dyaOrig"

# 1 twip = 635 EMU  (twip = 1/1440 inch, EMU = 1/914400 inch → 914400/1440 = 635)
_TWIPS_TO_EMU = 635


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _pure(elm):
    """
    Chuyển BaseOxmlElement về lxml element thuần.
    python-docx 1.2.0 override .xpath() và không nhận tham số 'namespaces'
    nên phải serialize → parse lại để bypass.
    """
    return etree.fromstring(etree.tostring(elm))


def _get_image_size(drawing_elm) -> tuple[int, int]:
    extents = drawing_elm.xpath(".//wp:inline/wp:extent", namespaces=_NS)
    if not extents:
        extents = drawing_elm.xpath(".//wp:anchor/wp:extent", namespaces=_NS)
    if not extents:
        return 0, 0
    ext = extents[0]
    return _emu_to_int(ext.get("cx")), _emu_to_int(ext.get("cy"))


def _get_alt_text(drawing_elm) -> str:
    doc_prs = drawing_elm.xpath(".//wp:inline/wp:docPr", namespaces=_NS)
    if not doc_prs:
        doc_prs = drawing_elm.xpath(".//wp:anchor/wp:docPr", namespaces=_NS)
    if not doc_prs:
        return ""
    doc_pr = doc_prs[0]
    return doc_pr.get("descr") or doc_pr.get("title") or ""


def _is_anchor(drawing_elm) -> bool:
    return bool(drawing_elm.xpath("wp:anchor", namespaces=_NS))


def _parse_vml_size(style: str) -> tuple[int, int]:
    PT_TO_EMU = 12700
    width_emu = height_emu = 0
    for part in style.split(";"):
        part = part.strip()
        if part.startswith("width:"):
            val = part[6:].replace("pt", "").strip()
            try:
                width_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
        elif part.startswith("height:"):
            val = part[7:].replace("pt", "").strip()
            try:
                height_emu = int(float(val) * PT_TO_EMU)
            except ValueError:
                pass
    return width_emu, height_emu


def _check_wand_available() -> bool:
    """Kiểm tra wand + ImageMagick DLL có sẵn không — chỉ chạy 1 lần."""
    try:
        from wand.api import library  # noqa: F401 — trigger DLL load
        return True
    except Exception:
        return False

# Check một lần khi module load — không spam log mỗi lần convert
_WAND_AVAILABLE: bool = _check_wand_available()
if not _WAND_AVAILABLE:
    print("[EMF_CONVERT] wand/ImageMagick không khả dụng — dùng GDI32 fallback")


def _convert_emf_to_png(blob: bytes) -> Optional[bytes]:
    # ── Wand (ImageMagick) — ưu tiên cao nhất, kết quả ổn định hơn GDI32 ──────
    if _WAND_AVAILABLE:
        try:
            from wand.image import Image as WandImage
            with WandImage(blob=blob, format="emf") as img:
                img.format = "png"
                result = img.make_blob("png")
                if result:
                    return result
        except Exception as e:
            print(f"[EMF_CONVERT] wand fail: {e}")

    # ── GDI32 fallback (Windows only) ─────────────────────────────────────────
    try:
        import tempfile, os, io, time, ctypes
        from ctypes import wintypes
        from PIL import Image

        gdi32  = ctypes.windll.gdi32
        user32 = ctypes.windll.user32

        with tempfile.NamedTemporaryFile(suffix=".emf", delete=False) as f:
            f.write(blob)
            emf_path = f.name

        hemf = None
        try:
            hemf = gdi32.GetEnhMetaFileW(emf_path)
            if not hemf:
                raise RuntimeError("GetEnhMetaFileW failed")

            class ENHMETAHEADER(ctypes.Structure):
                _fields_ = [
                    ("iType",          ctypes.c_uint),
                    ("nSize",          ctypes.c_uint),
                    ("rclBounds",      ctypes.c_long * 4),
                    ("rclFrame",       ctypes.c_long * 4),
                    ("dSignature",     ctypes.c_uint),
                    ("nVersion",       ctypes.c_uint),
                    ("nBytes",         ctypes.c_uint),
                    ("nRecords",       ctypes.c_uint),
                    ("nHandles",       ctypes.c_ushort),
                    ("sReserved",      ctypes.c_ushort),
                    ("nDescription",   ctypes.c_uint),
                    ("offDescription", ctypes.c_uint),
                    ("nPalEntries",    ctypes.c_uint),
                    ("szlDevice",      ctypes.c_long * 2),
                    ("szlMillimeters", ctypes.c_long * 2),
                ]

            header = ENHMETAHEADER()
            gdi32.GetEnhMetaFileHeader(hemf, ctypes.sizeof(header), ctypes.byref(header))

            w = max(header.rclBounds[2] - header.rclBounds[0], 1)
            h = max(header.rclBounds[3] - header.rclBounds[1], 1)
            if w <= 1 or h <= 1:
                w = max(int((header.rclFrame[2] - header.rclFrame[0]) * 96 / 2540), 100)
                h = max(int((header.rclFrame[3] - header.rclFrame[1]) * 96 / 2540), 100)

            hdc  = user32.GetDC(0)
            hmdc = gdi32.CreateCompatibleDC(hdc)
            hbmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
            gdi32.SelectObject(hmdc, hbmp)

            WHITE_BRUSH = 0
            hbrush = gdi32.GetStockObject(WHITE_BRUSH)
            rect   = (ctypes.c_long * 4)(0, 0, w, h)
            user32.FillRect(hmdc, rect, hbrush)

            rect2 = (ctypes.c_long * 4)(0, 0, w, h)
            gdi32.PlayEnhMetaFile(hmdc, hemf, rect2)

            class BITMAP(ctypes.Structure):
                _fields_ = [
                    ("bmType",       ctypes.c_long),
                    ("bmWidth",      ctypes.c_long),
                    ("bmHeight",     ctypes.c_long),
                    ("bmWidthBytes", ctypes.c_long),
                    ("bmPlanes",     ctypes.c_ushort),
                    ("bmBitsPixel",  ctypes.c_ushort),
                    ("bmBits",       ctypes.c_void_p),
                ]

            bmp = BITMAP()
            gdi32.GetObjectW(hbmp, ctypes.sizeof(bmp), ctypes.byref(bmp))
            bmpstr_size = bmp.bmWidthBytes * bmp.bmHeight
            bmpstr = (ctypes.c_char * bmpstr_size)()
            gdi32.GetBitmapBits(hbmp, bmpstr_size, bmpstr)

            img = Image.frombuffer(
                "RGB", (bmp.bmWidth, bmp.bmHeight),
                bytes(bmpstr), "raw", "BGRX", 0, 1
            )

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()

        finally:
            if hemf:
                gdi32.DeleteEnhMetaFile(hemf)
            try:
                gdi32.DeleteObject(hbmp)
            except Exception:
                pass
            try:
                gdi32.DeleteDC(hmdc)
            except Exception:
                pass
            try:
                user32.ReleaseDC(0, hdc)
            except Exception:
                pass

            for attempt in range(5):
                try:
                    os.unlink(emf_path)
                    break
                except PermissionError:
                    if attempt < 4:
                        time.sleep(0.1)

    except Exception as e:
        print(f"[EMF_CONVERT] gdi32 fail: {e}")
        return None


_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"

# ── EMF in-memory cache ───────────────────────────────────────────────────────
# GDI32 convert không deterministic — cùng 1 EMF có thể ra PNG khác nhau mỗi lần
# → cache kết quả theo sha256 của EMF gốc để đảm bảo 1 file EMF = 1 PNG duy nhất
# → tránh tạo ra 2 file cache khác sha256 cho cùng 1 ảnh
_emf_cache: Dict[str, bytes] = {}
_emf_cache_lock = threading.Lock()


def _is_valid_png(blob: bytes) -> bool:
    """PNG hợp lệ: đúng magic header và đủ lớn để chứa ít nhất IHDR chunk."""
    return len(blob) >= 67 and blob[:8] == _PNG_MAGIC


def _convert_emf_to_png_cached(blob: bytes) -> Optional[bytes]:
    """
    Convert EMF → PNG với in-memory cache theo sha256 của EMF gốc.

    Tại sao cần cache:
        GDI32 (PlayEnhMetaFile + GetBitmapBits) không deterministic —
        cùng 1 file EMF có thể ra bitmap bytes khác nhau mỗi lần gọi
        do GDI rendering state, font hinting, v.v.
        → 2 lần convert = 2 PNG blob khác sha256 = 2 file cache riêng
        → 1 cái đúng, 1 cái trắng/corrupt → frontend thấy ảnh trắng

    Cache trong memory (process lifetime) đảm bảo:
        - Cùng EMF → cùng PNG blob → cùng sha256 → 1 file cache duy nhất
        - Convert chỉ xảy ra 1 lần duy nhất per process restart
    """
    key = safe_sha256(blob)

    with _emf_cache_lock:
        cached = _emf_cache.get(key)
        if cached is not None:
            return cached

    result = _convert_emf_to_png(blob)

    if result and _is_valid_png(result):
        with _emf_cache_lock:
            _emf_cache[key] = result
        return result

    return None


def _normalize_blob(blob: bytes, mime: str) -> tuple[bytes, str]:
    """
    Nếu mime là EMF/WMF thì convert sang PNG qua cached converter.

    Nếu convert thất bại hoặc output không hợp lệ:
        - Trả blob gốc + mime gốc (EMF/WMF)
        - image_store sẽ reject file nếu magic bytes sai
        - Lần sau gọi lại sẽ thử convert lại
    """
    if mime in ("image/x-emf", "image/emf", "image/wmf", "image/x-wmf"):
        converted = _convert_emf_to_png_cached(blob)
        if converted:
            return converted, "image/png"
        print(f"[EMF_CONVERT] output invalid hoặc None, giữ nguyên EMF mime={mime}")
    return blob, mime


def _build_image_content(
    blob:       bytes,
    mime:       str,
    rid:        str,
    width_emu:  int,
    height_emu: int,
    alt_text:   str,
    floating:   bool,
    run_index:  int,
    draw_index: int,
    blip_index: int,
    extra:      Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Tạo content dict cho DocNode(type="image").

    Lưu raw_bytes để pipeline sau (image_diff, perceptual hash) dùng.
    Gọi save_image() để lưu file ra /tmp — trả về image_url.
    KHÔNG lưu data_uri — frontend dùng image_url để fetch.
    """
    sha256    = safe_sha256(blob)
    image_url = save_image(sha256, blob, mime)

    content: Dict[str, Any] = {
        "rid":        rid,
        "hash":       sha256,
        "sha256":     sha256,
        "mime":       mime,
        "width_emu":  width_emu,
        "height_emu": height_emu,
        "alt_text":   alt_text,
        "image_url":  image_url,
        "raw_bytes":  blob,
        "floating":   floating,
        "run_index":  run_index,
        "draw_index": draw_index,
        "blip_index": blip_index,
    }
    if extra:
        content.update(extra)
    return content


# ══════════════════════════════════════════════════════════════════════════════
# VML extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_vml_images_from_run(
    r_pure,
    part,
    uid_prefix: str,
    run_idx: int,
    parent_uid: Optional[str],
    order_ref: Optional[OrderRef],
) -> List[DocNode]:
    """Extract VML images từ 1 run element (lxml thuần) + part.

    Chỉ xử lý w:pict trực tiếp — KHÔNG đụng w:object (để OLE extractor xử lý).
    """
    nodes: List[DocNode] = []

    # Chỉ lấy w:pict — dùng xpath trực tiếp thay vì .// để tránh lấy
    # v:imagedata bên trong w:object (w:object không nằm trong w:pict)
    picts = r_pure.xpath("w:pict", namespaces=_NS)
    if not picts:
        # Fallback: .// nhưng loại trừ những pict nằm trong w:object
        all_picts = r_pure.xpath(".//w:pict", namespaces=_NS)
        obj_descendants: set = set()
        for obj in r_pure.xpath(".//w:object", namespaces=_NS):
            for el in obj.iter():
                obj_descendants.add(id(el))
        picts = [p for p in all_picts if id(p) not in obj_descendants]

    if not picts:
        return nodes

    for pict_idx, pict in enumerate(picts, start=1):
        imagedatas = pict.xpath(".//v:imagedata", namespaces=_NS)
        for img_idx, imgdata in enumerate(imagedatas, start=1):
            rid = imgdata.get(_R_EMBED)
            if not rid:
                continue

            image_part = part.related_parts.get(rid) if part else None
            if image_part is None:
                continue

            blob = image_part.blob
            if not blob:
                continue

            mime = getattr(image_part, "content_type", None) or "image/png"
            blob, mime = _normalize_blob(blob, mime)

            shape      = pict.xpath(".//v:shape", namespaces=_NS)
            width_emu  = height_emu = 0
            if shape:
                width_emu, height_emu = _parse_vml_size(shape[0].get("style", ""))

            alt_text = imgdata.get(_O_TITLE, "")
            img_uid  = f"{uid_prefix}.r{run_idx}.p{pict_idx}.{img_idx}"

            nodes.append(
                DocNode(
                    type="image",
                    uid=img_uid,
                    parent_uid=parent_uid,
                    order=next_order(order_ref),
                    path=img_uid.replace(".", "/"),
                    content=_build_image_content(
                        blob=blob,
                        mime=mime,
                        rid=rid,
                        width_emu=width_emu,
                        height_emu=height_emu,
                        alt_text=alt_text,
                        floating=True,
                        run_index=run_idx,
                        draw_index=pict_idx,
                        blip_index=img_idx,
                        extra={"vml": True},
                    ),
                )
            )

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# OLE extractor  ← MỚI
# ══════════════════════════════════════════════════════════════════════════════

def _extract_ole_images_from_run(
    r_pure,
    part,
    uid_prefix: str,
    run_idx: int,
    parent_uid: Optional[str],
    order_ref: Optional[OrderRef],
) -> List[DocNode]:
    """
    Extract thumbnail từ w:object (OLE embedded object).

    Cấu trúc XML:
        <w:r>
          <w:object w:dxaOrig="11323" w:dyaOrig="5207">
            <v:shape style="width:395.6pt;height:94pt">
              <v:imagedata r:id="rId5"/>   ← thumbnail PNG/EMF — extract được
            </v:shape>
            <o:OLEObject r:id="rId6"/>     ← file gốc (CorelDRAW...) — bỏ qua
          </w:object>
        </w:r>

    Chỉ lấy v:imagedata bên trong w:object — thumbnail preview.
    Treat như ảnh bình thường: lưu qua image_store, tạo DocNode(type="image").
    extra={"ole": True} để caller biết nguồn gốc nếu cần.

    Kích thước ưu tiên: v:shape style → w:object dxaOrig/dyaOrig (twips).
    """
    nodes: List[DocNode] = []

    objects = r_pure.xpath(".//w:object", namespaces=_NS)
    if not objects:
        return nodes

    for obj_idx, obj in enumerate(objects, start=1):
        imagedatas = obj.xpath(".//v:imagedata", namespaces=_NS)
        for img_idx, imgdata in enumerate(imagedatas, start=1):
            rid = imgdata.get(_R_EMBED)
            if not rid:
                continue

            image_part = part.related_parts.get(rid) if part else None
            if image_part is None:
                continue

            blob = image_part.blob
            if not blob:
                continue

            mime = getattr(image_part, "content_type", None) or "image/png"
            blob, mime = _normalize_blob(blob, mime)

            # Kích thước: ưu tiên v:shape style (pt → EMU)
            shapes = obj.xpath(".//v:shape", namespaces=_NS)
            width_emu = height_emu = 0
            if shapes:
                width_emu, height_emu = _parse_vml_size(shapes[0].get("style", ""))

            # Fallback: dxaOrig / dyaOrig trên w:object (twips → EMU)
            if not width_emu:
                dxa = obj.get(_W_DXA)
                if dxa:
                    try:
                        width_emu = int(dxa) * _TWIPS_TO_EMU
                    except ValueError:
                        pass
            if not height_emu:
                dya = obj.get(_W_DYA)
                if dya:
                    try:
                        height_emu = int(dya) * _TWIPS_TO_EMU
                    except ValueError:
                        pass

            alt_text = imgdata.get(_O_TITLE, "")
            img_uid  = f"{uid_prefix}.r{run_idx}.ole{obj_idx}.{img_idx}"

            nodes.append(
                DocNode(
                    type="image",
                    uid=img_uid,
                    parent_uid=parent_uid,
                    order=next_order(order_ref),
                    path=img_uid.replace(".", "/"),
                    content=_build_image_content(
                        blob=blob,
                        mime=mime,
                        rid=rid,
                        width_emu=width_emu,
                        height_emu=height_emu,
                        alt_text=alt_text,
                        floating=False,
                        run_index=run_idx,
                        draw_index=obj_idx,
                        blip_index=img_idx,
                        extra={"ole": True},
                    ),
                )
            )

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# Core extractor — nhận p_xml (lxml) + part
# ══════════════════════════════════════════════════════════════════════════════

def extract_images_from_p_xml(
    p_xml,
    part,
    uid_prefix: str = "img",
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> List[DocNode]:
    """
    Core logic extract ảnh từ 1 paragraph XML element + part.

    Dùng được từ cả 2 nơi:
        - extract_inline_images (Paragraph object) → unwrap rồi gọi hàm này
        - shape.py (_parse_p_xml trong textbox)    → gọi thẳng với p_xml + part

    Xử lý đầy đủ:
        ✅ w:drawing có a:blip (inline và anchor)
        ✅ w:pict / v:imagedata (VML — file .doc cũ convert sang .docx)
        ✅ w:object / v:imagedata (OLE — CorelDRAW, Visio, Excel nhúng...)  ← MỚI
        ✅ EMF/WMF → PNG convert qua _normalize_blob
        ✅ save_image → image_url (không dùng data_uri)
        ✅ raw_bytes lưu vào content cho perceptual hash

    Thứ tự ưu tiên trong 1 run:
        1. OLE (w:object)  — nếu có thì đây là "ảnh thật", bỏ qua drawing thumbnail
        2. VML (w:pict)    — nếu có thì đây là "ảnh thật", bỏ qua drawing thumbnail
        3. DML (w:drawing) — file .docx thuần không có VML/OLE
    """
    nodes: List[DocNode] = []

    run_tag = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}r"
    runs = [child for child in p_xml if child.tag == run_tag]

    # ── Không có run riêng biệt: fallback tìm thẳng trong p_xml ──────────────
    if not runs:
        r_pure = _pure(p_xml) if not hasattr(p_xml, "xpath") else p_xml

        # OLE trước
        nodes.extend(_extract_ole_images_from_run(
            r_pure, part, uid_prefix, 0, parent_uid, order_ref,
        ))

        # VML (w:pict không nằm trong w:object)
        nodes.extend(_extract_vml_images_from_run(
            r_pure, part, uid_prefix, 0, parent_uid, order_ref,
        ))

        # DML nếu chưa có gì
        if not nodes:
            drawings = r_pure.xpath(".//w:drawing", namespaces=_NS)
            for draw_idx, drawing in enumerate(drawings, start=1):
                blip_rids = drawing.xpath(".//a:blip/@r:embed", namespaces=_NS)
                if not blip_rids:
                    continue
                width_emu, height_emu = _get_image_size(drawing)
                alt_text              = _get_alt_text(drawing)
                floating              = _is_anchor(drawing)
                for blip_idx, rid in enumerate(blip_rids, start=1):
                    image_part = part.related_parts.get(rid) if part else None
                    if image_part is None:
                        continue
                    blob = image_part.blob
                    if not blob:
                        continue
                    mime = getattr(image_part, "content_type", None) or "image/png"
                    blob, mime = _normalize_blob(blob, mime)
                    img_uid = f"{uid_prefix}.d{draw_idx}.{blip_idx}"
                    nodes.append(DocNode(
                        type="image",
                        uid=img_uid,
                        parent_uid=parent_uid,
                        order=next_order(order_ref),
                        path=img_uid.replace(".", "/"),
                        content=_build_image_content(
                            blob=blob, mime=mime, rid=rid,
                            width_emu=width_emu, height_emu=height_emu,
                            alt_text=alt_text, floating=floating,
                            run_index=0, draw_index=draw_idx, blip_index=blip_idx,
                        ),
                    ))

        return nodes

    # ── Iterate từng run ──────────────────────────────────────────────────────
    for run_idx, r_elm in enumerate(runs, start=1):
        r_pure = etree.fromstring(etree.tostring(r_elm))

        # 1. OLE object — ưu tiên cao nhất
        ole_nodes = _extract_ole_images_from_run(
            r_pure, part, uid_prefix, run_idx, parent_uid, order_ref,
        )
        if ole_nodes:
            nodes.extend(ole_nodes)
            continue  # drawing trong cùng run chỉ là thumbnail của OLE — bỏ qua

        drawings = r_pure.xpath(".//w:drawing", namespaces=_NS)

        if drawings:
            # 2. VML — nếu có thì drawing chỉ là thumbnail
            vml_nodes = _extract_vml_images_from_run(
                r_pure, part, uid_prefix, run_idx, parent_uid, order_ref,
            )
            if vml_nodes:
                nodes.extend(vml_nodes)
                continue

            # 3. DML thuần — file .docx không có VML/OLE
            for draw_idx, drawing in enumerate(drawings, start=1):
                blip_rids = drawing.xpath(".//a:blip/@r:embed", namespaces=_NS)
                if not blip_rids:
                    continue

                width_emu, height_emu = _get_image_size(drawing)
                alt_text              = _get_alt_text(drawing)
                floating              = _is_anchor(drawing)

                for blip_idx, rid in enumerate(blip_rids, start=1):
                    image_part = part.related_parts.get(rid) if part else None
                    if image_part is None:
                        continue

                    blob = image_part.blob
                    if not blob:
                        continue

                    mime = getattr(image_part, "content_type", None) or "image/png"
                    blob, mime = _normalize_blob(blob, mime)

                    img_uid = f"{uid_prefix}.r{run_idx}.d{draw_idx}.{blip_idx}"
                    nodes.append(DocNode(
                        type="image",
                        uid=img_uid,
                        parent_uid=parent_uid,
                        order=next_order(order_ref),
                        path=img_uid.replace(".", "/"),
                        content=_build_image_content(
                            blob=blob, mime=mime, rid=rid,
                            width_emu=width_emu, height_emu=height_emu,
                            alt_text=alt_text, floating=floating,
                            run_index=run_idx, draw_index=draw_idx, blip_index=blip_idx,
                        ),
                    ))
        else:
            # Không có drawing — thử VML và OLE (ít gặp nhưng cần cover)
            nodes.extend(
                _extract_vml_images_from_run(
                    r_pure, part, uid_prefix, run_idx, parent_uid, order_ref,
                )
            )
            # OLE đã được xử lý ở đầu vòng lặp — không gọi lại ở đây

    return nodes


# ══════════════════════════════════════════════════════════════════════════════
# Public API — Paragraph wrapper (không đổi interface)
# ══════════════════════════════════════════════════════════════════════════════

def extract_inline_images(
    par: Paragraph,
    uid_prefix: str = "img",
    parent_uid: Optional[str] = None,
    order_ref: Optional[OrderRef] = None,
) -> List[DocNode]:
    """
    Trích xuất tất cả ảnh từ một paragraph.

    Wrapper mỏng quanh extract_images_from_p_xml — giữ nguyên interface
    để các caller hiện tại (table.py, paragraph.py) không cần thay đổi.
    """
    p_xml = _pure(par._p)
    part  = getattr(par, "part", None)
    return extract_images_from_p_xml(p_xml, part, uid_prefix, parent_uid, order_ref)