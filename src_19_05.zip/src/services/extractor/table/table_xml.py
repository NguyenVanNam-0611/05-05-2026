"""
extractor/table_xml.py
~~~~~~~~~~~~~~~~~~~~~~
XML-level helpers cho table — không import DocNode, không phụ thuộc model.

Chịu trách nhiệm:
    - Parse physical rows/cells từ XML (tránh python-docx deduplicate merged cells)
    - Tính col_span từ gridSpan
    - Detect vMerge (row_span)
    - Đếm col_count thực tế

Không chứa logic content hay DocNode.
Import bởi: table_cell.py, table.py
"""

from __future__ import annotations

from typing import List, Tuple

from docx.oxml.ns import qn
from docx.table import Table, _Cell


# ══════════════════════════════════════════════════════════════════════════════
# Physical row/cell từ XML
# ══════════════════════════════════════════════════════════════════════════════

def get_xml_rows(tbl: Table) -> List[List]:
    """
    Trả về list[list[tc_element]] — physical cells từ XML.

    python-docx tbl.rows[r].cells deduplicate merged cells → col_index lệch.
    Dùng hàm này để lấy đúng tc elements theo XML.
    """
    TR = qn("w:tr")
    TC = qn("w:tc")
    return [
        list(tr.iterchildren(TC))
        for tr in tbl._tbl.iterchildren(TR)
    ]


# ══════════════════════════════════════════════════════════════════════════════
# col_span
# ══════════════════════════════════════════════════════════════════════════════

def tc_col_span(tc) -> int:
    """Số cột mà tc element này chiếm (w:gridSpan). Default 1."""
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1
    gs = tcPr.find(qn("w:gridSpan"))
    return int(gs.get(qn("w:val"), 1)) if gs is not None else 1


# ══════════════════════════════════════════════════════════════════════════════
# col_count
# ══════════════════════════════════════════════════════════════════════════════

def count_cols_from_xml(xml_rows: List[List]) -> int:
    """
    Tính số cột thực tế của table từ xml_rows.

    Ưu tiên rows có > 1 physical cell để tránh title row (1 cell spanning toàn bộ)
    làm lệch col_count. Fallback về tất cả rows nếu không có multi-cell row.

    Edge case: xml_rows rỗng → 0.
    """
    if not xml_rows:
        return 0

    multi_cell_rows = [row for row in xml_rows if len(row) > 1]
    candidate_rows  = multi_cell_rows if multi_cell_rows else xml_rows

    counts = [sum(tc_col_span(tc) for tc in row) for row in candidate_rows]
    return max(counts) if counts else 0


# ══════════════════════════════════════════════════════════════════════════════
# vMerge / row_span
# ══════════════════════════════════════════════════════════════════════════════

def get_cell_merge_info(cell: _Cell) -> Tuple[int, bool, bool]:
    """
    Trả về (col_span, is_restart, is_continue).

    is_restart  = True → cell này bắt đầu 1 vMerge group (row_span > 1)
    is_continue = True → cell này là continuation của vMerge → bỏ qua khi extract
    """
    tc   = cell._tc
    tcPr = tc.find(qn("w:tcPr"))
    if tcPr is None:
        return 1, False, False

    gs       = tcPr.find(qn("w:gridSpan"))
    col_span = int(gs.get(qn("w:val"), 1)) if gs is not None else 1

    vMerge = tcPr.find(qn("w:vMerge"))
    if vMerge is None:
        return col_span, False, False

    val = vMerge.get(qn("w:val"), "")
    if val == "restart":
        return col_span, True, False
    # val == "" hoặc không có → continuation
    return col_span, False, True


def count_row_span(xml_rows: List[List], row_idx: int, grid_col: int) -> int:
    """
    Đếm số row mà cell tại (row_idx, grid_col) chiếm
    bằng cách đi xuống và đếm các vMerge continuation.

    Dừng khi:
    - Không tìm thấy tc tại grid_col (hết bảng hoặc lệch)
    - tc tiếp theo có vMerge=restart (bắt đầu group mới)
    - tc tiếp theo không có vMerge (row bình thường)
    """
    span = 1
    for r in range(row_idx + 1, len(xml_rows)):
        pos      = 0
        found_tc = None

        for tc in xml_rows[r]:
            if pos == grid_col:
                found_tc = tc
                break
            pos += tc_col_span(tc)
            if pos > grid_col:
                break

        if found_tc is None:
            break

        tcPr   = found_tc.find(qn("w:tcPr"))
        vMerge = tcPr.find(qn("w:vMerge")) if tcPr is not None else None

        if vMerge is None:
            break
        if vMerge.get(qn("w:val"), "") == "restart":
            break

        span += 1

    return span