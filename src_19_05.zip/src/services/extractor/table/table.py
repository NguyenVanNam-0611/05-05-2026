"""
extractor/table.py
~~~~~~~~~~~~~~~~~~
Extract table và cell từ docx thành DocNode.

Chịu trách nhiệm:
    - Orchestrate extract_table → row → cell (kể cả merged cell)
    - Gọi table_xml.py cho XML helpers
    - Gọi table_cell.py cho cell content helpers
    - Lưu đủ metadata để diff và render hoạt động đúng với mọi layout_type

Cây trả về từ extract_table():
    table
    └── row
        └── cell
            ├── paragraph
            │   └── image          (inline)
            ├── image              (direct child)
            └── table              (nested — đệ quy)

Metadata cell.content:
    text              str   — text normalize (paragraph) hoặc text gom từ nested table
    text_display      str   — text raw giữ newline
    nested_text       str   — text gom từ nested table (chỉ có khi layout_type=nested_table)
    full_text         str   — text + nested_text gộp lại (dùng cho text_set của outer table)
    layout_type       str   — "text" | "image" | "nested_table" | "mixed" | "empty"
    row_index         int
    col_index         int
    row_span          int
    col_span          int
    is_merged         bool
    image_count       int
    outer_label_texts list  — text của các cell cùng row không chứa nested table
                             (chỉ set cho cell có layout_type=nested_table, dùng bởi diff TH1)

Metadata table.content:
    row_count         int
    col_count         int
    text              str   — join toàn bộ cell text (kể cả nested) theo row
    text_set          str   — sorted unique full_text của mọi cell (stable cho Jaccard)
    has_nested_table  bool  — True nếu bất kỳ cell nào có nested table

Metadata row.content:
    row_index         int
    cell_count        int
    text              str   — join cell text trong row
    has_nested_table  bool  — True nếu row này có cell chứa nested table
    outer_label_texts list  — text label của row này (dùng bởi diff TH1)

KHÔNG xử lý: paragraph ở document level, TOC, shape ở document level.
Import từ: table_xml.py, table_cell.py, paragraph.py, utils.py
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph

from src.services.extractor.utils import OrderRef, next_order, norm_text, raw_text
from src.services.models.docnode import DocNode
from src.services.extractor.paragraph import extract_paragraph_nodes

from src.services.extractor.table.table_xml import (
    get_xml_rows,
    tc_col_span,
    count_cols_from_xml,
    get_cell_merge_info,
    count_row_span,
)
from src.services.extractor.table.table_cell import (
    iter_cell_items,
    cell_direct_text,
    cell_raw_text,
    cell_nested_text,
    cell_full_text,
    cell_image_count,
    detect_cell_layout_type,
    get_outer_label_texts,
)


# ══════════════════════════════════════════════════════════════════════════════
# Cell extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_cell(
    cell:              _Cell,
    uid_prefix:        str,
    parent_uid:        Optional[str],
    order_ref:         OrderRef,
    row_index:         int,
    col_index:         int,
    col_span:          int = 1,
    row_span:          int = 1,
    is_merged:         bool = False,
    outer_label_texts: Optional[List[str]] = None,
) -> DocNode:
    """
    Extract 1 cell thành DocNode với đầy đủ metadata.

    outer_label_texts: truyền từ _extract_row cho cell có layout_type=nested_table,
    để diff biết label nào cần bỏ khi match flat row (TH1).
    """
    layout_type = detect_cell_layout_type(cell)

    # Text tùy theo layout
    direct_text = cell_direct_text(cell)
    nested_text_ = cell_nested_text(cell) if layout_type == "nested_table" else ""
    full_text_   = cell_full_text(cell)

    # cell.content["text"]: dùng để diff/so sánh
    # - nested_table: dùng nested_text vì direct_text thường rỗng (label ở cell khác)
    # - các loại khác: dùng direct_text
    display_text = nested_text_ if layout_type == "nested_table" and not direct_text else direct_text

    cell_node = DocNode(
        type="cell",
        uid=uid_prefix,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=uid_prefix.replace(".", "/"),
        content={
            "text":              display_text,
            "text_display":      cell_raw_text(cell),
            "nested_text":       nested_text_,
            "full_text":         full_text_,
            "layout_type":       layout_type,
            "row_index":         row_index,
            "col_index":         col_index,
            "row_span":          row_span,
            "col_span":          col_span,
            "is_merged":         is_merged,
            "image_count":       cell_image_count(cell),
            "outer_label_texts": outer_label_texts or [],
        },
    )

    # ── Extract children theo thứ tự XML ──────────────────────────────────────
    # Dùng 2 counter riêng để uid không bị lỗ khi có cả paragraph lẫn table
    p_count = 0
    t_count = 0

    for item in iter_cell_items(cell):

        if isinstance(item, Table):
            t_count += 1
            cell_node.add_child(
                extract_table(
                    item,
                    uid=f"{uid_prefix}.t{t_count}",
                    parent_uid=uid_prefix,
                    order_ref=order_ref,
                )
            )
            continue

        # Paragraph
        assert isinstance(item, Paragraph)
        has_text  = bool(norm_text(item.text))
        has_image = any(
            run._r is not None and (
                run._r.find("w:drawing") is not None
                or run._r.find("w:pict") is not None
            )
            for run in item.runs
        )

        p_count += 1

        nodes = list(extract_paragraph_nodes(
            item,
            uid=f"{uid_prefix}.p{p_count}",
            parent_uid=uid_prefix,
            order_ref=order_ref,
            in_toc=False,
        ))

        if nodes:
            para_node = nodes[0]
        else:
            para_node = DocNode(
                type="paragraph",
                uid=f"{uid_prefix}.p{p_count}",
                parent_uid=uid_prefix,
                order=next_order(order_ref),
                path=f"{uid_prefix}/p{p_count}",
                content={
                    "text":         norm_text(item.text),
                    "text_display": raw_text(item.text),
                },
            )

        if has_text:
            para_node.content["text"]         = norm_text(item.text)
            para_node.content["text_display"]  = raw_text(item.text)

        img_children = [ch for ch in para_node.children if ch.type == "image"]
        if img_children:
            para_node.content["image_count"] = len(img_children)

        if has_text or has_image:
            cell_node.add_child(para_node)

    return cell_node


# ══════════════════════════════════════════════════════════════════════════════
# Row extractor
# ══════════════════════════════════════════════════════════════════════════════

def _extract_row(
    tbl:       Table,
    xml_rows:  List[List],
    r_idx:     int,
    uid:       Optional[str],
    order_ref: OrderRef,
    skip_map:  Dict[Tuple[int, int], bool],
) -> DocNode:
    """
    Extract 1 row thành DocNode.

    Tính outer_label_texts cho cả row trước khi extract từng cell,
    vì cần biết toàn bộ cell layout trước để phân biệt label ↔ nested cell.
    """
    row        = tbl.rows[r_idx]
    row_uid    = f"{uid}.r{r_idx}" if uid else f"row.{r_idx}"
    xml_tcs    = xml_rows[r_idx] if r_idx < len(xml_rows) else []

    # ── Pre-scan: tính outer_label_texts cho row ──────────────────────────────
    # Scan tất cả cell trong row, lấy text của cell KHÔNG có nested table
    # → dùng khi extract cell có nested table (truyền xuống outer_label_texts)
    all_cells_in_row = [_Cell(tc, tbl) for tc in xml_tcs]
    outer_labels     = get_outer_label_texts(all_cells_in_row)
    outer_labels_list = sorted(outer_labels)  # list để serialize vào content

    row_has_nested = any(
        detect_cell_layout_type(_Cell(tc, tbl)) == "nested_table"
        for tc in xml_tcs
    )

    row_text_val = " | ".join(
        cell_full_text(_Cell(tc, tbl))
        for tc in xml_tcs
        if cell_full_text(_Cell(tc, tbl))
    )

    row_node = DocNode(
        type="row",
        uid=row_uid,
        parent_uid=uid,
        order=next_order(order_ref),
        path=row_uid.replace(".", "/"),
        content={
            "row_index":         r_idx,
            "cell_count":        len(xml_tcs),
            "text":              row_text_val,
            "has_nested_table":  row_has_nested,
            "outer_label_texts": outer_labels_list,
        },
    )

    # ── Extract từng cell ─────────────────────────────────────────────────────
    logical_col = 0

    for tc in xml_tcs:
        # Skip nếu cell này đã được cover bởi vMerge từ row trên
        if skip_map.get((r_idx, logical_col)):
            logical_col += tc_col_span(tc)
            continue

        cell                          = _Cell(tc, tbl)
        col_span, is_restart, is_cont = get_cell_merge_info(cell)

        if is_cont:
            logical_col += col_span
            continue

        row_span  = 1
        is_merged = col_span > 1

        if is_restart:
            row_span  = count_row_span(xml_rows, r_idx, logical_col)
            is_merged = True
            for dr in range(1, row_span):
                for dc in range(col_span):
                    skip_map[(r_idx + dr, logical_col + dc)] = True

        cell_uid    = (
            f"{uid}.r{r_idx}.c{logical_col}"
            if uid else
            f"cell.r{r_idx}.c{logical_col}"
        )
        layout_type = detect_cell_layout_type(cell)

        # Chỉ truyền outer_label_texts cho cell có nested table
        # (các cell khác không cần)
        cell_outer_labels = outer_labels_list if layout_type == "nested_table" else []

        row_node.add_child(
            _extract_cell(
                cell=cell,
                uid_prefix=cell_uid,
                parent_uid=row_uid,
                order_ref=order_ref,
                row_index=r_idx,
                col_index=logical_col,
                col_span=col_span,
                row_span=row_span,
                is_merged=is_merged,
                outer_label_texts=cell_outer_labels,
            )
        )

        logical_col += col_span

    return row_node


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def extract_table(
    tbl:        Table,
    uid:        Optional[str]      = None,
    parent_uid: Optional[str]      = None,
    order_ref:  Optional[OrderRef] = None,
) -> DocNode:
    """
    Extract một table thành DocNode (kể cả nested table đệ quy).

    Args:
        tbl:        Table object từ python-docx.
        uid:        UID của table node (vd: "n3", "n3.r1.c2.t1").
        parent_uid: UID của node cha.
        order_ref:  Mutable counter dùng chung toàn document.

    Returns:
        DocNode(type="table") với cây con row → cell → ...

    Metadata:
        text_set bao gồm full_text của mọi cell (kể cả nested table content)
        → Jaccard similarity stable khi layout thay đổi (TH4).

        has_nested_table giúp detect_structure_change không bị nhầm
        khi col_count bị expand do nested table (trả False thay vì True).
    """
    if order_ref is None:
        order_ref = {"value": 0}

    xml_rows = get_xml_rows(tbl)
    n_rows   = len(xml_rows)
    n_cols   = count_cols_from_xml(xml_rows)

    # ── text và text_set dùng full_text (bao gồm nested table content) ────────
    # Lý do: text_set dùng cho Jaccard similarity (sequence_align và table_diff)
    # → phải stable với layout thay đổi → dùng full_text thay vì chỉ direct_text
    all_full_texts: List[str] = []
    table_text_rows: List[str] = []

    for row in tbl.rows:
        row_cell_texts = []
        for c in row.cells:
            ft = cell_full_text(c)
            if ft:
                row_cell_texts.append(ft)
                all_full_texts.append(ft)
        if row_cell_texts:
            table_text_rows.append(" | ".join(row_cell_texts))

    table_text = "\n".join(table_text_rows)
    text_set   = " ".join(sorted(set(all_full_texts)))

    # Detect xem table có nested table không (ảnh hưởng detect_structure_change)
    table_has_nested = any(
        detect_cell_layout_type(c) == "nested_table"
        for row in tbl.rows
        for c in row.cells
    )

    table_node = DocNode(
        type="table",
        uid=uid,
        parent_uid=parent_uid,
        order=next_order(order_ref),
        path=(uid or "").replace(".", "/"),
        content={
            "row_count":        n_rows,
            "col_count":        n_cols,
            "text":             table_text,
            "text_set":         text_set,
            "has_nested_table": table_has_nested,
        },
    )

    skip_map: Dict[Tuple[int, int], bool] = {}

    for r_idx in range(n_rows):
        row_node = _extract_row(
            tbl=tbl,
            xml_rows=xml_rows,
            r_idx=r_idx,
            uid=uid,
            order_ref=order_ref,
            skip_map=skip_map,
        )
        table_node.add_child(row_node)

    return table_node