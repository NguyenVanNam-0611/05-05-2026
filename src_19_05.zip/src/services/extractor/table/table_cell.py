"""
extractor/table_cell.py
~~~~~~~~~~~~~~~~~~~~~~~
Cell content helpers — phân tích nội dung cell, tính layout_type.

Chịu trách nhiệm:
    - Iterate items trong cell (paragraph, nested table) theo thứ tự XML
    - Detect layout_type của cell
    - Extract text thuần, text từ nested table
    - Đếm ảnh
    - Tính outer_label_texts cho row (dùng bởi diff khi match nested ↔ flat)

layout_type:
    "text"         — chỉ có paragraph text, không ảnh, không nested table
    "image"        — chỉ có ảnh (không text, không nested table)
    "nested_table" — có ít nhất 1 nested table (dù có thêm text hay không)
    "mixed"        — có cả text lẫn ảnh, không nested table
    "empty"        — không có gì

Import bởi: table.py
"""

from __future__ import annotations

from typing import Iterator, List, Optional, Set, Union

from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph

from src.services.extractor.utils import norm_text, raw_text

BlockItem = Union[Paragraph, Table]

# Literal type hint (Python 3.7 compat)
CellLayoutType = str  # "text" | "image" | "nested_table" | "mixed" | "empty"


# ══════════════════════════════════════════════════════════════════════════════
# Iterator
# ══════════════════════════════════════════════════════════════════════════════

def iter_cell_items(cell: _Cell) -> Iterator[BlockItem]:
    """
    Yield các item có nghĩa trong cell theo đúng thứ tự XML:
    - Paragraph có text hoặc ảnh inline
    - Nested Table (CT_Tbl)

    Bỏ qua paragraph rỗng hoàn toàn (Word tự thêm sau nested table).
    """
    for child in cell._tc.iterchildren():
        if isinstance(child, CT_P):
            par      = Paragraph(child, cell)
            has_text = bool(norm_text(par.text))
            has_img  = _para_has_image(par)
            if has_text or has_img:
                yield par
        elif isinstance(child, CT_Tbl):
            yield Table(child, cell)


# ══════════════════════════════════════════════════════════════════════════════
# Image helpers
# ══════════════════════════════════════════════════════════════════════════════

def _para_has_image(para: Paragraph) -> bool:
    """True nếu paragraph chứa ít nhất 1 ảnh inline (w:drawing hoặc w:pict)."""
    for run in para.runs:
        r = run._r
        if r is not None and (
            r.find(qn("w:drawing")) is not None
            or r.find(qn("w:pict")) is not None
        ):
            return True
    return False


def cell_image_count(cell: _Cell) -> int:
    """Đếm tổng số ảnh inline trong cell (qua paragraph có image)."""
    count = 0
    for item in iter_cell_items(cell):
        if not isinstance(item, Paragraph):
            continue
        for run in item.runs:
            r = run._r
            if r is not None and (
                r.find(qn("w:drawing")) is not None
                or r.find(qn("w:pict")) is not None
            ):
                count += 1
    return count


# ══════════════════════════════════════════════════════════════════════════════
# Text extraction
# ══════════════════════════════════════════════════════════════════════════════

def cell_direct_text(cell: _Cell) -> str:
    """
    Text normalize của cell từ paragraph trực tiếp (không đệ quy vào nested table).
    Dùng cho row.content["text"] và cell.content["text"] khi cell là text thuần.
    """
    parts = []
    for item in iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = norm_text(item.text)
            if t:
                parts.append(t)
    return " ".join(parts)


def cell_raw_text(cell: _Cell) -> str:
    """Text raw (giữ newline) của cell từ paragraph trực tiếp."""
    parts = []
    for item in iter_cell_items(cell):
        if isinstance(item, Paragraph):
            t = raw_text(item.text)
            if t:
                parts.append(t)
    return "\n".join(parts)


def cell_nested_text(cell: _Cell) -> str:
    """
    Text normalize gom từ nested table trong cell.

    Dùng để:
    1. Đưa vào cell.content["text"] khi layout_type="nested_table"
       → outer table text_set bao gồm cả content của nested table
    2. Jaccard similarity khi diff nested_table ↔ text (TH2)

    Format: join các cell text của nested table bằng space,
    các row ngăn cách bằng " | ".
    """
    parts = []
    for item in iter_cell_items(cell):
        if isinstance(item, Table):
            row_parts = []
            for row in item.rows:
                cell_parts = []
                for c in row.cells:
                    t = norm_text(c.text)
                    if t:
                        cell_parts.append(t)
                if cell_parts:
                    row_parts.append(" | ".join(cell_parts))
            if row_parts:
                parts.append(" || ".join(row_parts))
    return " ".join(parts)


def cell_full_text(cell: _Cell) -> str:
    """
    Text đầy đủ của cell:
    - Nếu có nested table: paragraph text + nested table text
    - Nếu không: chỉ paragraph text

    Dùng để tính text_set của outer table (bao gồm cả nested content).
    """
    direct = cell_direct_text(cell)
    nested = cell_nested_text(cell)
    parts  = [p for p in [direct, nested] if p]
    return " ".join(parts)


# ══════════════════════════════════════════════════════════════════════════════
# layout_type detection
# ══════════════════════════════════════════════════════════════════════════════

def detect_cell_layout_type(cell: _Cell) -> CellLayoutType:
    """
    Phân loại nội dung cell thành 1 trong 5 layout_type.

    Ưu tiên:
    1. Có nested table → "nested_table" (dù có thêm text/ảnh)
    2. Không có nested table:
       - Có text + ảnh → "mixed"
       - Chỉ có text   → "text"
       - Chỉ có ảnh    → "image"
       - Không có gì   → "empty"

    "nested_table" được ưu tiên vì đây là thông tin structural quan trọng nhất
    để diff chọn đúng strategy (TH1, TH2).
    """
    has_text   = False
    has_image  = False
    has_nested = False

    for item in iter_cell_items(cell):
        if isinstance(item, Table):
            has_nested = True
        elif isinstance(item, Paragraph):
            if norm_text(item.text):
                has_text = True
            if _para_has_image(item):
                has_image = True

    if has_nested:
        return "nested_table"
    if has_text and has_image:
        return "mixed"
    if has_text:
        return "text"
    if has_image:
        return "image"
    return "empty"


# ══════════════════════════════════════════════════════════════════════════════
# Outer label texts — dùng bởi diff (TH1: nested ↔ flat)
# ══════════════════════════════════════════════════════════════════════════════

def get_outer_label_texts(cells_in_row: List[_Cell]) -> Set[str]:
    """
    Lấy set text (đã norm, lower) của các cell trong row KHÔNG chứa nested table.

    Dùng trong diff khi match nested sub-row với flat row:
    flat row lặp lại label ở mỗi dòng nhưng nested sub-row không có
    → cần bỏ label ra khỏi flat row trước khi tính token overlap.

    Ví dụ:
        outer row: [cell("Đường kính") | cell(nested_table)]
        → outer_label_texts = {"đường kính"}

        flat row: [cell("Đường kính") | cell("OT4J") | cell("φ1.03")]
        → sau khi bỏ label: {ot4j, φ1.03}
        → overlap với nested sub-row {ot4j, φ1.03} = 100% → match
    """
    result: Set[str] = set()
    for cell in cells_in_row:
        layout = detect_cell_layout_type(cell)
        if layout != "nested_table":
            t = norm_text(cell.text)
            if t:
                result.add(t.lower())
    return result


# ══════════════════════════════════════════════════════════════════════════════
# Nested table sub-row texts — dùng bởi diff (TH1: match sub-row ↔ flat row)
# ══════════════════════════════════════════════════════════════════════════════

def get_nested_subrow_texts(cell: _Cell) -> Optional[List[List[str]]]:
    """
    Nếu cell có nested table, trả về list of list[str]:
    mỗi phần tử là list text của 1 sub-row trong nested table.

    Trả None nếu cell không có nested table.

    Dùng bởi _nested_aware_row_sig trong table_diff để tạo signature
    đặc biệt cho row có nested table — stable với label cell lặp lại.

    Ví dụ:
        nested table:
            row 0: [OT4J | φ1.03]
            row 1: [OT5J | φ1.19]
        → [["OT4J", "φ1.03"], ["OT5J", "φ1.19"]]
    """
    for item in iter_cell_items(cell):
        if isinstance(item, Table):
            result = []
            for row in item.rows:
                row_texts = [norm_text(c.text) for c in row.cells if norm_text(c.text)]
                if row_texts:
                    result.append(row_texts)
            return result if result else None
    return None