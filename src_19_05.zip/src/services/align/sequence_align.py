"""
align/sequence_align.py
~~~~~~~~~~~~~~~~~~~~~~~
Align block list A (original) với block list B (modified) thành list opcodes.

Fixes so với cũ:
1.  HEADING SHIFT BUG
2.  CROSS-MATCH BUG
3.  _match_mixed_slice INDEX BUG
4.  N-N table pairing
5.  SIMILAR BLOCK DEDUP
6.  EMPTY SHAPE CONTENT SIG
7.  SHAPE WITH TEXT CONTENT SIG
8.  MIXED SLICE OPCODE ORDER BUG
9.  SHAPE IMAGE BUG
10. SHAPE SIMILARITY IMAGE BUG
11. MIXED SLICE DELETE/INSERT J/I BOUNDARY BUG
12. DELETE J COLLISION BUG — delete.j1 == replace.j1 → frontend nhầm delete thành replace.
    ROOT CAUSE: _j_insertion() tính j boundary dựa vào số ki < before_ki trong ki_to_kj,
    nhưng khi pair duy nhất có ki > tất cả unmatched ki (e.g. pair=(3,2) với ki=0,1,2 unmatched),
    j_ins = j1 + 0 = j1 cho tất cả delete → collision với replace.j1 = j1+kj_pair.
    FIX: tất cả delete emit với j1 == j2 == j2_slice. insert giữ nguyên j đúng.
13. TABLE IDENTITY/EQUALITY SPLIT BUG — ảnh đổi layout → _sig_table đổi →
    SequenceMatcher emit delete+insert thay vì replace → diff_table không được gọi.
    ROOT CAUSE: _content_sig dùng signature() (equality sig có ảnh) để match block.
    FIX: tách thành 2 sig:
      • identity_sig = table_identity_sig() — text only, stable, dùng để MATCH
      • equality_sig = block.signature      — text + ảnh, dùng để detect CHANGE
    Đồng thời sửa _block_similarity() dùng Jaccard trên text_set tokens
    và hạ threshold table xuống 0.45 để Jaccard hoạt động đúng.
"""

from __future__ import annotations

import difflib
import hashlib
from typing import List, Set, Tuple

from src.services.block.block_builder import _norm
from src.services.block.signature import (
    _split_heading,
    _norm_text,
    table_identity_sig,
)
from src.services.models.block import Block
from src.services.extractor.shape.shape_content import collect_shape_parts

Opcode = Tuple[str, int, int, int, int]

# Threshold phân biệt theo block type
# • table: 0.45 — Jaccard trên text_set tokens, đủ phân biệt bảng khác nhau
# • other: 0.85 — SequenceMatcher ratio, giữ nguyên hành vi cũ
_TABLE_SIM_THRESHOLD = 0.45
_DEFAULT_SIM_THRESHOLD = 0.85


# ══════════════════════════════════════════════════════════════════════════════
# Shape content helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_combined(block: Block) -> str:
    parts = collect_shape_parts(block.node)
    return " ".join(parts)


def _count_content_parts(block: Block) -> int:
    return len(collect_shape_parts(block.node))


# ══════════════════════════════════════════════════════════════════════════════
# Heading context normalizer
# ══════════════════════════════════════════════════════════════════════════════

def _heading_ctx_body(heading_ctx: str) -> str:
    """
    Bỏ số chương khỏi toàn bộ heading breadcrumb.

    "5.1 Vận hành > 5.1.2 Kiểm tra" → "vận hành > kiểm tra"

    Dùng để tạo identity sig stable trước heading shift (thêm/xóa section
    làm số chương của tất cả section sau bị tăng lên).
    """
    if not heading_ctx:
        return ""
    parts  = heading_ctx.split(" > ")
    bodies = []
    for part in parts:
        _, body = _split_heading(part)
        bodies.append(body)
    return " > ".join(bodies)


# ══════════════════════════════════════════════════════════════════════════════
# Similarity
# ══════════════════════════════════════════════════════════════════════════════

def _table_text_tokens(block: Block) -> Set[str]:
    """
    Trả về set token text của bảng — dùng cho Jaccard similarity.

    Ưu tiên text_set (sorted unique texts, sẵn từ extractor).
    Fallback về text nếu text_set không có.

    text_set stable với: layout ảnh, col_span, thứ tự ảnh.
    """
    raw = (
        block.node.content.get("text_set", "")
        or block.node.content.get("text", "")
        or ""
    )
    toks = set(_norm_text(raw).lower().split())
    return toks if toks else set()


def _block_similarity(a: Block, b: Block) -> float:
    """
    Tính độ tương đồng giữa 2 block cùng type.

    • shape: SequenceMatcher trên combined parts + heading bonus
    • table: Jaccard trên text_set tokens
             → stable khi ảnh đổi layout (text_set không đổi)
             → 0.45 floor khi same_heading để luôn > _TABLE_SIM_THRESHOLD
    • other: SequenceMatcher trên text + heading bonus

    Trả về float [0.0, 1.0].
    """
    if a.type != b.type:
        return 0.0

    same_heading = (a.heading_ctx == b.heading_ctx)

    # ── Shape ────────────────────────────────────────────────────────────────
    if a.type == "shape":
        a_parts    = collect_shape_parts(a.node)
        b_parts    = collect_shape_parts(b.node)
        a_combined = " ".join(a_parts)
        b_combined = " ".join(b_parts)

        if not a_parts and not b_parts:
            return 0.45 if same_heading else 0.05

        if not a_parts or not b_parts:
            return 0.45 if same_heading else 0.0

        ratio         = difflib.SequenceMatcher(a=a_combined, b=b_combined, autojunk=False).ratio()
        heading_bonus = 0.2 if same_heading else 0.0
        return min(1.0, ratio + heading_bonus)

    # ── Table: Jaccard trên text_set tokens ──────────────────────────────────
    # Fix #13: không dùng SequenceMatcher trên equality_sig (hash string)
    # vì 2 hash string chỉ giống nhau khi identically equal, ratio ≈ 0 khi khác.
    # Jaccard trên text tokens: overlap /  union → đo semantic similarity đúng.
    if a.type == "table":
        a_toks = _table_text_tokens(a)
        b_toks = _table_text_tokens(b)

        # Cả 2 bảng toàn ảnh, không có text
        if not a_toks and not b_toks:
            # same_heading: khả năng cao là cùng bảng → 0.6 > threshold 0.45
            # khác heading:  khả năng thấp → 0.2 < threshold 0.45 → không match
            return 0.6 if same_heading else 0.2

        # 1 bảng có text, 1 bảng toàn ảnh — khả năng là cùng bảng rất thấp
        if not a_toks or not b_toks:
            return 0.5 if same_heading else 0.1

        intersection = len(a_toks & b_toks)
        union        = len(a_toks | b_toks)
        jaccard      = intersection / union  # union > 0 vì cả 2 không rỗng

        if same_heading:
            # floor 0.55 > threshold 0.45 → luôn match khi text giống và cùng section
            return max(0.55, jaccard)
        return min(1.0, jaccard + 0.10)

    # ── Paragraph, heading, image — SequenceMatcher trên text ────────────────
    heading_bonus = 0.35 if same_heading else 0.15
    a_text        = _norm_text(a.node.content.get("text", ""))
    b_text        = _norm_text(b.node.content.get("text", ""))
    ratio         = difflib.SequenceMatcher(a=a_text, b=b_text, autojunk=False).ratio()
    return min(1.0, ratio + heading_bonus)


def _similarity_threshold(a: Block, b: Block) -> float:
    """
    Threshold phân biệt match / no-match theo block type.

    table: 0.45 — Jaccard, đủ để phân biệt bảng giống vs khác
    other: 0.85 — SequenceMatcher ratio, giữ nguyên hành vi cũ
    """
    if a.type == "table":
        return _TABLE_SIM_THRESHOLD
    return _DEFAULT_SIM_THRESHOLD


# ══════════════════════════════════════════════════════════════════════════════
# Content-only (IDENTITY) signature
# ══════════════════════════════════════════════════════════════════════════════

def _content_sig(block: Block) -> str:
    """
    Identity signature — dùng để MATCH block giữa 2 phiên bản.

    Fix #13 — nhánh table:
    • Trước: dùng block.signature (equality sig có ảnh)
             → ảnh đổi layout → sig đổi → SequenceMatcher emit delete+insert
    • Sau:   dùng table_identity_sig() (text only, stable)
             → ảnh đổi layout → sig KHÔNG đổi → SequenceMatcher emit replace
             → diff_table được gọi → frontend thấy đúng thay đổi ảnh

    Các type khác giữ nguyên:
    • shape:   sig đặc biệt, stable trước heading shift (fix #1, #2)
    • heading: stable với số chương (fix #1)
    • other:   dùng equality sig (paragraph, image — text không đổi thì sig không đổi)
    """
    t = block.type

    if t == "shape":
        parts    = collect_shape_parts(block.node)
        combined = " ".join(parts)
        ctx_body = _heading_ctx_body(block.heading_ctx or "")

        if not parts:
            uid      = getattr(block.node, "uid", "") or ""
            uid_hash = hashlib.md5(uid.encode("utf-8")).hexdigest()[:8]
            return f"shape|empty|{uid_hash}|{ctx_body}"

        h          = hashlib.md5(combined.encode("utf-8")).hexdigest()[:16]
        part_count = len(parts)
        return f"shape|{h}|n{part_count}|{ctx_body}"

    if t == "heading":
        level = int(block.node.content.get("level", 1) or 1)
        txt   = _norm_text(block.node.content.get("text", ""))
        chapter, body = _split_heading(txt)
        chapter_depth = len(chapter.split(".")) if chapter else 0
        h = hashlib.md5(body.encode("utf-8")).hexdigest()[:12]
        return f"H{level}|d{chapter_depth}|{h}"

    # Fix #13: table dùng identity sig (text only) thay vì equality sig (có ảnh)
    if t == "table":
        return table_identity_sig(
            block.node,
            heading_ctx=block.heading_ctx or "",
        )

    # paragraph, image, unknown — dùng equality sig
    # text không đổi → sig không đổi → OK dùng làm identity
    return f"{t}|{block.signature or ''}"


# ══════════════════════════════════════════════════════════════════════════════
# Opcode sort key
# ══════════════════════════════════════════════════════════════════════════════

def _opcode_sort_key(op: Opcode) -> tuple:
    tag, i1, i2, j1, j2 = op
    return (i1, j1)


# ══════════════════════════════════════════════════════════════════════════════
# Main aligner
# ══════════════════════════════════════════════════════════════════════════════

def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    """
    Align 2 block list thành list opcodes (tag, i1, i2, j1, j2).

    Luồng:
    1. SequenceMatcher trên identity sigs → tìm exact match (equal)
    2. Với equal: nếu i1 != j1 → _match_mixed_slice (vị trí lệch)
    3. Với replace 1-1: _block_similarity → replace hoặc delete+insert
    4. Với replace N-N table: pair theo thứ tự, từng cặp quyết định độc lập
    5. Với replace M-N mixed: _match_mixed_slice → greedy similarity
    """
    a_sigs = [_content_sig(b) for b in a_blocks]
    b_sigs = [_content_sig(b) for b in b_blocks]

    sm         = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    raw_opcodes = sm.get_opcodes()
    refined: List[Opcode] = []

    for tag, i1, i2, j1, j2 in raw_opcodes:
        if tag == "equal":
            if i1 == j1:
                refined.append((tag, i1, i2, j1, j2))
            else:
                _match_mixed_slice(refined, a_blocks, b_blocks, i1, i2, j1, j2)
            continue

        if tag != "replace":
            refined.append((tag, i1, i2, j1, j2))
            continue

        a_slice = a_blocks[i1:i2]
        b_slice = b_blocks[j1:j2]

        # ── 1-1 replace ───────────────────────────────────────────────────────
        if len(a_slice) == 1 and len(b_slice) == 1:
            threshold  = _similarity_threshold(a_slice[0], b_slice[0])
            similarity = _block_similarity(a_slice[0], b_slice[0])
            if similarity >= threshold:
                refined.append(("replace", i1, i2, j1, j2))
            else:
                refined.append(("delete", i1, i2, j1, j1))
                refined.append(("insert", i2, i2, j1, j2))
            continue

        # ── N-N table pairing ─────────────────────────────────────────────────
        if (
            len(a_slice) == len(b_slice)
            and len(a_slice) > 0
            and all(b.type == "table" for b in a_slice)
            and all(b.type == "table" for b in b_slice)
        ):
            for k in range(len(a_slice)):
                sim       = _block_similarity(a_slice[k], b_slice[k])
                threshold = _similarity_threshold(a_slice[k], b_slice[k])
                if sim >= threshold:
                    refined.append(("replace", i1 + k, i1 + k + 1, j1 + k, j1 + k + 1))
                else:
                    refined.append(("delete", i1 + k, i1 + k + 1, j1 + k, j1 + k))
                    refined.append(("insert", i1 + k + 1, i1 + k + 1, j1 + k, j1 + k + 1))
            continue

        # ── M-N mixed ─────────────────────────────────────────────────────────
        if len(a_slice) > 0 and len(b_slice) > 0:
            _match_mixed_slice(refined, a_blocks, b_blocks, i1, i2, j1, j2)
            continue

        refined.append((tag, i1, i2, j1, j2))

    refined.sort(key=_opcode_sort_key)
    return refined


# ══════════════════════════════════════════════════════════════════════════════
# Mixed slice matcher
# ══════════════════════════════════════════════════════════════════════════════

def _match_mixed_slice(
    refined:  List[Opcode],
    a_blocks: List[Block],
    b_blocks: List[Block],
    i1: int, i2: int,
    j1: int, j2: int,
) -> None:
    """
    Match M blocks từ A với N blocks từ B trong slice [i1:i2] × [j1:j2].

    Bước 1: exact match theo thứ tự vị trí (SequenceMatcher trên identity sigs)
    Bước 2: greedy similarity cho phần còn lại (threshold theo type)
    Bước 3: emit opcodes
      • matched pair → equal (nếu equality sigs giống) hoặc replace (nếu khác)
      • unmatched a  → delete (j = j2 để tránh collision với replace.j1)
      • unmatched b  → insert

    Fix #12: delete emit với j1 = j2 = j2_slice để tránh collision với replace.j1.
    Fix #13: equality check dùng block.signature (equality sig có ảnh),
             không dùng _content_sig (identity sig) — sau khi match xong,
             phải check equality_sig để biết có thay đổi thật không.
    """
    a_slice = a_blocks[i1:i2]
    b_slice = b_blocks[j1:j2]

    matched_a: Set[int] = set()
    matched_b: Set[int] = set()
    pairs: List[Tuple[int, int]] = []

    # ── Bước 1: exact match theo thứ tự vị trí ───────────────────────────────
    a_sigs = [_content_sig(a) for a in a_slice]
    b_sigs = [_content_sig(b) for b in b_slice]

    sub_sm = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)
    for sub_tag, si1, si2, sj1, sj2 in sub_sm.get_opcodes():
        if sub_tag != "equal":
            continue
        for offset in range(si2 - si1):
            ki = si1 + offset
            kj = sj1 + offset
            if ki not in matched_a and kj not in matched_b:
                matched_a.add(ki)
                matched_b.add(kj)
                pairs.append((ki, kj))

    # ── Bước 2: greedy similarity cho phần còn lại ───────────────────────────
    candidates: List[Tuple[float, int, int]] = []
    for ki, a in enumerate(a_slice):
        if ki in matched_a:
            continue
        for kj, b in enumerate(b_slice):
            if kj in matched_b:
                continue
            threshold = _similarity_threshold(a, b)
            sim       = _block_similarity(a, b)
            if sim >= threshold:
                candidates.append((sim, ki, kj))

    # Sort: sim cao → khoảng cách vị trí gần → index nhỏ
    candidates.sort(key=lambda item: (-item[0], abs(item[1] - item[2]), item[1], item[2]))

    for sim, ki, kj in candidates:
        if ki in matched_a or kj in matched_b:
            continue
        matched_a.add(ki)
        matched_b.add(kj)
        pairs.append((ki, kj))

    # ── Bước 3: emit opcodes ─────────────────────────────────────────────────
    pair_by_ki = {ki: kj for ki, kj in pairs}
    paired_kj  = set(pair_by_ki.values())

    for ki in range(len(a_slice)):
        ai = i1 + ki
        if ki in pair_by_ki:
            kj = pair_by_ki[ki]
            bj = j1 + kj
            # Fix #13: equality check dùng equality_sig (block.signature)
            # Identity match chỉ nói "cùng block", không nói "không đổi".
            # Equality_sig (có ảnh) mới biết được có thay đổi layout ảnh không.
            if a_slice[ki].signature == b_slice[kj].signature:
                refined.append(("equal",   ai, ai + 1, bj, bj + 1))
            else:
                refined.append(("replace", ai, ai + 1, bj, bj + 1))
        else:
            # Fix #12: j1 = j2 = j2_slice — tránh collision với replace.j1
            refined.append(("delete", ai, ai + 1, j2, j2))

    for kj in sorted(kj for kj in range(len(b_slice)) if kj not in paired_kj):
        refined.append(("insert", i2, i2, j1 + kj, j1 + kj + 1))