"""
utils/image_store.py
~~~~~~~~~~~~~~~~~~~~
Quản lý lưu ảnh ra /tmp và serve qua static URL.

Thay đổi so với cũ:
    - save_image: validate file đã cache trước khi trả URL
      → xóa và lưu lại nếu file cache bị corrupt (quá nhỏ hoặc header sai)
    - _is_valid_image: kiểm tra header magic bytes theo mime
      → tránh cache EMF convert thất bại bị lưu dưới dạng PNG giả
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional

# ── Config ────────────────────────────────────────────────────────────────────

TMP_DIR        = Path(os.environ.get("DOCX_IMAGE_TMP", "/tmp/docx_images"))
MAX_AGE_HOURS  = int(os.environ.get("DOCX_IMAGE_MAX_AGE_HOURS", "12"))
URL_PREFIX     = "/images"

# Map MIME → extension
_MIME_TO_EXT: dict[str, str] = {
    "image/png":  "png",
    "image/jpeg": "jpg",
    "image/gif":  "gif",
    "image/webp": "webp",
    "image/bmp":  "bmp",
}

# Magic bytes để validate file đã cache
_MAGIC: dict[str, bytes] = {
    "png":  b"\x89PNG\r\n\x1a\n",
    "jpg":  b"\xff\xd8\xff",
    "gif":  b"GIF8",
    "webp": b"RIFF",
    "bmp":  b"BM",
}

# Kích thước tối thiểu hợp lệ (bytes)
_MIN_SIZE: dict[str, int] = {
    "png":  67,    # PNG header + IHDR chunk tối thiểu
    "jpg":  100,
    "gif":  35,
    "webp": 30,
    "bmp":  54,
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ext_for(mime: Optional[str]) -> str:
    """Trả extension từ mime, fallback về 'png'."""
    return _MIME_TO_EXT.get((mime or "").lower(), "png")


def _file_path(sha256: str, ext: str) -> Path:
    return TMP_DIR / f"{sha256}.{ext}"


def _is_valid_cached_file(path: Path, ext: str) -> bool:
    """
    Kiểm tra file cache có hợp lệ không.

    Validate:
        1. Kích thước tối thiểu theo loại file
        2. Magic bytes header đúng format

    Trả False nếu file corrupt → caller sẽ xóa và lưu lại.
    """
    try:
        size = path.stat().st_size
        min_size = _MIN_SIZE.get(ext, 50)
        if size < min_size:
            return False

        magic = _MAGIC.get(ext)
        if magic:
            with path.open("rb") as f:
                header = f.read(len(magic))
            if header != magic:
                return False

        return True
    except Exception:
        return False


# ── Public API ────────────────────────────────────────────────────────────────

def ensure_tmp_dir() -> None:
    """Tạo thư mục /tmp/docx_images nếu chưa có. Gọi một lần khi startup."""
    TMP_DIR.mkdir(parents=True, exist_ok=True)


def save_image(sha256: str, blob: bytes, mime: Optional[str] = None) -> str:
    """
    Lưu blob ra disk, trả về URL path để frontend dùng.

    Dùng write-then-rename để đảm bảo atomic — không có partial file.

    Nếu file đã tồn tại (cùng sha256):
        - Validate file cache — nếu hợp lệ thì touch mtime và trả URL
        - Nếu corrupt (quá nhỏ / sai magic bytes) → xóa và lưu lại blob mới
          (fix race condition: EMF convert thất bại lần đầu → cache corrupt
           → mọi lần sau đều trả URL của file corrupt)

    Returns:
        URL path dạng "/images/{sha256}.{ext}"
    """
    ensure_tmp_dir()
    ext  = _ext_for(mime)
    dest = _file_path(sha256, ext)

    if dest.exists():
        if _is_valid_cached_file(dest, ext):
            # File hợp lệ — touch mtime để không bị cleanup sớm
            dest.touch()
            return f"{URL_PREFIX}/{sha256}.{ext}"
        else:
            # File corrupt — xóa để lưu lại
            try:
                dest.unlink()
            except Exception:
                pass

    # Atomic write
    tmp_path = dest.with_suffix(f".{ext}.tmp")
    try:
        tmp_path.write_bytes(blob)
        tmp_path.rename(dest)
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise

    return f"{URL_PREFIX}/{sha256}.{ext}"


def image_url(sha256: str, mime: Optional[str] = None) -> Optional[str]:
    """
    Trả URL nếu file đã tồn tại và hợp lệ trên disk, None nếu chưa.
    """
    ext  = _ext_for(mime)
    path = _file_path(sha256, ext)
    if path.exists() and _is_valid_cached_file(path, ext):
        return f"{URL_PREFIX}/{sha256}.{ext}"
    return None


def get_image_path(sha256: str, mime: Optional[str] = None) -> Optional[Path]:
    """
    Trả Path object nếu file tồn tại — dùng trong route handler để serve.
    Thử tất cả extension nếu không biết mime.
    """
    if mime:
        ext = _ext_for(mime)
        p   = _file_path(sha256, ext)
        if p.exists() and _is_valid_cached_file(p, ext):
            return p
        return None

    # Thử tất cả ext đã biết
    for ext in _MIME_TO_EXT.values():
        p = _file_path(sha256, ext)
        if p.exists() and _is_valid_cached_file(p, ext):
            return p
    return None


def cleanup_old_images(max_age_hours: int = MAX_AGE_HOURS) -> int:
    """
    Xóa file cũ hơn max_age_hours. Trả về số file đã xóa.

    An toàn khi chạy concurrent — bỏ qua FileNotFoundError.
    """
    if not TMP_DIR.exists():
        return 0

    cutoff  = time.time() - max_age_hours * 3600
    deleted = 0

    for f in TMP_DIR.iterdir():
        if not f.is_file():
            continue
        try:
            if f.stat().st_mtime < cutoff:
                f.unlink()
                deleted += 1
        except FileNotFoundError:
            pass
        except Exception:
            pass

    return deleted