"""
diff/table/table_diff.py
~~~~~~~~~~~~~~~~~~~~~~~~
So sánh 2 table node ở mức row → cell → paragraph/image/nested table.

Chỉ chứa logic diff thuần. Utility và serialize đã tách ra:
  - table_helpers.py   : tree traversal, text extraction, structure detection
  - table_serialize.py : serialize DocNode → dict
  - table_analyze.py   : filter noise + chọn render mode

Fixes đã có:
  - SequenceMatcher trên row signature để align row trước khi diff
  - _diff_cell: xử lý nested table → text và ngược lại
  - _try_emit_merge: detect N rows → 1 row merge
  - _diff_one_row: map cell theo col_index thực, xử lý colspan thay đổi
  - _diff_cell_paragraphs: dùng SequenceMatcher thay zip cho paragraph
  - _diff_one_row_with_header_map: diff theo header mapping (Nhóm 2)
  - _diff_cell: emit build_image_equal cho ảnh unchanged

Fix mới:
  - _try_emit_unflatten: detect 1 row có nested table ↔ N flat rows
    Cả 2 chiều: gốc nested → mới flat, hoặc gốc flat → mới nested.
    Emit table_row_unflattened thay vì N table_row_added + 1 table_row_deleted.
    Frontend nhận đủ thông tin để gom và highlight row nào thay đổi.
"""

from __future__ import annotations

import difflib
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from src.services.models.docnode import DocNode
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.image_diff import images_equal, build_image_change, build_image_equal
from src.services.block.signature import _sig_row as _row_sig

from src.services.diff.table.table_helpers import (
    get_rows,
    get_cells,
    get_col_count,
    real_col_index,
    cell_text,
    cell_full_text,
    row_text,
    row_cell_texts,
    group_children_by_type,
    resolve_header_map,
)
from src.services.diff.table.table_serialize import (
    serialize_node,
    serialize_cell,
    serialize_row,
    build_row_display_cells,
)



# ══════════════════════════════════════════════════════════════════════════════
# Paragraph diff inside cell
# ══════════════════════════════════════════════════════════════════════════════

def _diff_paragraph(a: DocNode, b: DocNode) -> Optional[Dict[str, Any]]:
    """So sánh 2 paragraph node — text + image. Trả None nếu không đổi."""
    from src.services.extractor.utils import norm_text as _norm

    old_text    = _norm(a.content.get("text", ""))
    new_text    = _norm(b.content.get("text", ""))
    old_display = a.content.get("text_display") or old_text
    new_display = b.content.get("text_display") or new_text

    text_changed = old_text != new_text
    a_imgs = [c for c in (a.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.children or []) if c.type == "image"]

    if not text_changed and not a_imgs and not b_imgs:
        return None

    changes: List[Dict[str, Any]] = []

    if text_changed:
        word_diff   = diff_words(old_text, new_text, old_display=old_display, new_display=new_display)
        diff_result = word_diff if word_diff else {}
        changes.append({
            "type":             "paragraph_modified",
            "old_full_text":    diff_result.get("old_full_text", old_text),
            "new_full_text":    diff_result.get("new_full_text", new_text),
            "spans":            diff_result.get("spans", []),
            "original_content": a.content,
            "modified_content": b.content,
        })

    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if images_equal(ai, bi):
            changes.append(build_image_equal(ai, bi))
        else:
            changes.append(build_image_change(ai, bi))

    if not changes:
        return None

    return {
        "type":     "paragraph_container_modified",
        "original": serialize_node(a),
        "modified": serialize_node(b),
        "changes":  changes,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Paragraph list diff — dùng SequenceMatcher thay zip
# ══════════════════════════════════════════════════════════════════════════════

def _diff_cell_paragraphs(
    a_paras: List[DocNode],
    b_paras: List[DocNode],
) -> List[Dict[str, Any]]:
    """
    Diff list paragraph trong cell dùng SequenceMatcher trên text.
    Fix so với zip: align đúng khi insert dòng ở giữa cell.
    """
    from src.services.extractor.utils import norm_text as _norm

    changes: List[Dict[str, Any]] = []
    if not a_paras and not b_paras:
        return changes

    a_texts = [_norm(p.content.get("text", "")) for p in a_paras]
    b_texts = [_norm(p.content.get("text", "")) for p in b_paras]
    sm      = difflib.SequenceMatcher(a=a_texts, b=b_texts, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                changes.append({
                    "type":        "paragraph_unchanged",
                    "change_kind": "equal",
                    "original":    serialize_node(a_paras[i1 + k]),
                    "modified":    serialize_node(b_paras[j1 + k]),
                })

        elif tag == "insert":
            for j in range(j1, j2):
                changes.append({
                    "type":        "paragraph_inserted",
                    "change_kind": "insert",
                    "original":    None,
                    "modified":    serialize_node(b_paras[j]),
                })

        elif tag == "delete":
            for i in range(i1, i2):
                changes.append({
                    "type":        "paragraph_deleted",
                    "change_kind": "delete",
                    "original":    serialize_node(a_paras[i]),
                    "modified":    None,
                })

        elif tag == "replace":
            pairs = min(i2 - i1, j2 - j1)
            for k in range(pairs):
                ap         = a_paras[i1 + k]
                bp         = b_paras[j1 + k]
                para_change = _diff_paragraph(ap, bp)
                changes.append(para_change if para_change else {
                    "type":        "paragraph_unchanged",
                    "change_kind": "equal",
                    "original":    serialize_node(ap),
                    "modified":    serialize_node(bp),
                })
            for i in range(i1 + pairs, i2):
                changes.append({
                    "type":        "paragraph_deleted",
                    "change_kind": "delete",
                    "original":    serialize_node(a_paras[i]),
                    "modified":    None,
                })
            for j in range(j1 + pairs, j2):
                changes.append({
                    "type":        "paragraph_inserted",
                    "change_kind": "insert",
                    "original":    None,
                    "modified":    serialize_node(b_paras[j]),
                })

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Cell diff
# ══════════════════════════════════════════════════════════════════════════════

def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    from src.services.extractor.utils import norm_text as _norm

    changes: List[Dict[str, Any]] = []
    a_paras, a_imgs, a_tables = group_children_by_type(a)
    b_paras, b_imgs, b_tables = group_children_by_type(b)

    # ── Nested table → text ───────────────────────────────────────────────────
    if a_tables and not b_tables and b_paras:
        a_nested_text = " ".join(
            _norm(t.content.get("text_set", "") or t.content.get("text", ""))
            for t in a_tables
        )
        b_para_text = " ".join(_norm(p.content.get("text", "")) for p in b_paras)
        changes.append({
            "type":           "nested_table_to_text",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_nested_text,
            "new_text":       b_para_text,
            "original_table": serialize_node(a_tables[0]) if a_tables else None,
        })
        return changes

    # ── Text → nested table ───────────────────────────────────────────────────
    if b_tables and not a_tables and a_paras:
        a_para_text = " ".join(_norm(p.content.get("text", "")) for p in a_paras)
        b_nested_text = " ".join(
            _norm(t.content.get("text_set", "") or t.content.get("text", ""))
            for t in b_tables
        )
        changes.append({
            "type":           "text_to_nested_table",
            "change_kind":    "replace",
            "no_highlight":   True,
            "old_text":       a_para_text,
            "new_text":       b_nested_text,
            "modified_table": serialize_node(b_tables[0]) if b_tables else None,
        })
        return changes

    # ── Paragraph diff ────────────────────────────────────────────────────────
    changes.extend(_diff_cell_paragraphs(a_paras, b_paras))

    # ── Image diff ────────────────────────────────────────────────────────────
    for i in range(max(len(a_imgs), len(b_imgs))):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if ai is None and bi is not None:
            changes.append(build_image_change(None, bi))
        elif bi is None and ai is not None:
            changes.append(build_image_change(ai, None))
        elif ai is not None and bi is not None:
            if images_equal(ai, bi):
                changes.append(build_image_equal(ai, bi))
            else:
                changes.append(build_image_change(ai, bi))

    # ── Nested table diff — đệ quy ────────────────────────────────────────────
    for i in range(max(len(a_tables), len(b_tables))):
        at = a_tables[i] if i < len(a_tables) else None
        bt = b_tables[i] if i < len(b_tables) else None
        if at is None and bt is not None:
            changes.append({
                "type": "nested_table_inserted", "change_kind": "insert",
                "original": None, "modified": serialize_node(bt), "changes": [],
            })
        elif bt is None and at is not None:
            changes.append({
                "type": "nested_table_deleted", "change_kind": "delete",
                "original": serialize_node(at), "modified": None, "changes": [],
            })
        elif at is not None and bt is not None:
            nested_changes = diff_table(at, bt)
            if nested_changes:
                changes.append({
                    "type": "nested_table_modified", "change_kind": "replace",
                    "original": serialize_node(at), "modified": serialize_node(bt),
                    "changes": nested_changes,
                })
            else:
                changes.append({
                    "type": "nested_table_unchanged", "change_kind": "equal",
                    "original": serialize_node(at), "modified": serialize_node(bt),
                    "changes": [],
                })

    return changes


# ══════════════════════════════════════════════════════════════════════════════
# Row diff — standard (col_index mapping)
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_row(
    changes:  List[Dict[str, Any]],
    ar:       DocNode,
    br:       DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> None:
    """Diff 2 row theo col_index — dùng khi structure giống nhau."""
    a_cells   = get_cells(ar)
    b_cells   = get_cells(br)
    col_count = get_col_count(b_tbl) or get_col_count(a_tbl)

    def build_col_map(cells: List[DocNode]) -> Dict[int, DocNode]:
        m: Dict[int, DocNode] = {}
        for cell in cells:
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            for k in range(cs):
                m[ci + k] = cell
        return m

    a_map    = build_col_map(a_cells)
    b_map    = build_col_map(b_cells)
    all_cols = sorted(set(a_map) | set(b_map))

    row_changed       = False
    row_cell_changes: List[Dict[str, Any]] = []

    for col in all_cols:
        ac    = a_map.get(col)
        bc    = b_map.get(col)
        ac_ci = int((ac.content or {}).get("col_index", 0) or 0) if ac is not None else col
        bc_ci = int((bc.content or {}).get("col_index", 0) or 0) if bc is not None else col
        ac_is_cont = (ac is not None and ac_ci != col)
        bc_is_cont = (bc is not None and bc_ci != col)

        if ac_is_cont and bc_is_cont:
            continue

        if bc_is_cont and not ac_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue

        if ac_is_cont and not bc_is_cont:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue

        if ac is None and bc is not None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue

        if bc is None and ac is not None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue

        if ac is None or bc is None:
            continue

        a_cs = int((ac.content or {}).get("col_span", 1) or 1)
        b_cs = int((bc.content or {}).get("col_span", 1) or 1)

        if a_cs != b_cs:
            a_covered = sorted(
                {a_map[c] for c in range(col, col + b_cs) if c in a_map},
                key=lambda x: int((x.content or {}).get("col_index", 0) or 0),
            )
            a_combined = " ".join(cell_full_text(c) for c in a_covered if cell_full_text(c))
            b_text     = cell_full_text(bc)
            row_changed = True
            row_cell_changes.append({
                "type":           "table_cell_span_changed",
                "change_kind":    "replace",
                "col_index":      col,
                "left_cell":      serialize_cell(ac),
                "right_cell":     serialize_cell(bc),
                "left_text":      a_combined,
                "right_text":     b_text,
                "left_col_span":  a_cs,
                "right_col_span": b_cs,
                "left_cells":     [serialize_cell(c) for c in a_covered],
                "changes": [{
                    "type":          "paragraph_modified",
                    "old_full_text": a_combined,
                    "new_full_text": b_text,
                    "spans":         (diff_words(a_combined, b_text) or {}).get("spans", []),
                }],
            })
            continue

        cell_changes = _diff_cell(ac, bc)
        if cell_changes:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   col,
                "left_cell":   serialize_cell(ac),
                "right_cell":  serialize_cell(bc),
                "left_text":   cell_text(ac),
                "right_text":  cell_text(bc),
                "changes":     cell_changes,
            })

    if row_changed:
        changes.append({
            "type":        "table_row_modified",
            "change_kind": "replace",
            "row_index":   row_idx,
            "col_count":   col_count,
            "left_row":    serialize_row(ar),
            "right_row":   serialize_row(br),
            "left_cells":  [serialize_cell(c) for c in a_cells],
            "right_cells": [serialize_cell(c) for c in b_cells],
            "left_display_cells":  build_row_display_cells(a_tbl, ar),
            "right_display_cells": build_row_display_cells(b_tbl, br),
            "left_text":   row_text(ar),
            "right_text":  row_text(br),
            "cell_changes": row_cell_changes,
        })


# ══════════════════════════════════════════════════════════════════════════════
# Row diff — header-aware (fix thêm cột ở giữa — Nhóm 2)
# ══════════════════════════════════════════════════════════════════════════════

def _diff_one_row_with_header_map(
    changes:    List[Dict[str, Any]],
    ar:         DocNode,
    br:         DocNode,
    row_idx:    int,
    a_tbl:      DocNode,
    b_tbl:      DocNode,
    header_map: Dict[str, Any],
) -> None:
    """Diff 2 row theo header mapping thay vì col_index tuyệt đối (Nhóm 2)."""
    col_map      = header_map.get("col_map", {})
    added_cols   = set(header_map.get("added_cols", []))
    deleted_cols = set(header_map.get("deleted_cols", []))
    a_cells      = get_cells(ar)
    b_cells      = get_cells(br)
    col_count    = get_col_count(b_tbl) or get_col_count(a_tbl)

    def build_col_map(cells: List[DocNode]) -> Dict[int, DocNode]:
        m: Dict[int, DocNode] = {}
        for cell in cells:
            ci = int((cell.content or {}).get("col_index", 0) or 0)
            cs = int((cell.content or {}).get("col_span", 1) or 1)
            for k in range(cs):
                m[ci + k] = cell
        return m

    a_map = build_col_map(a_cells)
    b_map = build_col_map(b_cells)

    row_changed       = False
    row_cell_changes: List[Dict[str, Any]] = []

    for a_col, b_col in col_map.items():
        ac = a_map.get(a_col)
        bc = b_map.get(b_col)
        if ac is None and bc is None:
            continue
        if ac is None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": b_col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": cell_full_text(bc), "changes": [],
            })
            continue
        if bc is None:
            row_changed = True
            row_cell_changes.append({
                "type": "table_cell_deleted", "change_kind": "delete",
                "col_index": a_col, "left_cell": serialize_cell(ac),
                "right_cell": None, "left_text": cell_full_text(ac),
                "right_text": "", "changes": [],
            })
            continue
        cell_changes = _diff_cell(ac, bc)
        if cell_changes:
            row_changed = True
            row_cell_changes.append({
                "type":        "table_cell_modified",
                "change_kind": "replace",
                "col_index":   b_col,
                "left_cell":   serialize_cell(ac),
                "right_cell":  serialize_cell(bc),
                "left_text":   cell_text(ac),
                "right_text":  cell_text(bc),
                "changes":     cell_changes,
            })

    for a_col in sorted(deleted_cols):
        ac = a_map.get(a_col)
        if ac is None:
            continue
        row_changed = True
        row_cell_changes.append({
            "type": "table_cell_deleted", "change_kind": "delete",
            "col_index": a_col, "left_cell": serialize_cell(ac),
            "right_cell": None, "left_text": cell_full_text(ac),
            "right_text": "", "changes": [],
        })

    for b_col in sorted(added_cols):
        bc = b_map.get(b_col)
        if bc is None:
            continue
        row_changed = True
        row_cell_changes.append({
            "type": "table_cell_added", "change_kind": "insert",
            "col_index": b_col, "left_cell": None,
            "right_cell": serialize_cell(bc),
            "left_text": "", "right_text": cell_full_text(bc), "changes": [],
        })

    if row_changed:
        changes.append({
            "type":        "table_row_modified",
            "change_kind": "replace",
            "row_index":   row_idx,
            "col_count":   col_count,
            "left_row":    serialize_row(ar),
            "right_row":   serialize_row(br),
            "left_cells":  [serialize_cell(c) for c in a_cells],
            "right_cells": [serialize_cell(c) for c in b_cells],
            "left_display_cells":  build_row_display_cells(a_tbl, ar),
            "right_display_cells": build_row_display_cells(b_tbl, br),
            "left_text":   row_text(ar),
            "right_text":  row_text(br),
            "cell_changes": row_cell_changes,
        })


# ══════════════════════════════════════════════════════════════════════════════
# Row merge detection  (N rows → 1 row)
# ══════════════════════════════════════════════════════════════════════════════

def _rows_merged_into(
    a_rows:    List[DocNode],
    b_row:     DocNode,
    col_count: int,
) -> Optional[List[int]]:
    """
    Detect N rows cũ → 1 row mới (merge rows).
    Trả list index trong a_rows đã được merge, hoặc None.
    Cần ít nhất 2 rows để gọi là merge.
    """
    b_cell_texts = [cell_full_text(c) for c in get_cells(b_row)]
    b_full_text  = " ".join(t for t in b_cell_texts if t).lower()
    if not b_full_text:
        return None

    b_tokens: Set[str] = set()
    for raw in re.split(r"[,;\n]+", b_full_text):
        from src.services.extractor.utils import norm_text as _norm
        tok = _norm(raw)
        if tok:
            b_tokens.add(tok)

    merged_indices: List[int] = []
    for idx, a_row in enumerate(a_rows):
        a_texts = row_cell_texts(a_row)
        if not a_texts:
            continue
        from src.services.extractor.utils import norm_text as _norm
        all_found = all(
            t.lower() in b_tokens or t.lower() in b_full_text
            for t in a_texts if t
        )
        if all_found:
            merged_indices.append(idx)

    return merged_indices if len(merged_indices) >= 2 else None


def _try_emit_merge(
    changes:  List[Dict[str, Any]],
    a_slice:  List[DocNode],
    b_row:    DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> Optional[Set[int]]:
    """
    Thử detect và emit table_row_merged (N rows → 1 row).
    Trả set index đã consumed, hoặc None.
    """
    col_count   = get_col_count(b_tbl)
    merged_idxs = _rows_merged_into(a_slice, b_row, col_count)
    if merged_idxs is None:
        return None

    merged_a_rows   = [a_slice[i] for i in merged_idxs]
    a_combined_text = ", ".join(t for r in merged_a_rows for t in row_cell_texts(r) if t)
    b_cells         = get_cells(b_row)
    b_combined      = " ".join(cell_full_text(c) for c in b_cells if cell_full_text(c))
    cell_changes: List[Dict[str, Any]] = []

    for ci, bc in enumerate(b_cells):
        bc_text = cell_full_text(bc)
        if not bc_text:
            continue
        r_col = real_col_index(bc, ci)
        a_col_texts = [
            cell_full_text(ac)
            for ar in merged_a_rows
            for ac in get_cells(ar)
            if real_col_index(ac, -1) == r_col and cell_full_text(ac)
        ]
        if not a_col_texts:
            cell_changes.append({
                "type": "table_cell_added", "change_kind": "insert",
                "col_index": r_col, "left_cell": None,
                "right_cell": serialize_cell(bc),
                "left_text": "", "right_text": bc_text, "changes": [],
            })
        else:
            a_joined = ", ".join(a_col_texts)
            if a_joined != bc_text:
                cell_changes.append({
                    "type":        "table_cell_merged",
                    "change_kind": "replace",
                    "col_index":   r_col,
                    "left_cell":   serialize_cell(next(
                        (ac for ar in merged_a_rows for ac in get_cells(ar)
                         if real_col_index(ac, -1) == r_col), None
                    )),
                    "right_cell": serialize_cell(bc),
                    "left_text":  a_joined,
                    "right_text": bc_text,
                    "word_diff":  diff_words(a_joined, bc_text),
                    "changes":    [],
                })

    changes.append({
        "type":                "table_row_merged",
        "change_kind":         "replace",
        "row_index":           row_idx,
        "col_count":           col_count,
        "merged_from_rows":    [serialize_row(r) for r in merged_a_rows],
        "merged_from_count":   len(merged_a_rows),
        "left_row":            serialize_row(merged_a_rows[0]) if merged_a_rows else None,
        "right_row":           serialize_row(b_row),
        "left_cells":          [serialize_cell(c) for r in merged_a_rows for c in get_cells(r)],
        "right_cells":         [serialize_cell(c) for c in b_cells],
        "left_display_cells":  build_row_display_cells(a_tbl, merged_a_rows[0]),
        "right_display_cells": build_row_display_cells(b_tbl, b_row),
        "left_text":           a_combined_text,
        "right_text":          b_combined,
        "cell_changes":        cell_changes,
    })
    return set(merged_idxs)


# ══════════════════════════════════════════════════════════════════════════════
# Nested ↔ flat detection  (1 row nested table ↔ N flat rows)
# ══════════════════════════════════════════════════════════════════════════════

def _get_nested_table_rows(row: DocNode) -> Optional[Tuple[DocNode, DocNode, List[DocNode]]]:
    """
    Kiểm tra row có dạng [label_cell | cell_chứa_nested_table] không.

    Trả về (label_cell, nested_cell, nested_rows) nếu đúng dạng,
    hoặc None nếu không phải.

    Điều kiện:
    - Row phải có ít nhất 1 cell chứa nested table
    - Nested table phải có ít nhất 2 rows (nếu chỉ 1 row thì không phải unflatten)
    - Chọn cell có nested table đầu tiên (thường là cell cuối sau label)
    """
    cells = get_cells(row)
    for cell in cells:
        _, _, tables = group_children_by_type(cell)
        if tables:
            nested_tbl  = tables[0]
            nested_rows = get_rows(nested_tbl)
            if len(nested_rows) >= 2:
                return cell, nested_tbl, nested_rows
    return None

def _nested_aware_row_sig(row) -> str:
    from src.services.block.signature import _sig_row as _orig_sig_row
    from src.services.extractor.utils import norm_text as _norm

    nested_info = _get_nested_table_rows(row)
    if nested_info is None:
        return _orig_sig_row(row)

    _nested_cell, nested_tbl, nested_rows = nested_info
    cells = get_cells(row)
    outer_texts = []
    for cell in cells:
        _, _, tables = group_children_by_type(cell)
        if not tables:
            t = cell_full_text(cell)
            if t:
                outer_texts.append(_norm(t))

    outer_text = " ".join(outer_texts)
    return f"NESTED:{_norm(outer_text)}:{len(nested_rows)}"

def _extract_flat_row_texts(flat_row: DocNode) -> List[str]:
    """
    Lấy text của tất cả cell trong flat row (đã loại bỏ rỗng).
    Dùng để match với sub-row của nested table.
    """
    return [t for t in (cell_full_text(c) for c in get_cells(flat_row)) if t]


def _nested_row_matches_flat_row(
    nested_row:        DocNode,
    flat_row:          DocNode,
    outer_label_texts: Optional[Set[str]] = None,
) -> bool:
    """
    Kiểm tra 1 sub-row của nested table có tương ứng với 1 flat row không.

    Logic: lấy text của nested_row và flat_row (sau khi bỏ label cells lặp lại
    từ outer row), tính token overlap >= 50% thì coi là match.

    outer_label_texts: set text (đã norm, lower) của các outer cells không chứa
    nested table — cần bỏ ra khỏi flat row trước khi tính overlap, vì flat row
    lặp lại label ở mỗi dòng nhưng nested sub-row không có.
    """
    from src.services.extractor.utils import norm_text as _norm

    nested_texts = set(
        _norm(t).lower()
        for t in (cell_full_text(c) for c in get_cells(nested_row))
        if t
    )

    flat_texts_all = [
        _norm(t).lower()
        for t in _extract_flat_row_texts(flat_row)
        if t
    ]

    # Bỏ label cells lặp lại từ outer row trước khi tính overlap
    if outer_label_texts:
        flat_texts = [t for t in flat_texts_all if t not in outer_label_texts]
    else:
        flat_texts = flat_texts_all

    # Nếu sau khi bỏ label không còn gì → fallback về toàn bộ
    flat_set = set(flat_texts) if flat_texts else set(flat_texts_all)

    if not nested_texts or not flat_set:
        return False

    nested_tokens: Set[str] = set()
    for txt in nested_texts:
        nested_tokens.update(txt.split())
    flat_tokens: Set[str] = set()
    for txt in flat_set:
        flat_tokens.update(txt.split())

    if not nested_tokens:
        return False

    overlap = len(nested_tokens & flat_tokens)
    return overlap / len(nested_tokens) >= 0.5



def _diff_nested_vs_flat_row(
    nested_row: DocNode,
    flat_row:   DocNode,
    row_idx:    int,
) -> Optional[Dict[str, Any]]:
    """
    Diff 1 sub-row của nested table với 1 flat row tương ứng.

    Chỉ so sánh text khác nhau giữa nested sub-row và flat row,
    bỏ qua label cell lặp lại ở flat row.

    Trả None nếu không có thay đổi thật sự.
    """
    from src.services.extractor.utils import norm_text as _norm

    nested_cells = get_cells(nested_row)
    flat_cells   = get_cells(flat_row)

    # Lấy text từ nested sub-row (mỗi cell → 1 text)
    nested_texts = [cell_full_text(c) for c in nested_cells]
    # Lấy text từ flat row
    flat_texts = [cell_full_text(c) for c in flat_cells]

    # Tìm cell nào trong flat thật sự khác so với nested
    # Bỏ qua label cell (text xuất hiện ở cả 2)
    nested_set = {_norm(t).lower() for t in nested_texts if t}
    flat_unique = [t for t in flat_texts if _norm(t).lower() not in nested_set and t]
    nested_unique = [t for t in nested_texts if _norm(t).lower() not in {_norm(x).lower() for x in flat_texts} and t]

    if not flat_unique and not nested_unique:
        return None  # Không có thay đổi thật sự

    cell_changes: List[Dict[str, Any]] = []

    # Match nested cells vs flat cells theo text similarity
    nc_sigs = [_norm(cell_full_text(c)) for c in nested_cells]
    fc_sigs = [_norm(cell_full_text(c)) for c in flat_cells]

    sm = difflib.SequenceMatcher(a=nc_sigs, b=fc_sigs, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "replace":
            for k in range(min(i2 - i1, j2 - j1)):
                nc = nested_cells[i1 + k]
                fc = flat_cells[j1 + k]
                nt = cell_full_text(nc)
                ft = cell_full_text(fc)
                if _norm(nt) != _norm(ft):
                    cell_changes.append({
                        "type":        "table_cell_modified",
                        "change_kind": "replace",
                        "col_index":   int((nc.content or {}).get("col_index", k) or k),
                        "left_cell":   serialize_cell(nc),
                        "right_cell":  serialize_cell(fc),
                        "left_text":   nt,
                        "right_text":  ft,
                        "changes": [{
                            "type":          "paragraph_modified",
                            "old_full_text": nt,
                            "new_full_text": ft,
                            "spans":         (diff_words(nt, ft) or {}).get("spans", []),
                        }],
                    })
        elif tag == "insert":
            for j in range(j1, j2):
                fc = flat_cells[j]
                cell_changes.append({
                    "type": "table_cell_added", "change_kind": "insert",
                    "col_index": int((fc.content or {}).get("col_index", j) or j),
                    "left_cell": None, "right_cell": serialize_cell(fc),
                    "left_text": "", "right_text": cell_full_text(fc), "changes": [],
                })
        elif tag == "delete":
            for i in range(i1, i2):
                nc = nested_cells[i]
                cell_changes.append({
                    "type": "table_cell_deleted", "change_kind": "delete",
                    "col_index": int((nc.content or {}).get("col_index", i) or i),
                    "left_cell": serialize_cell(nc), "right_cell": None,
                    "left_text": cell_full_text(nc), "right_text": "", "changes": [],
                })

    return {
        "nested_row":   serialize_row(nested_row),
        "flat_row":     serialize_row(flat_row),
        "row_index":    row_idx,
        "has_changes":  bool(cell_changes),
        "cell_changes": cell_changes,
    }


def _try_emit_unflatten(
    changes:   List[Dict[str, Any]],
    a_row:     DocNode,
    b_slice:   List[DocNode],
    row_idx:   int,
    a_tbl:     DocNode,
    b_tbl:     DocNode,
    direction: str,
) -> Optional[Set[int]]:
    """
    Detect và emit table_row_unflattened.

    Cả 2 chiều:
    - direction="nested_to_flat": a_row có nested table, b_slice là flat rows
    - direction="flat_to_nested": a_row là flat row (dùng khi gọi ngược lại)

    Thuật toán:
    1. Lấy nested_rows từ nested table trong a_row
    2. Lấy outer_label_texts (cells không chứa nested table) để loại khỏi flat row khi match
    3. Match từng nested_row với flat_row trong b_slice theo token overlap
    4. Nếu match được ít nhất 1 cặp → emit table_row_unflattened
    5. Diff từng cặp matched → sub_row_diffs để frontend highlight thay đổi

    Trả về set index trong b_slice đã consumed, hoặc None nếu không detect được.
    """
    nested_info = _get_nested_table_rows(a_row)
    if nested_info is None:
        return None

    nested_cell, nested_tbl, nested_rows = nested_info

    from src.services.extractor.utils import norm_text as _norm

    # Lấy text của outer cells (không phải cell chứa nested table)
    # Dùng để loại label cells lặp lại khi so sánh flat row với nested sub-row
    outer_label_texts: Set[str] = set()
    for cell in get_cells(a_row):
        _, _, tables = group_children_by_type(cell)
        if not tables:
            t = cell_full_text(cell)
            if t:
                outer_label_texts.add(_norm(t).lower())

    nested_sigs = [
        " ".join(_norm(cell_full_text(c)) for c in get_cells(r))
        for r in nested_rows
    ]
    flat_sigs = [
        " ".join(_norm(cell_full_text(c)) for c in get_cells(r))
        for r in b_slice
    ]

    sm = difflib.SequenceMatcher(a=nested_sigs, b=flat_sigs, autojunk=False)

    matched_pairs: List[Tuple[int, int]] = []
    consumed_flat: Set[int] = set()

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ("equal", "replace"):
            for k in range(min(i2 - i1, j2 - j1)):
                ni = i1 + k
                fi = j1 + k
                if _nested_row_matches_flat_row(nested_rows[ni], b_slice[fi], outer_label_texts):
                    matched_pairs.append((ni, fi))
                    consumed_flat.add(fi)

    if not matched_pairs:
        return None

    if len(matched_pairs) < max(1, len(nested_rows) // 2):
        return None

    sub_row_diffs: List[Dict[str, Any]] = []
    for ni, fi in matched_pairs:
        diff = _diff_nested_vs_flat_row(
            nested_row=nested_rows[ni],
            flat_row=b_slice[fi],
            row_idx=fi,
        )
        if diff is not None:
            sub_row_diffs.append(diff)
        else:
            sub_row_diffs.append({
                "nested_row":   serialize_row(nested_rows[ni]),
                "flat_row":     serialize_row(b_slice[fi]),
                "row_index":    fi,
                "has_changes":  False,
                "cell_changes": [],
            })

    matched_nested = {ni for ni, _ in matched_pairs}
    unmatched_nested_rows = [
        serialize_row(nested_rows[ni])
        for ni in range(len(nested_rows))
        if ni not in matched_nested
    ]

    unmatched_flat_rows = [
        serialize_row(b_slice[fi])
        for fi in range(len(b_slice))
        if fi not in consumed_flat
    ]

    col_count   = get_col_count(b_tbl) or get_col_count(a_tbl)
    a_cells     = get_cells(a_row)
    b_cells_all = [c for fi in sorted(consumed_flat) for c in get_cells(b_slice[fi])]

    changes.append({
        "type":                   "table_row_unflattened",
        "change_kind":            "replace",
        "direction":              direction,
        "row_index":              row_idx,
        "col_count":              col_count,
        "left_row":               serialize_row(a_row),
        "left_cells":             [serialize_cell(c) for c in a_cells],
        "left_display_cells":     build_row_display_cells(a_tbl, a_row),
        "left_nested_table":      serialize_node(nested_tbl),
        "left_nested_rows":       [serialize_row(r) for r in nested_rows],
        "right_rows":             [serialize_row(b_slice[fi]) for fi in sorted(consumed_flat)],
        "right_rows_count":       len(consumed_flat),
        "right_cells_all":        [serialize_cell(c) for c in b_cells_all],
        "sub_row_diffs":          sub_row_diffs,
        "unmatched_nested_rows":  unmatched_nested_rows,
        "unmatched_flat_rows":    unmatched_flat_rows,
        "left_text":              row_text(a_row),
        "right_text":             " | ".join(row_text(b_slice[fi]) for fi in sorted(consumed_flat)),
    })

    return consumed_flat

def _try_emit_unflatten_reverse(
    changes:  List[Dict[str, Any]],
    a_slice:  List[DocNode],
    b_row:    DocNode,
    row_idx:  int,
    a_tbl:    DocNode,
    b_tbl:    DocNode,
) -> Optional[Set[int]]:
    """
    Chiều ngược: a_slice là flat rows, b_row có nested table.
    Wrap lại _try_emit_unflatten với a/b đổi chỗ, rồi đổi ngược left/right.

    Trả set index trong a_slice đã consumed, hoặc None.
    """
    nested_info = _get_nested_table_rows(b_row)
    if nested_info is None:
        return None

    nested_cell, nested_tbl, nested_rows = nested_info
    from src.services.extractor.utils import norm_text as _norm

    nested_sigs = [
        " ".join(_norm(cell_full_text(c)) for c in get_cells(r))
        for r in nested_rows
    ]
    flat_sigs = [
        " ".join(_norm(cell_full_text(c)) for c in get_cells(r))
        for r in a_slice
    ]

    sm = difflib.SequenceMatcher(a=nested_sigs, b=flat_sigs, autojunk=False)

    matched_pairs: List[Tuple[int, int]] = []
    consumed_flat: Set[int] = set()

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ("equal", "replace"):
            for k in range(min(i2 - i1, j2 - j1)):
                ni = i1 + k
                fi = j1 + k
                if _nested_row_matches_flat_row(nested_rows[ni], a_slice[fi]):
                    matched_pairs.append((ni, fi))
                    consumed_flat.add(fi)

    if not matched_pairs:
        return None
    if len(matched_pairs) < max(1, len(nested_rows) // 2):
        return None

    sub_row_diffs: List[Dict[str, Any]] = []
    for ni, fi in matched_pairs:
        # Chiều ngược: flat là gốc (a), nested là mới (b)
        diff = _diff_nested_vs_flat_row(
            nested_row=nested_rows[ni],
            flat_row=a_slice[fi],
            row_idx=fi,
        )
        if diff is not None:
            # Đổi chiều left/right
            diff["nested_row"], diff["flat_row"] = diff["flat_row"], diff["nested_row"]
            sub_row_diffs.append(diff)
        else:
            sub_row_diffs.append({
                "nested_row":   serialize_row(a_slice[fi]),
                "flat_row":     serialize_row(nested_rows[ni]),
                "row_index":    fi,
                "has_changes":  False,
                "cell_changes": [],
            })

    matched_nested = {ni for ni, _ in matched_pairs}
    unmatched_nested_rows = [
        serialize_row(nested_rows[ni])
        for ni in range(len(nested_rows))
        if ni not in matched_nested
    ]
    unmatched_flat_rows = [
        serialize_row(a_slice[fi])
        for fi in range(len(a_slice))
        if fi not in consumed_flat
    ]

    col_count    = get_col_count(b_tbl) or get_col_count(a_tbl)
    b_cells      = get_cells(b_row)
    a_cells_all  = [c for fi in sorted(consumed_flat) for c in get_cells(a_slice[fi])]

    changes.append({
        "type":                   "table_row_unflattened",
        "change_kind":            "replace",
        "direction":              "flat_to_nested",
        # -- Gốc (flat) --
        "row_index":              row_idx,
        "col_count":              col_count,
        "left_rows":              [serialize_row(a_slice[fi]) for fi in sorted(consumed_flat)],
        "left_rows_count":        len(consumed_flat),
        "left_cells_all":         [serialize_cell(c) for c in a_cells_all],
        # -- Mới (nested) --
        "right_row":              serialize_row(b_row),
        "right_cells":            [serialize_cell(c) for c in b_cells],
        "right_display_cells":    build_row_display_cells(b_tbl, b_row),
        "right_nested_table":     serialize_node(nested_tbl),
        "right_nested_rows":      [serialize_row(r) for r in nested_rows],
        # -- Diff chi tiết --
        "sub_row_diffs":          sub_row_diffs,
        "unmatched_nested_rows":  unmatched_nested_rows,
        "unmatched_flat_rows":    unmatched_flat_rows,
        # -- Text summary --
        "left_text":              " | ".join(row_text(a_slice[fi]) for fi in sorted(consumed_flat)),
        "right_text":             row_text(b_row),
    })

    return consumed_flat


# ══════════════════════════════════════════════════════════════════════════════
# Main diff_table
# ══════════════════════════════════════════════════════════════════════════════

def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    """
    So sánh 2 table node, trả về list changes.

    Luồng xử lý replace opcode:
    ┌─────────────────────────────────────────────────────────────┐
    │ n_a == 1, n_b > 1                                           │
    │   → thử _try_emit_unflatten (nested_to_flat)               │
    │   → fallback: emit 1 delete + n_b insert                   │
    ├─────────────────────────────────────────────────────────────┤
    │ n_a > 1, n_b == 1                                           │
    │   → thử _try_emit_unflatten_reverse (flat_to_nested)       │
    │   → thử _try_emit_merge (N rows → 1 row)                   │
    │   → fallback: emit n_a delete + 1 insert                   │
    ├─────────────────────────────────────────────────────────────┤
    │ n_a > n_b > 1                                               │
    │   → thử merge detection từng b_row                         │
    │   → fallback: 1-1 diff + delete/insert thừa                │
    ├─────────────────────────────────────────────────────────────┤
    │ n_b >= n_a                                                  │
    │   → inner SequenceMatcher                                   │
    └─────────────────────────────────────────────────────────────┘
    """
    from src.services.diff.table.table_helpers import detect_structure_change

    changes: List[Dict[str, Any]] = []
    a_rows = get_rows(a_tbl)
    b_rows = get_rows(b_tbl)

    if not a_rows and not b_rows:
        return changes

    structure_changed = detect_structure_change(a_tbl, b_tbl)
    header_map: Optional[Dict[str, Any]] = None
    use_header_diff = False

    if structure_changed:
        header_map = resolve_header_map(a_tbl, b_tbl)
        use_header_diff = (
            header_map.get("has_header", False)
            and len(header_map.get("col_map", {})) > 0
        )

    a_sigs = [_nested_aware_row_sig(r) for r in a_rows]
    b_sigs = [_nested_aware_row_sig(r) for r in b_rows]
    sm     = difflib.SequenceMatcher(a=a_sigs, b=b_sigs, autojunk=False)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():

        if tag == "equal":
            continue

        if tag == "insert":
            for jr in range(j1, j2):
                br      = b_rows[jr]
                b_cells = get_cells(br)
                changes.append({
                    "type":        "table_row_added",
                    "change_kind": "insert",
                    "row_index":   jr,
                    "col_count":   get_col_count(b_tbl),
                    "left_row":    None,
                    "right_row":   serialize_row(br),
                    "left_cells":  [],
                    "right_cells": [serialize_cell(c) for c in b_cells],
                    "right_display_cells": build_row_display_cells(b_tbl, br),
                    "left_text":   "",
                    "right_text":  row_text(br),
                    "cell_changes": [],
                })
            continue

        if tag == "delete":
            for ir in range(i1, i2):
                ar      = a_rows[ir]
                a_cells = get_cells(ar)
                changes.append({
                    "type":        "table_row_deleted",
                    "change_kind": "delete",
                    "row_index":   ir,
                    "col_count":   get_col_count(a_tbl),
                    "left_row":    serialize_row(ar),
                    "right_row":   None,
                    "left_cells":  [serialize_cell(c) for c in a_cells],
                    "right_cells": [],
                    "left_display_cells": build_row_display_cells(a_tbl, ar),
                    "left_text":   row_text(ar),
                    "right_text":  "",
                    "cell_changes": [],
                })
            continue

        if tag != "replace":
            continue

        a_slice = a_rows[i1:i2]
        b_slice = b_rows[j1:j2]
        n_a     = len(a_slice)
        n_b     = len(b_slice)

        def _do_diff_row(ar: DocNode, br: DocNode, ridx: int) -> None:
            if use_header_diff:
                _diff_one_row_with_header_map(changes, ar, br, ridx, a_tbl, b_tbl, header_map)
            else:
                _diff_one_row(changes, ar, br, ridx, a_tbl, b_tbl)

        # ── Case: 1 nested row ↔ N flat rows ─────────────────────────────────
        # Gốc có 1 row chứa nested table, mới có nhiều flat rows
        if n_a == 1 and n_b > 1:
            consumed = _try_emit_unflatten(
                changes=changes,
                a_row=a_slice[0],
                b_slice=b_slice,
                row_idx=i1,
                a_tbl=a_tbl,
                b_tbl=b_tbl,
                direction="nested_to_flat",
            )
            if consumed is not None:
                # Emit unmatched flat rows là table_row_added
                for fi in range(n_b):
                    if fi not in consumed:
                        br      = b_slice[fi]
                        b_cells = get_cells(br)
                        changes.append({
                            "type":        "table_row_added",
                            "change_kind": "insert",
                            "row_index":   j1 + fi,
                            "col_count":   get_col_count(b_tbl),
                            "left_row":    None,
                            "right_row":   serialize_row(br),
                            "left_cells":  [],
                            "right_cells": [serialize_cell(c) for c in b_cells],
                            "right_display_cells": build_row_display_cells(b_tbl, br),
                            "left_text":   "",
                            "right_text":  row_text(br),
                            "cell_changes": [],
                        })
            else:
                # Fallback: không detect được → 1 delete + N insert
                ar      = a_slice[0]
                a_cells = get_cells(ar)
                changes.append({
                    "type":        "table_row_deleted",
                    "change_kind": "delete",
                    "row_index":   i1,
                    "col_count":   get_col_count(a_tbl),
                    "left_row":    serialize_row(ar),
                    "right_row":   None,
                    "left_cells":  [serialize_cell(c) for c in a_cells],
                    "right_cells": [],
                    "left_display_cells": build_row_display_cells(a_tbl, ar),
                    "left_text":   row_text(ar),
                    "right_text":  "",
                    "cell_changes": [],
                })
                for fi, br in enumerate(b_slice):
                    b_cells = get_cells(br)
                    changes.append({
                        "type":        "table_row_added",
                        "change_kind": "insert",
                        "row_index":   j1 + fi,
                        "col_count":   get_col_count(b_tbl),
                        "left_row":    None,
                        "right_row":   serialize_row(br),
                        "left_cells":  [],
                        "right_cells": [serialize_cell(c) for c in b_cells],
                        "right_display_cells": build_row_display_cells(b_tbl, br),
                        "left_text":   "",
                        "right_text":  row_text(br),
                        "cell_changes": [],
                    })
            continue

        # ── Case: N flat rows ↔ 1 nested row ─────────────────────────────────
        # Gốc có nhiều flat rows, mới có 1 row chứa nested table
        if n_b == 1 and n_a > 1:
            # Thử chiều flat → nested trước
            consumed = _try_emit_unflatten_reverse(
                changes=changes,
                a_slice=a_slice,
                b_row=b_slice[0],
                row_idx=j1,
                a_tbl=a_tbl,
                b_tbl=b_tbl,
            )
            if consumed is not None:
                # Emit unmatched flat rows (gốc) là table_row_deleted
                for fi in range(n_a):
                    if fi not in consumed:
                        ar      = a_slice[fi]
                        a_cells = get_cells(ar)
                        changes.append({
                            "type":        "table_row_deleted",
                            "change_kind": "delete",
                            "row_index":   i1 + fi,
                            "col_count":   get_col_count(a_tbl),
                            "left_row":    serialize_row(ar),
                            "right_row":   None,
                            "left_cells":  [serialize_cell(c) for c in a_cells],
                            "right_cells": [],
                            "left_display_cells": build_row_display_cells(a_tbl, ar),
                            "left_text":   row_text(ar),
                            "right_text":  "",
                            "cell_changes": [],
                        })
                continue

            # Thử merge (N rows → 1 row, không phải unflatten)
            merged = _try_emit_merge(
                changes=changes,
                a_slice=a_slice,
                b_row=b_slice[0],
                row_idx=j1,
                a_tbl=a_tbl,
                b_tbl=b_tbl,
            )
            if merged is not None:
                remaining_indices = list(range(n_a))
                for ci in merged:
                    if ci < len(remaining_indices):
                        remaining_indices[ci] = -1
                for i, ar in enumerate(a_slice):
                    if i not in merged:
                        a_cells = get_cells(ar)
                        changes.append({
                            "type":        "table_row_deleted",
                            "change_kind": "delete",
                            "row_index":   i1 + i,
                            "col_count":   get_col_count(a_tbl),
                            "left_row":    serialize_row(ar),
                            "right_row":   None,
                            "left_cells":  [serialize_cell(c) for c in a_cells],
                            "right_cells": [],
                            "left_display_cells": build_row_display_cells(a_tbl, ar),
                            "left_text":   row_text(ar),
                            "right_text":  "",
                            "cell_changes": [],
                        })
                continue

            # Fallback: N delete + 1 insert
            for i, ar in enumerate(a_slice):
                a_cells = get_cells(ar)
                changes.append({
                    "type":        "table_row_deleted",
                    "change_kind": "delete",
                    "row_index":   i1 + i,
                    "col_count":   get_col_count(a_tbl),
                    "left_row":    serialize_row(ar),
                    "right_row":   None,
                    "left_cells":  [serialize_cell(c) for c in a_cells],
                    "right_cells": [],
                    "left_display_cells": build_row_display_cells(a_tbl, ar),
                    "left_text":   row_text(ar),
                    "right_text":  "",
                    "cell_changes": [],
                })
            br      = b_slice[0]
            b_cells = get_cells(br)
            changes.append({
                "type":        "table_row_added",
                "change_kind": "insert",
                "row_index":   j1,
                "col_count":   get_col_count(b_tbl),
                "left_row":    None,
                "right_row":   serialize_row(br),
                "left_cells":  [],
                "right_cells": [serialize_cell(c) for c in b_cells],
                "right_display_cells": build_row_display_cells(b_tbl, br),
                "left_text":   "",
                "right_text":  row_text(br),
                "cell_changes": [],
            })
            continue

        # ── Case: n_a > n_b > 1 ──────────────────────────────────────────────
        if n_a > n_b:
            consumed_a: Set[int] = set()

            for k, br in enumerate(b_slice):
                remaining_a = [a_slice[i] for i in range(n_a) if i not in consumed_a]
                consumed    = None

                if len(remaining_a) >= 2:
                    consumed = _try_emit_merge(
                        changes=changes, a_slice=remaining_a,
                        b_row=br, row_idx=j1 + k, a_tbl=a_tbl, b_tbl=b_tbl,
                    )

                if consumed is not None:
                    remaining_indices = [i for i in range(n_a) if i not in consumed_a]
                    for ci in consumed:
                        consumed_a.add(remaining_indices[ci])
                else:
                    first_avail = next(
                        (i for i in range(n_a) if i not in consumed_a), None
                    )
                    if first_avail is not None:
                        _do_diff_row(a_slice[first_avail], br, i1 + first_avail)
                        consumed_a.add(first_avail)

            for i in range(n_a):
                if i not in consumed_a:
                    ar      = a_slice[i]
                    a_cells = get_cells(ar)
                    changes.append({
                        "type":        "table_row_deleted",
                        "change_kind": "delete",
                        "row_index":   i1 + i,
                        "col_count":   get_col_count(a_tbl),
                        "left_row":    serialize_row(ar),
                        "right_row":   None,
                        "left_cells":  [serialize_cell(c) for c in a_cells],
                        "right_cells": [],
                        "left_display_cells": build_row_display_cells(a_tbl, ar),
                        "left_text":   row_text(ar),
                        "right_text":  "",
                        "cell_changes": [],
                    })
            continue

        # ── Case: n_b >= n_a — inner SequenceMatcher ─────────────────────────
        inner_a_sigs = [_row_sig(r) for r in a_slice]
        inner_b_sigs = [_row_sig(r) for r in b_slice]
        inner_sm     = difflib.SequenceMatcher(
            a=inner_a_sigs, b=inner_b_sigs, autojunk=False
        )

        for inner_tag, ia1, ia2, ib1, ib2 in inner_sm.get_opcodes():
            if inner_tag == "equal":
                continue

            if inner_tag == "insert":
                for jj in range(ib1, ib2):
                    br      = b_slice[jj]
                    b_cells = get_cells(br)
                    changes.append({
                        "type":        "table_row_added",
                        "change_kind": "insert",
                        "row_index":   j1 + jj,
                        "col_count":   get_col_count(b_tbl),
                        "left_row":    None,
                        "right_row":   serialize_row(br),
                        "left_cells":  [],
                        "right_cells": [serialize_cell(c) for c in b_cells],
                        "right_display_cells": build_row_display_cells(b_tbl, br),
                        "left_text":   "",
                        "right_text":  row_text(br),
                        "cell_changes": [],
                    })

            elif inner_tag == "delete":
                for ii in range(ia1, ia2):
                    ar      = a_slice[ii]
                    a_cells = get_cells(ar)
                    changes.append({
                        "type":        "table_row_deleted",
                        "change_kind": "delete",
                        "row_index":   i1 + ii,
                        "col_count":   get_col_count(a_tbl),
                        "left_row":    serialize_row(ar),
                        "right_row":   None,
                        "left_cells":  [serialize_cell(c) for c in a_cells],
                        "right_cells": [],
                        "left_display_cells": build_row_display_cells(a_tbl, ar),
                        "left_text":   row_text(ar),
                        "right_text":  "",
                        "cell_changes": [],
                    })

            elif inner_tag == "replace":
                # Thử detect unflatten trong inner slice trước
                # Case: 1 nested ↔ nhiều flat trong inner slice
                ia_slice = a_slice[ia1:ia2]
                ib_slice = b_slice[ib1:ib2]

                if len(ia_slice) == 1 and len(ib_slice) > 1:
                    consumed = _try_emit_unflatten(
                        changes=changes,
                        a_row=ia_slice[0],
                        b_slice=ib_slice,
                        row_idx=i1 + ia1,
                        a_tbl=a_tbl,
                        b_tbl=b_tbl,
                        direction="nested_to_flat",
                    )
                    if consumed is not None:
                        for fi in range(len(ib_slice)):
                            if fi not in consumed:
                                br      = ib_slice[fi]
                                b_cells = get_cells(br)
                                changes.append({
                                    "type":        "table_row_added",
                                    "change_kind": "insert",
                                    "row_index":   j1 + ib1 + fi,
                                    "col_count":   get_col_count(b_tbl),
                                    "left_row":    None,
                                    "right_row":   serialize_row(br),
                                    "left_cells":  [],
                                    "right_cells": [serialize_cell(c) for c in b_cells],
                                    "right_display_cells": build_row_display_cells(b_tbl, br),
                                    "left_text":   "",
                                    "right_text":  row_text(br),
                                    "cell_changes": [],
                                })
                        continue

                inner_pairs = min(ia2 - ia1, ib2 - ib1)
                for k in range(inner_pairs):
                    _do_diff_row(a_slice[ia1 + k], b_slice[ib1 + k], i1 + ia1 + k)

                for ii in range(ia1 + inner_pairs, ia2):
                    ar      = a_slice[ii]
                    a_cells = get_cells(ar)
                    changes.append({
                        "type":        "table_row_deleted",
                        "change_kind": "delete",
                        "row_index":   i1 + ii,
                        "col_count":   get_col_count(a_tbl),
                        "left_row":    serialize_row(ar),
                        "right_row":   None,
                        "left_cells":  [serialize_cell(c) for c in a_cells],
                        "right_cells": [],
                        "left_display_cells": build_row_display_cells(a_tbl, ar),
                        "left_text":   row_text(ar),
                        "right_text":  "",
                        "cell_changes": [],
                    })

                for jj in range(ib1 + inner_pairs, ib2):
                    br      = b_slice[jj]
                    b_cells = get_cells(br)
                    changes.append({
                        "type":        "table_row_added",
                        "change_kind": "insert",
                        "row_index":   j1 + jj,
                        "col_count":   get_col_count(b_tbl),
                        "left_row":    None,
                        "right_row":   serialize_row(br),
                        "left_cells":  [],
                        "right_cells": [serialize_cell(c) for c in b_cells],
                        "right_display_cells": build_row_display_cells(b_tbl, br),
                        "left_text":   "",
                        "right_text":  row_text(br),
                        "cell_changes": [],
                    })

    return changes