"""
block/signature.py
~~~~~~~~~~~~~~~~~~
Tạo fingerprint cho mỗi DocNode.

Nguyên tắc thiết kế:
1. STABLE     — cùng nội dung, khác vị trí trong file → signature giống nhau
2. SENSITIVE  — khác nội dung dù nhỏ → signature khác nhau
3. NO TRUNCATE — không cắt text trước khi hash (tránh collision bảng lớn)
4. SEMANTIC   — chỉ hash những gì có nghĩa với người dùng,
                bỏ qua metadata format (run_count, alignment None vs LEFT...)

─────────────────────────────────────────────────────────────────────────────
TWO-SIGNATURE DESIGN cho table
─────────────────────────────────────────────────────────────────────────────

  • equality_sig  = signature(node)               — text + ảnh + structure
                    dùng để detect CHANGE bên trong block sau khi đã match
  • identity_sig  = table_identity_sig(node)       — text only, stable
                    dùng để MATCH block giữa 2 phiên bản (sequence_align)

─────────────────────────────────────────────────────────────────────────────
Cell identity — phân loại theo layout_type (từ extract)
─────────────────────────────────────────────────────────────────────────────

  layout_type="text"         → hash(full_text)
  layout_type="mixed"        → hash(full_text), bỏ ảnh
  layout_type="image"        → f"img_only:{col_index}:{image_count}"
  layout_type="nested_table" → hash(nested_text)  — stable với layout bên trong
  layout_type="empty"        → f"empty:{col_index}"
  layout_type không có       → fallback walk children (node cũ)

Lý do image và empty dùng col_index: tránh collision khi nhiều cell
cùng loại trong 1 row (ví dụ: nhiều cell ảnh cùng row).

Export công khai:
    signature(node, heading_ctx="")          — equality sig
    table_identity_sig(node, heading_ctx="") — identity sig cho table matching
    _norm_text                               — dùng bởi block_builder, sequence_align
    _split_heading                           — dùng bởi sequence_align
    _hash                                    — dùng bởi sequence_align
"""

from __future__ import annotations

import hashlib
import re
from typing import List, Tuple

from src.services.models.docnode import DocNode
from src.services.extractor.utils import norm_text as _norm_text
from src.services.extractor.shape.shape_content import collect_shape_parts


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _hash(value: str, length: int = 16) -> str:
    """
    MD5 hash truncate tới `length` hex chars.
    Trả "empty" nếu value rỗng — giúp debug đọc signature dễ hơn.
    KHÔNG truncate value trước khi hash — tránh collision bảng lớn.
    """
    if not value:
        return "empty"
    return hashlib.md5(value.encode("utf-8")).hexdigest()[:length]


def _norm_alignment(align) -> str:
    """
    Chuẩn hoá alignment về string nhất quán.
    Word trả None (= LEFT mặc định) hoặc WD_ALIGN_PARAGRAPH.LEFT
    → cả 2 map về "LEFT" để không tạo false diff.
    """
    if align is None:
        return "LEFT"
    s = str(align).upper().strip()
    if "." in s:
        s = s.split(".")[-1]
    return s or "LEFT"


# ══════════════════════════════════════════════════════════════════════════════
# Heading split
# ══════════════════════════════════════════════════════════════════════════════

_CHAPTER_RE = re.compile(r"^(\d+(?:\.\d+)*)\s+(.*)", re.DOTALL)


def _split_heading(text: str) -> Tuple[str, str]:
    """
    Tách số chương khỏi nội dung heading.

    "5.2 Phân tích kết quả" → ("5.2", "phân tích kết quả")
    "Giới thiệu"            → ("",    "giới thiệu")

    Dùng bởi:
    1. sequence_align — match heading dù số chương thay đổi (heading shift bug)
    2. _heading_ctx_body_from_sig — chuẩn hoá heading_ctx trong identity sig
    """
    t = _norm_text(text).lower()
    m = _CHAPTER_RE.match(t)
    if m:
        return m.group(1), m.group(2).strip()
    return "", t


def _heading_ctx_body_from_sig(heading_ctx: str) -> str:
    """
    Bỏ số chương khỏi toàn bộ heading breadcrumb.

    "5.1 Chuẩn bị > 5.1.2 Kiểm tra" → "chuẩn bị > kiểm tra"

    Tách riêng để tránh circular import với sequence_align
    (sequence_align import _split_heading từ đây).
    """
    if not heading_ctx:
        return ""
    parts  = heading_ctx.split(" > ")
    bodies = []
    for part in parts:
        _, body = _split_heading(part)
        bodies.append(body)
    return " > ".join(bodies)


# ══════════════════════════════════════════════════════════════════════════════
# EQUALITY signature builders
# (detect CHANGE bên trong block sau khi đã match)
# ══════════════════════════════════════════════════════════════════════════════

def _sig_heading(node: DocNode) -> str:
    """H{level}:{text_hash} — chỉ text + level, bỏ style (redundant với level)."""
    txt   = _norm_text(node.content.get("text", ""))
    level = int(node.content.get("level", 0) or 0)
    return f"H{level}:{_hash(txt)}"


def _sig_paragraph(node: DocNode) -> str:
    """
    P:{text_hash}:{style_hash}:{alignment}

    Bỏ run_count — cùng text có thể 1 hay 2 run tuỳ Word.
    Bỏ space_before/after — false diff khi copy-paste giữa template.
    Giữ alignment — thay đổi có nghĩa, chuẩn hoá None → LEFT.
    """
    txt   = _norm_text(node.content.get("text", ""))
    style = _norm_text(node.content.get("style", "") or "")
    align = _norm_alignment(node.content.get("alignment"))
    return f"P:{_hash(txt)}:{_hash(style, 8)}:{align}"


def _sig_table(node: DocNode) -> str:
    """
    T:{row_count}x{col_count}:{content_hash}

    Equality sig — hash toàn bộ row/cell/image để detect mọi thay đổi
    kể cả ảnh đổi layout bên trong cell.
    """
    rows = int(node.content.get("row_count", 0) or 0)
    cols = int(node.content.get("col_count", 0) or 0)

    if node.children:
        children_sig = "|".join(
            _sig_row(r) for r in node.children if r.type == "row"
        )
        return f"T:{rows}x{cols}:{_hash(children_sig)}"

    txt = _norm_text(node.content.get("text", ""))
    return f"T:{rows}x{cols}:{_hash(txt)}"


def _sig_row(node: DocNode) -> str:
    """
    R:{cells_hash}

    Không dùng row_index — thêm/xóa row đầu làm shift toàn bộ index
    → tất cả row sau bị báo modified dù nội dung không đổi.
    """
    if node.children:
        cells_sig = "|".join(
            _sig_cell(c) for c in node.children if c.type == "cell"
        )
        return f"R:{_hash(cells_sig)}"

    row_text = _norm_text(node.content.get("text", ""))
    return f"R:{_hash(row_text)}"


def _sig_cell(node: DocNode) -> str:
    """
    C:{content_hash}

    Equality sig — hash toàn bộ nội dung cell theo thứ tự XML:
    - paragraph: text + ảnh inline (sha256)
    - image:     direct child — sha256
    - table:     nested table — _sig_table đệ quy
    """
    parts: List[str] = []

    if node.children:
        for child in node.children:
            if child.type == "paragraph":
                txt = _norm_text(child.content.get("text", ""))
                if txt:
                    parts.append(txt)
                for gc in (child.children or []):
                    if gc.type == "image":
                        sha = gc.content.get("sha256", "") or ""
                        if sha:
                            parts.append(f"img:{sha[:16]}")
                        else:
                            uid = getattr(gc, "uid", "") or ""
                            parts.append(f"img:nosha:{_hash(uid, 8)}")

            elif child.type == "image":
                sha = child.content.get("sha256", "") or ""
                if sha:
                    parts.append(f"img:{sha[:16]}")
                else:
                    name     = child.content.get("name", "") or ""
                    w        = child.content.get("width_emu", 0) or 0
                    h        = child.content.get("height_emu", 0) or 0
                    fallback = name or f"{w}x{h}"
                    parts.append(f"img:nosha:{_hash(fallback, 8)}")

            elif child.type == "table":
                parts.append(_sig_table(child))

    else:
        # Fallback khi không có children — dùng full_text (bao gồm nested content)
        txt = _norm_text(
            node.content.get("full_text", "")
            or node.content.get("text", "")
        )
        if txt:
            parts.append(txt)

    combined = "|".join(parts)
    return f"C:{_hash(combined)}"


def _sig_image(node: DocNode) -> str:
    """
    I:{sha256}:{width}x{height}

    Fallback theo thứ tự độ tin cậy: sha256 → name → data_uri → uid.
    """
    sha    = (node.content.get("sha256", "") or "").strip()
    width  = int(node.content.get("width_emu",  0) or 0)
    height = int(node.content.get("height_emu", 0) or 0)

    if sha:
        return f"I:{sha[:16]}:{width}x{height}"

    name = _norm_text(node.content.get("name", "") or "")
    if name:
        return f"I:{_hash(name, 12)}:{width}x{height}"

    data_uri = node.content.get("data_uri", "") or ""
    if data_uri:
        return f"I:{_hash(data_uri, 16)}:{width}x{height}"

    uid = getattr(node, "uid", "") or ""
    return f"I:nodata:{_hash(uid, 8)}:{width}x{height}"


def _sig_shape(node: DocNode, heading_ctx: str = "") -> str:
    """
    S:{shape_type}:{content_hash}

    Dùng collect_shape_parts — nguồn sự thật duy nhất về nội dung shape.
    heading_ctx inject vào để phân biệt 2 shape cùng nội dung ở 2 section khác.
    Shape rỗng: dùng parent_uid + uid + heading_ctx làm stable identity.
    """
    shape_type = node.content.get("shape_type", "") or ""
    parts      = collect_shape_parts(node)
    combined   = " | ".join(parts)

    if not combined:
        parent_uid = getattr(node, "parent_uid", "") or ""
        uid        = getattr(node, "uid", "") or ""
        stable_id  = _hash(f"{parent_uid}:{uid}:{heading_ctx}", 8)
        return f"S:{shape_type}:empty:{stable_id}"

    if heading_ctx:
        combined = f"{heading_ctx}||{combined}"
    return f"S:{shape_type}:{_hash(combined)}"


# ══════════════════════════════════════════════════════════════════════════════
# IDENTITY signature builders — table matching
# (MATCH block giữa 2 phiên bản — text only, stable trước ảnh đổi layout)
# ══════════════════════════════════════════════════════════════════════════════

def _cell_identity_sig(node: DocNode) -> str:
    """
    Identity sig của cell — text only, stable.

    Ưu tiên dùng layout_type từ extract (đã tính sẵn) để tránh walk children lại.
    Fallback về walk children nếu node cũ chưa có layout_type (backward compat).

    layout_type="text"/"mixed" → hash(full_text hoặc text)
    layout_type="nested_table" → hash(nested_text)   — stable với layout nested
    layout_type="image"        → img_only:{col}:{count}
    layout_type="empty"        → empty:{col}
    fallback                   → walk children như cũ
    """
    content     = node.content or {}
    col_index   = int(content.get("col_index", 0) or 0)
    layout_type = content.get("layout_type", "")

    # ── Dùng layout_type từ extract ───────────────────────────────────────────
    if layout_type == "nested_table":
        # nested_text: text gom từ nested table, stable với layout bên trong
        nested_text = _norm_text(
            content.get("nested_text", "")
            or content.get("full_text", "")
            or content.get("text", "")
        )
        return f"C:tbl:{_hash(nested_text)}"

    if layout_type == "image":
        image_count = int(content.get("image_count", 0) or 0)
        return f"C:img:{col_index}:{image_count}"

    if layout_type == "empty":
        return f"C:empty:{col_index}"

    if layout_type in ("text", "mixed"):
        # full_text bao gồm cả nested content nếu có
        # Với text/mixed thì nested_text thường rỗng → full_text == text
        txt = _norm_text(
            content.get("full_text", "")
            or content.get("text", "")
        )
        if txt:
            return f"C:{_hash(txt)}"
        return f"C:empty:{col_index}"

    # ── Fallback: walk children (node cũ chưa có layout_type) ────────────────
    texts:              List[str] = []
    image_count:        int       = 0
    has_nested_table:   bool      = False
    nested_table_texts: List[str] = []

    if node.children:
        for child in node.children:
            if child.type == "paragraph":
                txt = _norm_text(child.content.get("text", ""))
                if txt:
                    texts.append(txt)
            elif child.type == "image":
                image_count += 1
            elif child.type == "table":
                has_nested_table = True
                ts = _norm_text(
                    child.content.get("text_set", "")
                    or child.content.get("text", "")
                )
                nested_table_texts.append(ts)
    else:
        txt = _norm_text(content.get("full_text", "") or content.get("text", ""))
        if txt:
            texts.append(txt)

    if has_nested_table:
        combined = "|".join(nested_table_texts)
        return f"C:tbl:{_hash(combined)}"

    if texts:
        return f"C:{_hash(' '.join(texts))}"

    if image_count > 0:
        return f"C:img:{col_index}:{image_count}"

    return f"C:empty:{col_index}"


def _row_identity_sig(node: DocNode) -> str:
    """
    Identity sig của row — tổng hợp từ cell identity sigs.

    Không dùng row_index (shift khi thêm/xóa row đầu).
    Không dùng ảnh (stable trước ảnh đổi layout).

    Nếu row có nested table (has_nested_table=True từ extract):
    dùng outer_label_texts + nested cell sig để tạo sig đặc biệt
    stable với số lượng sub-rows của nested table thay đổi.
    """
    content = node.content or {}

    if node.children:
        # Row có nested table → sig dựa vào label + nested text
        # tránh sig thay đổi khi sub-row count thay đổi
        if content.get("has_nested_table"):
            label_texts = content.get("outer_label_texts", [])
            nested_sigs = []
            for c in node.children:
                if c.type != "cell":
                    continue
                if (c.content or {}).get("layout_type") == "nested_table":
                    nested_sigs.append(_cell_identity_sig(c))
            combined = "|".join(
                [_norm_text(t) for t in label_texts if t] + nested_sigs
            )
            return f"R:nested:{_hash(combined)}"

        cells_sig = "|".join(
            _cell_identity_sig(c)
            for c in node.children
            if c.type == "cell"
        )
        return f"R:{_hash(cells_sig)}"

    # Fallback
    row_text = _norm_text(content.get("text", ""))
    return f"R:{_hash(row_text)}"


def table_identity_sig(node: DocNode, heading_ctx: str = "") -> str:
    """
    Identity sig của table — dùng để MATCH block giữa 2 phiên bản.

    Dùng text_set (sorted unique full_text của mọi cell, kể cả nested content):
    - Stable với: layout ảnh, col_span, thứ tự ảnh, row rỗng, nested layout
    - Sensitive với: thêm/xóa/sửa text bất kỳ cell nào

    text_set từ extract đã tính đúng (dùng full_text). Không cần fallback
    build lại trừ khi node cũ chưa có text_set.

    heading_ctx_body: bỏ số chương để stable khi heading shift.

    Format: T_id:{rows}x{cols}:{text_hash}:{ctx_hash}
    """
    content = node.content or {}
    rows    = int(content.get("row_count", 0) or 0)
    cols    = int(content.get("col_count", 0) or 0)

    # text_set từ extract đã bao gồm full_text (nested table content)
    text_set = _norm_text(content.get("text_set", "") or "")

    if not text_set and node.children:
        # Fallback cho node cũ chưa có text_set đúng
        all_texts = sorted(set(
            _norm_text(
                c.content.get("full_text", "")
                or c.content.get("text", "")
            )
            for r in node.children if r.type == "row"
            for c in (r.children or []) if c.type == "cell"
            if _norm_text(
                c.content.get("full_text", "")
                or c.content.get("text", "")
            )
        ))
        text_set = " ".join(all_texts)

    ctx_body = _heading_ctx_body_from_sig(heading_ctx)
    h_text   = _hash(text_set, 16)
    h_ctx    = _hash(ctx_body, 8) if ctx_body else "noctx"

    return f"T_id:{rows}x{cols}:{h_text}:{h_ctx}"


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════

def signature(node: DocNode, heading_ctx: str = "") -> str:
    """
    Tạo EQUALITY fingerprint cho node.

    Dùng để detect CHANGE bên trong block sau khi đã match.
    Bao gồm ảnh (sha256) → sensitive với mọi thay đổi kể cả ảnh đổi layout.

    KHÔNG dùng để match table giữa 2 phiên bản → dùng table_identity_sig().
    """
    t = node.type

    if t == "heading":   return _sig_heading(node)
    if t == "paragraph": return _sig_paragraph(node)
    if t == "table":     return _sig_table(node)
    if t == "row":       return _sig_row(node)
    if t == "cell":      return _sig_cell(node)
    if t == "image":     return _sig_image(node)
    if t == "shape":     return _sig_shape(node, heading_ctx)

    txt = _norm_text(node.content.get("text", ""))
    return f"U:{t}:{_hash(txt, 12)}"