"""
block/block_builder.py
~~~~~~~~~~~~~~~~~~~~~~
Duyệt DocNode tree → List[Block] đã được:
    1. Lọc bỏ section không cần diff (TOC, revision history...)
    2. Track heading_ctx (breadcrumb)
    3. Inject signature(node, heading_ctx) — khớp với signature.py và sequence_align.py
    4. Sort theo order + fix shape heading
    5. Merge bảng bị cắt trang
    6. Fallback heuristic TOC
"""

from __future__ import annotations

import re
from typing import List, Optional

from src.services.models.docnode import DocNode
from src.services.models.block import Block
# FIX: đổi _norm thành _norm_text — tên đúng được export từ signature.py
from src.services.block.signature import signature, _norm_text


# ══════════════════════════════════════════════════════════════════════════════
# Helpers chuẩn hoá text (lowercase cho pattern matching nội bộ)
# ══════════════════════════════════════════════════════════════════════════════

def _norm(s: str) -> str:
    """Lowercase + collapse whitespace — dùng cho so sánh pattern nội bộ."""
    s = (s or "").lower().strip()
    return re.sub(r"\s+", " ", s)


# ══════════════════════════════════════════════════════════════════════════════
# Pattern skip
# ══════════════════════════════════════════════════════════════════════════════

_SKIP_SECTION_PATTERNS = [
    "muc luc", "mục lục", "table of contents", "目次",
    "ly lich sua doi", "lý lịch sửa đổi", "revision history",
    "change history", "document history", "改訂履歴",
]

_SKIP_BLOCK_PATTERNS = [
    "tiep trang sau", "tiếp trang sau",
    "(tiep trang sau)", "(tiếp trang sau)",
    "continued on next page", "continue on next page",
    "次ページに続く",
]

_TOC_LINE_RE = re.compile(
    r".+[\.\s·•]{3,}\d+\s*$"
)
_TOC_HEURISTIC_MIN_LINES = 4


def _is_skip_section_heading(node: DocNode) -> bool:
    text = _norm(node.content.get("text", ""))
    return any(pat in text for pat in _SKIP_SECTION_PATTERNS)


def _is_skip_pattern(text: str) -> bool:
    return any(pat in text for pat in _SKIP_BLOCK_PATTERNS)


def _is_skip_block(node: DocNode) -> bool:
    if node.content.get("in_toc"):
        return True
    if node.type in ("paragraph", "heading"):
        return _is_skip_pattern(_norm(node.content.get("text", "")))
    if node.type == "table":
        non_empty = []
        for n in node.walk():
            if n.type == "cell":
                t = _norm(n.content.get("text", ""))
                if t:
                    non_empty.append(t)
        if not non_empty:
            return False
        return all(_is_skip_pattern(t) for t in non_empty)
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Shape helpers
# ══════════════════════════════════════════════════════════════════════════════

def _shape_has_any_child(node: DocNode) -> bool:
    return bool(node.children)


# ══════════════════════════════════════════════════════════════════════════════
# Table merge helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_rows(table_node: DocNode) -> List[DocNode]:
    return [c for c in (table_node.children or []) if c.type == "row"]


def _get_cells(row_node: DocNode) -> List[DocNode]:
    return [c for c in (row_node.children or []) if c.type == "cell"]


def _col_count(table_node: DocNode) -> int:
    rows = _get_rows(table_node)
    return len(_get_cells(rows[0])) if rows else 0


def _get_header_key(table_node: DocNode) -> Optional[str]:
    rows = _get_rows(table_node)
    if not rows:
        return None
    return "|".join(_norm(c.content.get("text", "")) for c in _get_cells(rows[0]))


def _get_cell_texts(row_node: DocNode) -> List[str]:
    texts = []
    for cell in _get_cells(row_node):
        cell_text = _norm(cell.content.get("text", ""))
        if cell_text:
            texts.append(cell_text)
            continue
        for child in (cell.children or []):
            if child.type == "paragraph":
                t = _norm(child.content.get("text", ""))
                if t:
                    texts.append(t)
    return texts


def _last_row_is_continue(table_node: DocNode) -> bool:
    rows = _get_rows(table_node)
    if not rows:
        return False
    non_empty = _get_cell_texts(rows[-1])
    return bool(non_empty) and all(_is_skip_pattern(t) for t in non_empty)


def _remove_last_row(table_node: DocNode) -> None:
    rows = _get_rows(table_node)
    if not rows:
        return
    last = rows[-1]
    table_node.children = [c for c in (table_node.children or []) if c is not last]
    table_node.content["row_count"] = len(_get_rows(table_node))


def _merge_two_tables(base: DocNode, extra: DocNode) -> None:
    extra_rows = _get_rows(extra)
    for row in (extra_rows[1:] if len(extra_rows) > 1 else []):
        base.children.append(row)
    base.content["row_count"] = len(_get_rows(base))


def _can_merge(prev: Block, curr: Block) -> bool:
    if prev.type != "table" or curr.type != "table":
        return False
    if prev.heading_ctx != curr.heading_ctx:
        return False
    prev_header = _get_header_key(prev.node)
    curr_header = _get_header_key(curr.node)
    if prev_header is None or curr_header is None:
        return False
    if prev_header != curr_header:
        return False
    if _col_count(prev.node) != _col_count(curr.node):
        return False
    if not _last_row_is_continue(prev.node):
        return False
    return True


def _merge_consecutive_tables(blocks: List[Block]) -> List[Block]:
    if not blocks:
        return blocks
    result: List[Block] = []
    for block in blocks:
        if result and _can_merge(result[-1], block):
            prev = result[-1]
            _remove_last_row(prev.node)
            _merge_two_tables(prev.node, block.node)
            # Recalculate signature với heading_ctx sau khi merge
            prev.signature = signature(prev.node, heading_ctx=prev.heading_ctx or "")
            continue
        result.append(block)
    return result


# ══════════════════════════════════════════════════════════════════════════════
# Shape heading fix
# ══════════════════════════════════════════════════════════════════════════════

def _fix_shape_headings(blocks: List[Block]) -> List[Block]:
    """
    Fix heading_ctx cho shape floating bằng index trong list,
    không dùng order value.

    Shape floating có order cao bất thường (XML đặt sau cùng)
    → order-based lookup chọn heading sai (section sau thay vì section hiện tại).

    FIX: duyệt list theo thứ tự thực (đã sort), track heading cuối
    gặp được → assign cho shape ngay phía sau.
    """
    last_heading_ctx: Optional[str] = None

    for block in blocks:
        if block.type == "heading":
            last_heading_ctx = block.heading_ctx
            continue

        if block.type == "shape" and last_heading_ctx is not None:
            if block.heading_ctx != last_heading_ctx:
                block.heading_ctx = last_heading_ctx
                block.signature = signature(block.node, heading_ctx=last_heading_ctx)

    return blocks
# ══════════════════════════════════════════════════════════════════════════════
# TOC heuristic fallback
# ══════════════════════════════════════════════════════════════════════════════

def _looks_like_toc_line(text: str) -> bool:
    return bool(_TOC_LINE_RE.match(text.strip()))


def _remove_heuristic_toc(blocks: List[Block]) -> List[Block]:
    result: List[Block] = []
    i = 0
    while i < len(blocks):
        block = blocks[i]
        if (
            block.type == "paragraph"
            and not block.node.content.get("in_toc")
            and _looks_like_toc_line(_norm(block.node.content.get("text", "")))
        ):
            j = i
            while (
                j < len(blocks)
                and blocks[j].type == "paragraph"
                and not blocks[j].node.content.get("in_toc")
                and _looks_like_toc_line(_norm(blocks[j].node.content.get("text", "")))
            ):
                j += 1
            if (j - i) >= _TOC_HEURISTIC_MIN_LINES:
                i = j
                continue
            else:
                result.extend(blocks[i:j])
                i = j
                continue
        result.append(block)
        i += 1
    return result


# ══════════════════════════════════════════════════════════════════════════════
# Main builder
# ══════════════════════════════════════════════════════════════════════════════

def build_blocks(doc_root: DocNode) -> List[Block]:
    """
    Duyệt DocNode tree → List[Block] sẵn sàng cho align_blocks().

    Mỗi Block có:
    - type, node, uid, order
    - heading_ctx  : breadcrumb heading tại vị trí block ("Ch1 > Mục 1.2")
    - signature    : fingerprint text, inject heading_ctx cho shape
    """
    blocks: List[Block] = []

    current_heading: Optional[str]  = None
    current_heading_level: int      = 0
    heading_stack: List[dict]       = []
    skip_until_level: Optional[int] = None

    for node in (doc_root.children or []):

        # ── Heading ───────────────────────────────────────────────────────────
        if node.type == "heading":
            heading_level = int(node.content.get("level", 1) or 1)

            if skip_until_level is not None:
                if heading_level <= skip_until_level:
                    skip_until_level = None
                else:
                    continue

            if _is_skip_section_heading(node):
                skip_until_level = heading_level
                continue

            if _is_skip_block(node):
                continue

            heading_text = (node.content.get("text") or "").strip()

            while heading_stack and heading_stack[-1]["level"] >= heading_level:
                heading_stack.pop()
            heading_stack.append({"text": heading_text, "level": heading_level})

            current_heading       = " > ".join(x["text"] for x in heading_stack if x["text"])
            current_heading_level = heading_level

            blocks.append(Block(
                type          = "heading",
                node          = node,
                # heading không cần heading_ctx trong signature
                # (heading tự là context, không phụ thuộc context cha)
                signature     = signature(node),
                heading_ctx   = current_heading,
                heading_level = current_heading_level,
                order         = node.order,
                uid           = node.uid,
            ))
            continue

        # ── Skip section ──────────────────────────────────────────────────────
        if skip_until_level is not None:
            continue

        if _is_skip_block(node):
            continue

        # ── Shape decorative (không có child) ─────────────────────────────────
        if node.type == "shape" and not _shape_has_any_child(node):
            continue

        # ── Paragraph / Table / Image / Shape ─────────────────────────────────
        blocks.append(Block(
            type          = node.type,
            node          = node,
            # Truyền heading_ctx vào signature — shape phân biệt được
            # 2 shape cùng text ở 2 heading khác nhau (cross-match bug fix)
            signature     = signature(node, heading_ctx=current_heading or ""),
            heading_ctx   = current_heading,
            heading_level = current_heading_level,
            order         = node.order,
            uid           = node.uid,
        ))

    # ── Sort + fix shape heading ───────────────────────────────────────────────
    sorted_blocks = sorted(
        blocks,
        key=lambda x: (x.order if x.order is not None else 0, x.uid or ""),
    )
    sorted_blocks = _fix_shape_headings(sorted_blocks)

    # ── TOC heuristic fallback ────────────────────────────────────────────────
    sorted_blocks = _remove_heuristic_toc(sorted_blocks)

    # ── Merge bảng bị cắt trang ───────────────────────────────────────────────
    return _merge_consecutive_tables(sorted_blocks)